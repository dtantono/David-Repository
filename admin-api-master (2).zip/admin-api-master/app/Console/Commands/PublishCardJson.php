<?php

namespace App\Console\Commands;

use App\Http\Controllers\WazaController;
use App\Illustrator;
use App\Models\Card;
use App\Models\CodeMaster;
use App\Models\Expansion;
use App\Models\Pokedex;
use App\Models\Waza;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class PublishCardJson extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'publish:card_json';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Card Jsonを出力します。';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::info('=== Start Publish Json');

        // 公開中のカードのみ
        $cards = Card::where('publish_status', 4)->get();
        $bar = $this->output->createProgressBar($cards->count());

        // 出力するディレクトリ名
        //$exports_dir = '/exports/' . date('Ymd_His') . '/';
        $exports_dir = '/exports/cards/' . date('Ymd') . '/';

        Storage::makeDirectory($exports_dir);

        $table = CodeMaster::get();
        $code_masters = [];
        foreach ($table as $key => $v) {
            $code_masters[$v->type_name][$v->code] = $v->name;
        }

        foreach ($cards as $card) {
            // カードテンプレートJSON読み込み
            $template = json_decode(file_get_contents(app_path('Console/Commands/template/card.json')));

            $template->data->id = (int)$card->id;
            $template->data->card_id = $card->card_id;
            $template->data->card_type->large = (int)$card->card_type_large;
            $template->data->card_type->middle = (int)$card->card_type_middle;
            $template->data->card_type->small = (int)$card->card_type_small;
            $template->data->card_type->collection = $card->collection;

            if (!empty($code_masters['rarity_status'][$card->rarity])) {
                $template->data->rarity->id = $code_masters['rarity_status'][$card->rarity];
            }
            $template->data->rarity->name = $card->rarity;

            $illustrator = Illustrator::where('id', $card->illustrator_id)->first();
            $template->data->illustrator->id = $card->illustrator_id;
            $template->data->illustrator->name = $illustrator->name;

            $expansion = Expansion::where('id', $card->expansion_id)->first();
            $template->data->expansion->id = $card->expansion_id;
            $template->data->expansion->name = $expansion->name;

            $template->data->regulation->id = $card->regulation_id;
            $template->data->regulation->name = $code_masters['regulation'][$card->regulation_id];

            $template->data->deck_group->id = $card->deck_group_id;
            $template->data->deck_group->name = $code_masters['deck_group'][$card->deck_group_id];

            $template->data->copyright = $card->copyright;
            $template->data->format = $card->format;

            $template->data->evolution_mark = (int)$card->evolution_mark;
            $template->data->p_evolution_type = json_decode($card->p_evolution_type);

            $template->data->p_ability_type = $card->p_ability_type;
            $template->data->p_other_type->prismstar = $card->p_other_type;

            $template->data->before_evolution_pokemon = $card->before_evolution_pokemon_id;

            $template->data->name = $card->name;
            $template->data->hp = (int)$card->hp;

            $count = 1;
            foreach ($template->data->energy_type as $key => $value) {
                if ($card->energy_type == $count) {
                    $template->data->energy_type->$value = true;
                }
                $count++;
            }

            $count = 1;
            foreach ($template->data->weakness as $key => $value) {
                if ($card->weakness == $count) {
                    $template->data->weakness->$value = true;
                }
                $count++;
            }

            $template->data->resistance->type = $card->resistance_type;
            $template->data->resistance->value = $card->resistance_value;

            $template->data->retreat_cost = (int)$card->retreat_cost;

            $pokedex = Pokedex::where('id', $card->pokedex_id)->first();
            $template->data->pokedex->id = (int)$pokedex->id;
            $template->data->pokedex->pokedex_no = $pokedex->pokedex_no;
            $template->data->pokedex->pokedex_type->id = $pokedex->pokedex_type;
            $template->data->pokedex->pokedex_type->name = $pokedex->pokedex_type_name;
            $template->data->pokedex->flavor->id = $pokedex->retreat_cost;
            $template->data->pokedex->flavor->flavor_kanji = $pokedex->flavor_kanji;
            $template->data->pokedex->flavor->flavor_kana = $pokedex->flavor_kana;
            $template->data->pokedex->flavor->flavor_ver = $pokedex->flavor_ver;
            $template->data->pokedex->height = $pokedex->height;
            $template->data->pokedex->weight = $pokedex->weight;

            $template->data->card_image_id = $card->id;

            for ($i = 1; $i >= 3; $i) {
                if (!empty($card->{'waza_id_' . $i})) {
                    $template->data->waza->{'waza_' . $i} = $this->get_waza($card->{'waza_id_' . $i});
                }
            }

            $template->data->height = $card->height;
            $template->data->weight = $card->weight;

            $template->energy = json_decode($card->energy);
            $template->trainers = json_decode($card->weight);
            $template->evolution_map = json_decode($card->evolution_map);

            Storage::put($exports_dir . $card->card_id . '.json', json_encode($template, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

            $bar->advance();
        }
        $bar->finish();

        Log::info('=== Finish Publish Json');
    }

    private function get_waza($id)
    {
        $json = new \stdClass();
        $waza = Waza::where('id', $id)->first();
        $waza_controller = new WazaController();
        if ($waza) {
            $json->id = $waza->id;
            $json->waza_name = $waza->name;
            $json->waza_damage = $waza->damage;
            $json->waza_text = $waza->body;
            $json->memo = $waza->memo;
            $json->status = $waza->status;
            $json->waza_type = $waza->category;
            $json->energy_cost = $waza_controller->getWazaEnergies($waza->id);
            $json->logic = $waza_controller->getWazaLogics([], $waza->id);
        }
        return (array)$json;
    }
}
