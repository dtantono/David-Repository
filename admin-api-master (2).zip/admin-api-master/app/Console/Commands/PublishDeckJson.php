<?php

namespace App\Console\Commands;

use App\Http\Controllers\WazaController;
use App\Illustrator;
use App\Models\Card;
use App\Models\CodeMaster;
use App\Models\Deck;
use App\Models\DeckCard;
use App\Models\Expansion;
use App\Models\Pokedex;
use App\Models\Waza;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class PublishDeckJson extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'publish:deck_json';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Deck Jsonを出力します。';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::info('=== Start Publish Json');

        // 公開中のカードのみ
        $decks = Deck::where('publish_status', 4)->get();

        $bar = $this->output->createProgressBar($decks->count());

        // 出力するディレクトリ名
        $exports_dir = '/exports/decks/' . date('Ymd') . '/';

        Storage::makeDirectory($exports_dir);

        $table = CodeMaster::get();
        $code_masters = [];
        foreach ($table as $key => $v) {
            $code_masters[$v->type_name][$v->code] = $v->name;
        }

        foreach ($decks as $deck) {
            $deck_cards = DeckCard::where('deck_id', $deck->id)->get();
            $ids = [];
            $nos = [];
            foreach ($deck_cards as $deck_card) {
                $ids[] = $deck_card->card_id;
                $nos[$deck_card->card_id] = $deck_card->card_no;
            }
            // カードテンプレートJSON読み込み
            $template = json_decode(file_get_contents(app_path('Console/Commands/template/deck.json')));

            $cards = Card::where('publish_status', 4)->whereIn('id', $ids)->get();

            $template->data->deck->id = (int)$deck->id;
            $template->data->deck->deck_name = $deck->name;
            $template->data->deck->deck_total = (int)$deck_cards->count();
            $template->data->deck->deck_card = [];
            $template->data->deck->evolution_list = [];

            $card_data = [];
            foreach ($cards as $card) {
                $card_data['card_id'] = $card->card_id;
                $card_data['card_type']['large'] = (int)$card->card_type_large;
                $card_data['card_type']['middle'] = (int)$card->card_type_middle;
                $card_data['card_type']['small'] = (int)$card->card_type_small;
                $card_data['name'] = $card->name;
                $card_data['energy_type'] = $card->energy_type;
                $card_data['value'] = $nos[$card->id];
                $template->data->deck->deck_card[] = $card_data;
                $template->data->deck->evolution_list = json_decode($card->evolution_map);
            }

            Storage::put($exports_dir . $deck->id . '.json', json_encode($template, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

            $bar->advance();
        }
        $bar->finish();

        Log::info('=== Finish Publish Json');
    }
}
