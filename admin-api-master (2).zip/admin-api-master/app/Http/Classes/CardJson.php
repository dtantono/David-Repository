<?php

namespace App\Http\Classes;

use App\Http\Controllers\ExportController;
use App\Illustrator;
use App\Models\Card;
use App\Models\CodeMaster;
use App\Models\Expansion;
use App\Models\Pokedex;
use App\Models\Waza;
use App\Models\WazasEnergies;

class CardJson
{
    public function generate($card)
    {
        $table = CodeMaster::get();
        $code_masters = [];
        $code_master_values = [];
        foreach ($table as $key => $v) {
            $code_masters[$v->type_name][$v->code] = $v->name;
            $code_master_values[$v->type_name][$v->name] = $v->code;
        }

        // カードテンプレートJSON読み込み
        $template = json_decode(file_get_contents(app_path('Console/Commands/template/card.json')));

        $template->data->id = (int)$card->id;
        $template->data->card_id = $card->card_id;
        if (!empty($card->card_type_large)) {
            $template->data->card_type->large = (int)$card->card_type_large;
        }
        if (!empty($card->card_type_middle)) {
            $template->data->card_type->middle = (int)$card->card_type_middle;
        }
        if (!empty($card->card_type_small)) {
            $template->data->card_type->small = (int)$card->card_type_small;
        }
        $template->data->collection = $card->collection;

        if (!empty($code_masters['rarity_status'][$card->rarity])) {
            $template->data->rarity->id = (int)$card->rarity;
            $template->data->rarity->name = $code_masters['rarity_status'][$card->rarity];
        }

        $illustrator = Illustrator::where('id', $card->illustrator_id)->first();
        if (!empty($illustrator)) {
            $template->data->illustrator->id = $card->illustrator_id;
            $template->data->illustrator->name = $illustrator->name;
        }

        if (!empty($card->expansion_id)) {
            $expansion = Expansion::where('id', $card->expansion_id)->first();
            $template->data->expansion->id = $card->expansion_id;
            $template->data->expansion->name = $expansion->name;
        }

        $template->data->regulation->id = $card->regulation_id;
        if (!empty($code_masters['regulation'][$card->regulation_id])) {
            $template->data->regulation->name = $code_masters['regulation'][$card->regulation_id];
        }

        $template->data->deck_group->id = $card->deck_group_id;
        if (!empty($code_masters['deck_group'][$card->deck_group_id])) {
            $template->data->deck_group->name = $code_masters['deck_group'][$card->deck_group_id];
        }

        $template->data->copyright = $card->copyright;
        if ($card->evolution_mark && !empty($code_masters['evolution_mark'][$card->evolution_mark])) {
            $template->data->format = $code_masters['evolution_mark'][$card->evolution_mark];
        }
        $template->data->evolution_mark = (int)$card->evolution_mark;
        $p_evolution_type = json_decode($card->p_evolution_type, true);
        if (empty($p_evolution_type['gx'])) {
            $p_evolution_type['gx'] = false;
        }
        if (empty($p_evolution_type['ultrabeast'])) {
            $p_evolution_type['ultrabeast'] = false;
        }
        $template->data->p_evolution_type = $p_evolution_type;

        if (!empty($card->p_ability_type)) {
            $template->data->p_ability_type = $card->p_ability_type;
        }
        if (!empty($card->p_other_type)) {
            $template->data->p_other_type->prismstar = true;
        }

        $before_pokemon = Card::where('id', $card->before_evolution_pokemon_id)->first();

        if (!empty($before_pokemon->name)) {
            $template->data->before_evolution_pokemon = [$before_pokemon->name];
        }


        $template->data->name = $card->name;
        $template->data->hp = (int)$card->hp;

        $count = 1;
        foreach ($template->data->energy_type as $key => $value) {
            if ($card->energy_type == $count) {
                $template->data->energy_type->{$key} = true;
            }
            $count++;
        }

        $count = 1;
        foreach ($template->data->weakness as $key => $value) {
            if ($card->weakness == $count) {
                $template->data->weakness->{$key} = true;
            }
            $count++;
        }

        if (!empty($card->resistance_type)) {
            $template->data->resistance->type = (int)$card->resistance_type;
        }
        if (!empty($card->resistance_value)) {
            $template->data->resistance->value = (int)$card->resistance_value;
        }

        $template->data->retreat_cost = (int)$card->retreat_cost;

        $pokedex = Pokedex::where('id', $card->pokedex_id)->first();
        if ($pokedex) {
            $template->data->pokedex->id = (int)$pokedex->id;
            $template->data->pokedex->pokedex_no = (int)$pokedex->pokedex_no;
            $template->data->pokedex->pokedex_type->id = $pokedex->pokedex_type;
            $template->data->pokedex->pokedex_type->name = $pokedex->pokedex_type_name;
            $template->data->pokedex->flavor->id = (int)$pokedex->pokedex_no;
            $template->data->pokedex->flavor->flavor_kanji = $pokedex->flavor_kanji;
            $template->data->pokedex->flavor->flavor_kana = $pokedex->flavor_kana;
            $template->data->pokedex->flavor->flavor_ver = $pokedex->flavor_ver;
            $template->data->pokedex->height = $pokedex->height;
            $template->data->pokedex->weight = $pokedex->weight;
        }

        $template->data->card_image_id = $card->id;

        //カードタイプがポケモン
        if ($card->card_type_large == 1) {
            for ($i = 1; $i <= 3; $i++) {
                if (!empty($card->{'waza_id_' . $i})) {
                    $template->data->waza->{'waza_' . $i} = $this->get_waza($card->{'waza_id_' . $i});
                }
            }
        } else {
            //カードタイプがエネルギー・トレーナーズのとき
            $arr = [
                1 => 'Co',
                2 => 'Gr',
                3 => 'Fr',
                4 => 'Wa',
                5 => 'Li',
                6 => 'Ps',
                7 => 'Fg',
                8 => 'Da',
                9 => 'Me',
                10 => 'Fa',
                11 => 'Dr',
            ];
            $energies = WazasEnergies::where('waza_id', $card->waza_id_1)->get();
            $template->data->waza->waza_1 = new \stdClass();
            $template->data->waza->waza_1->id = null;
            $template->data->waza->waza_1->waza_name = null;
            $template->data->waza->waza_1->waza_type = null;
            $template->data->waza->waza_1->waza_damage = null;
            $template->data->waza->waza_1->energy_cost = new \stdClass();
            foreach ($arr as $type => $value) {
                $template->data->waza->waza_1->energy_cost->{$value} = new \stdClass();
                $template->data->waza->waza_1->energy_cost->{$value}->type = $type;
                $template->data->waza->waza_1->energy_cost->{$value}->value = 0;
            }

            $old_master = [
                1 => 'Gr',
                2 => 'Fr',
                3 => 'Wa',
                4 => 'Li',
                5 => 'Ps',
                6 => 'Fg',
                7 => 'Da',
                8 => 'Me',
                9 => 'Fa',
                10 => 'Dr',
                11 => 'Co',
            ];
            foreach ($energies as $energy) {
                $template->data->waza->waza_1->energy_cost->{$old_master[$energy->energy_id]}->value = $energy->quantity;
            }
            $template->data->waza->waza_1->waza_text = null;
            $template->data->waza->waza_1->memo = null;
            $template->data->waza->waza_1->logic = null;
        }

        if ($card->card_type_large == 2) {
            $energy = $this->get_energy_trainer($card->{'waza_id_1'}, 2);
            if ($energy) {
                $template->data->energy = $energy;
            } else {
                $template->data->energy->energy_total = 1;
            }
        }
        if ($card->card_type_large == 3) {
            if (!empty($card->{'waza_id_2'})) {
                $template->data->trainers = new \stdClass();
                $trainers = $this->get_trainer_multi([$card->{'waza_id_1'}, $card->{'waza_id_2'}, $card->{'waza_id_3'}]);
                if ($trainers) {
                    $template->data->trainers = $trainers;
                }
            } else {
                $trainers = $this->get_energy_trainer($card->{'waza_id_1'}, 3);
                if ($trainers) {
                    $template->data->trainers = $trainers;
                }
            }

        }

        $evolution_map = json_decode($card->evolution_map, true);
        $evolution_map_arr = [];
        if (!empty($evolution_map)) {
            foreach ($evolution_map['evolution_map'] as $k1 => $v1) {
                $evolution_map_arr[$k1] = [$v1['name']];

            }
            $template->data->evolution_map = $evolution_map_arr;
        }

        return $template;
    }


    private function get_waza($id)
    {
        $json = new \stdClass();
        $waza = Waza::where('id', $id)->first();
        $waza_controller = new ExportController();
        if (!$waza) {
            return $json;
        }
        $json->id = $waza->id;
        $json->waza_name = $waza->name;
        $json->waza_damage = $waza->damage;
        $json->waza_text = $waza->body;
        $json->memo = $waza->memo;
        $json->waza_type = $waza->waza_type;
        $json->energy_cost = $waza_controller->getWazaEnergies($waza->id);
        $json->logic = $waza_controller->getWazaLogics([], $waza->id);

        if ($json->waza_type == 1 && empty($json->logic)) {
            //固定JSON書き換える
            $json->logic = json_decode(file_get_contents(app_path('Console/Commands/template/card_pokemon_default.json')), true);
        }
        return (array)$json;
    }

    private function get_energy_trainer($id, $card_type_large)
    {
        $json = new \stdClass();
        $waza = Waza::where('id', $id)->first();
        $waza_controller = new ExportController();
        if (!$waza) {
            return (array)$json;
        }

        $json->id = $waza->id;
        $logic = $waza_controller->getWazaLogics([], $waza->id);
        switch ($card_type_large) {
            case 2:
                $json->energy_text = $waza->body;
                $json->energy_memo = $waza->memo;
                $json->energy_total = (int)$waza->energy_number;
                $json->energy_logic = $logic;
                break;
            case 3:
                $json->trainers_text = $waza->body;
                $json->trainers_memo = $waza->memo;
                $json->trainers_logic = $logic;
                break;
        }

        return (array)$json;
    }

    private function get_trainer_multi($ids)
    {
        $json = new \stdClass();
        $waza = Waza::where('id', $ids[0])->first();
        $waza_controller = new ExportController();
        if (!$waza) {
            return (array)$json;
        }

        $logic2 = [];
        if (!empty($ids[1])) {
            $logic2 = $waza_controller->getWazaLogics([], $ids[1]);
        }

        $logic3 = [];
        if (!empty($ids[2])) {
            $logic3 = $waza_controller->getWazaLogics([], $ids[2]);
        }


        $json->id = $waza->id;
        $logic = $waza_controller->getWazaLogics([], $waza->id);

        $json->trainers_text = $waza->body;
        $json->trainers_memo = $waza->memo;
        $json->trainers_logic_1 = $logic;
        if (!empty($logic2)) {
            $json->trainers_logic_2 = $logic2;
        }
        if (!empty($logic3)) {
            $json->trainers_logic_3 = $logic3;
        }

        return (array)$json;
    }
}
