<?php

namespace App\Http\Controllers;

use App\Illustrator;
use App\Models\Card;
use App\Models\CodeMaster;
use App\Models\Expansion;
use App\Models\Pokedex;
use App\Models\Waza;
use Illuminate\Http\Request;

class CardController extends Controller
{
    var $params = [
        "id",
        "version",
        "card_id",
        "publish_status",
        "card_type_large",
        "card_type_middle",
        "card_type_small",
        "collection",
        "rarity",
        "illustrator_id",
        "expansion_id",
        "regulation_id",
        "deck_group_id",
        "copyright",
        "format",
        "evolution_mark",
        "p_evolution_type",
        "p_ability_type",
        "p_other_type",
        "before_evolution_pokemon_id",
        "name",
        "hp",
        "energy_type",
        "weakness",
        "resistance_type",
        "resistance_value",
        "retreat_cost",
        "affiliation_id",
        "pokedex_id",
        "card_image_path",
        "waza_id_1",
        "waza_id_2",
        "waza_id_3",
        "energy",
        "trainers",
        "evolution_map",
        "created_at",
        "updated_at",
        "register_name",
        "updater_name",
    ];

    var $master_params = [
    ];

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $cards = Card::query();

        if ($request->search) {
            $wazas = Waza::select('id')
                ->where('name', 'like', '%' . $request->search . '%')
                ->get()
                ->toArray();

            $cards->where(function ($query) use ($request, $wazas) {
                $query->where('name', 'like', '%' . $request->search . '%');

                if ($wazas) {
                    $query->orwhereIn('waza_id_1', $wazas);
                    $query->orwhereIn('waza_id_2', $wazas);
                    $query->orwhereIn('waza_id_3', $wazas);
                }
            });
        }

        if ($request->ids) {
            $cards->whereIn('id', explode(',', $request->ids));
        }

        if ($request->publish_status) {
            $publish_status = explode(',', $request->publish_status);
            $cards->whereIn('publish_status', $publish_status);
        }

        $per_page = 10;
        if ($request->per_page) {
            $per_page = $request->per_page;
        }

        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $cards->orderBy($sort_column, $sort);

        if ($request->csv) {
            return $cards->get();
        }

        $items = $cards->paginate($per_page);

        $card_data = [];
        foreach ($items as $key => $value) {
            $card_data[$key] = $this->set_card_data($this->params, $value, true);
        }
        $json = [
            "total" => $items->total(),
            "per_page" => $items->perPage(),
            "current_page" => $items->currentPage(),
            "last_page" => $items->lastPage(),
            "from" => $items->firstItem(),
            "to" => $items->lastItem(),
            'data' => $card_data,
        ];
        return $json;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $image_path = '';
        if ($request->image) {
            $image_path = $this->upload_file($request, 'card');
        }

        $card = new Card();
        foreach ($this->params as $param) {
            $card->$param = $request->$param;
        }

        if (!empty($request->p_evolution_type)) {
            $card->p_evolution_type = json_encode($request->p_evolution_type);
        }
        if (!empty($request->energy)) {
            $card->energy = json_encode($request->energy);
        }
        if (!empty($request->trainers)) {
            $card->trainers = json_encode($request->trainers);
        }
        if (!empty($request->evolution_map)) {
            $card->evolution_map = json_encode($request->evolution_map);
        }
        $card->card_image_path = $image_path;

        if (!empty($request->updater_name)) {
            $card->register_name = $request->updater_name;
            $card->updater_name = $request->updater_name;
        }
        $card->created_at = date('Y-m-d H:i:s');
        $card->updated_at = date('Y-m-d H:i:s');
        $card->save();
        return $card;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PictureBook $card
     * @return \Illuminate\Http\Response
     */
    public function show(Card $card)
    {
        $card_data = $this->set_card_data($this->params, $card);

        return $card_data;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Card $card
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Card $card)
    {
        $image_path = '';
        if ($request->image) {
            $image_path = $this->upload_file($request, 'card');
        }
        foreach ($this->params as $param) {
            if ($param === 'id' || $param === 'created_at' || $param === 'register_name') {
                continue;
            }
            $card->$param = $request->$param;
        }
        if (!empty($request->p_evolution_type)) {
            $card->p_evolution_type = json_encode($request->p_evolution_type);
        }
        if (!empty($request->energy)) {
            $card->energy = json_encode($request->energy);
        }
        if (!empty($request->trainers)) {
            $card->trainers = json_encode($request->trainers);
        }
        if (!empty($request->evolution_map)) {
            $card->evolution_map = json_encode($request->evolution_map);
        }
        if ($image_path) {
            $card->card_image_path = $image_path;
        }

        if (!empty($request->updater_name)) {
            $card->updater_name = $request->updater_name;
        }
        $card->updated_at = date('Y-m-d H:i:s');

        $card->save();
        return $card;
    }


    /*
     *
     */
    public function set_card_data($params, $value, $is_list = false)
    {
        $table = CodeMaster::get();
        $code_masters = [];
        foreach ($table as $key => $v) {
            $code_masters[$v->type_name][$v->code] = $v->name;
        }
        foreach ($params as $column) {
            if ($column === 'card_type_large') {
                $card_data['card_type']['large']['id'] = null;
                $card_data['card_type']['large']['name'] = '';
                if (!empty($value->$column)) {
                    $card_data['card_type']['large']['id'] = (int)$value->$column;
                    $card_data['card_type']['large']['name'] = $code_masters['card_type_large'][$value->$column];
                }
            } elseif ($column === 'card_type_middle') {
                $card_data['card_type']['middle']['id'] = null;
                $card_data['card_type']['middle']['name'] = '';
                switch ($card_data['card_type']['large']['id']) {
                    case 2:
                        if (!empty($code_masters['card_type_middle_2'][$value->$column])) {
                            $card_data['card_type']['middle']['id'] = (int)$value->$column;
                            $card_data['card_type']['middle']['name'] = $code_masters['card_type_middle_2'][$value->$column];
                        }
                        break;
                    case 3:
                        if (!empty($code_masters['card_type_middle_3'][$value->$column])) {
                            $card_data['card_type']['middle']['id'] = (int)$value->$column;
                            $card_data['card_type']['middle']['name'] = $code_masters['card_type_middle_3'][$value->$column];
                        }
                        break;
                }
            } elseif ($column === 'regulation_id') {
                $card_data['regulation']['id'] = '';
                $card_data['regulation']['name'] = '';
                if (!empty($code_masters['regulation'][$value->$column])) {
                    $card_data['regulation']['id'] = $value->$column;
                    $card_data['regulation']['name'] = $code_masters['regulation'][$value->$column];
                }
            } elseif ($column === 'deck_group_id') {
                $card_data['deck_group']['id'] = '';
                $card_data['deck_group']['name'] = '';
                if (!empty($code_masters['deck_group'][$value->$column])) {
                    $card_data['deck_group']['id'] = $value->$column;
                    $card_data['deck_group']['name'] = $code_masters['deck_group'][$value->$column];
                }
            } elseif ($column === 'affiliation_id') {
                $card_data['affiliation']['id'] = '';
                $card_data['affiliation']['name'] = '';
                if (!empty($code_masters['affiliation'][$value->$column])) {
                    $card_data['affiliation']['id'] = (int)$value->$column;
                    $card_data['affiliation']['name'] = $code_masters['affiliation'][$value->$column];
                }
            } elseif ($column === 'evolution_mark') {
                $card_data['evolution_mark']['id'] = '';
                $card_data['evolution_mark']['name'] = '';
                if (!empty($code_masters['evolution_mark'][$value->$column])) {
                    $card_data['evolution_mark']['id'] = (int)$value->$column;
                    $card_data['evolution_mark']['name'] = $code_masters['evolution_mark'][$value->$column];
                }
            } elseif ($column === 'card_type_small') {
                $card_data['card_type']['small']['id'] = null;
                $card_data['card_type']['small']['name'] = '';
                switch ($card_data['card_type']['middle']['id']) {
                    case 1:
                        if (!empty($code_masters['card_type_small_1'][$value->$column])) {
                            $card_data['card_type']['small']['id'] = (int)$value->$column;
                            $card_data['card_type']['small']['name'] = $code_masters['card_type_middle_3'][$value->$column];
                        }
                        break;
                }
            } elseif ($column === 'illustrator_id') {
                $illustrator = Illustrator::where('id', $value->$column)->first();
                $card_data['illustrator']['id'] = '';
                $card_data['illustrator']['name'] = '';
                if ($illustrator) {
                    $card_data['illustrator']['id'] = $illustrator->id;
                    $card_data['illustrator']['name'] = $illustrator->name;
                }
            } elseif ($column === 'expansion_id') {
                $expansion = Expansion::where('id', $value->$column)->first();
                $card_data['expansion']['id'] = '';
                $card_data['expansion']['name'] = '';
                if ($expansion) {
                    $card_data['expansion']['id'] = $expansion->id;
                    $card_data['expansion']['name'] = $expansion->name;
                }
            } elseif ($column === 'pokedex_id') {
                $pokedex = Pokedex::where('id', $value->$column)->first();
                $card_data['pokedex']['id'] = '';
                $card_data['pokedex']['name'] = '';
                if ($pokedex) {
                    $card_data['pokedex']['id'] = $pokedex->id;
                    $card_data['pokedex']['name'] = $pokedex->name;
                    $card_data['pokedex']['pokedex_no'] = $pokedex->pokedex_no;
                    $card_data['pokedex']['pokedex_type_name'] = $pokedex->pokedex_type_name;
                    $card_data['pokedex']['flavor_kanji'] = $pokedex->flavor_kanji;
                    $card_data['pokedex']['flavor_kana'] = $pokedex->flavor_kana;
                    $card_data['pokedex']['height'] = $pokedex->height;
                    $card_data['pokedex']['weight'] = $pokedex->weight;
                }
            } elseif ($column === 'waza_id_1' || $column === 'waza_id_2' || $column === 'waza_id_3') {
                $name = str_replace('_id', '', $column);
                $waza = Waza::where('id', $value->$column)->first();
                $card_data[$name]['id'] = '';
                $card_data[$name]['waza_name'] = '';
                $card_data[$name]['waza_damage'] = '';
                $card_data[$name]['waza_text'] = '';
                if (!empty($waza)) {
                    $card_data[$name]['id'] = $waza->id;
                    $card_data[$name]['waza_name'] = $waza->name;
                    $card_data[$name]['waza_damage'] = $waza->damage;
                    $card_data[$name]['waza_text'] = $waza->body;
                }
            } elseif ($column === 'p_evolution_type' || $column === 'energy' || $column === 'trainers') {
                $card_data[$column] = json_decode($value->$column);
            } elseif ($column === 'evolution_map') {
                $card_data[$column] = $this->create_evolution_map($value->id, $value->evolution_mark);
            } elseif (!empty($this->master_params[$column])) {
                foreach ($this->master_params as $table_key => $master_name) {
                    $card_data[$master_name]['id'] = null;
                    $card_data[$master_name]['name'] = '';
                    if ($table_key === $column && !empty($code_masters[$master_name][$value->$column])) {
                        $card_data[$master_name]['id'] = (int)$value->$column;
                        $card_data[$master_name]['name'] = $code_masters[$master_name][$value->$column];
                        break;
                    }
                }
            } elseif ($column === 'rarity' && $is_list) {
                if (!empty($code_masters['rarity_status'][$value->$column])) {
                    $card_data['rarity'] = $code_masters['rarity_status'][$value->$column];
                } else {
                    $card_data['rarity'] = '';
                }
            } elseif ($column === 'created_at' || $column === 'updated_at' || $column === 'register_name' || $column === 'updater_name') {
                $card_data[$column] = null;
                if ($value->$column) {
                    $card_data[$column] = (string)$value->$column;
                }

            } else {
                if (!empty($value->$column)) {
                    $card_data[$column] = $value->$column;
                }
            }
        }
        return $card_data;
    }

    /*
     *
     */
    private function create_evolution_map($id, $evolution_mark)
    {
        $evolution['evolution_map'] =
            [
                'evolution_group_1' => ['id' => null, 'name' => ''],
                'evolution_group_2' => ['id' => null, 'name' => ''],
                'evolution_group_3' => ['id' => null, 'name' => ''],
            ];
        $card = Card::where('id', $id)->first();
        switch ($evolution_mark) {
            case 1:
                //たね
                $evolution1 = $card;
                if (!empty($evolution1)) {
                    $evolution['evolution_map']['evolution_group_1']['id'] = (int)$evolution1->id;
                    $evolution['evolution_map']['evolution_group_1']['name'] = $evolution1->name;
                    //1進化
                    $evolution2 = Card::where('before_evolution_pokemon_id', $evolution1->id)->first();
                    if (!empty($evolution2)) {
                        $evolution['evolution_map']['evolution_group_2']['id'] = (int)$evolution2->id;
                        $evolution['evolution_map']['evolution_group_2']['name'] = $evolution2->name;
                        //2進化
                        $evolution3 = Card::where('before_evolution_pokemon_id', $evolution2->id)->first();
                        if ($evolution3) {
                            $evolution['evolution_map']['evolution_group_3']['id'] = (int)$evolution3->id;
                            $evolution['evolution_map']['evolution_group_3']['name'] = $evolution3->name;
                        }
                    }
                }

                break;
            case 2:
                //たね
                $evolution1 = Card::where('id', $card->before_evolution_pokemon_id)->first();
                if (!empty($evolution1)) {
                    $evolution['evolution_map']['evolution_group_1']['id'] = (int)$evolution1->id;
                    $evolution['evolution_map']['evolution_group_1']['name'] = $evolution1->name;
                    //1進化
                    $evolution2 = $card;
                    if (!empty($evolution2)) {
                        $evolution['evolution_map']['evolution_group_2']['id'] = (int)$evolution2->id;
                        $evolution['evolution_map']['evolution_group_2']['name'] = $evolution2->name;
                        //2進化
                        $evolution3 = Card::where('before_evolution_pokemon_id', $evolution2->id)->first();
                        if ($evolution3) {
                            $evolution['evolution_map']['evolution_group_3']['id'] = (int)$evolution3->id;
                            $evolution['evolution_map']['evolution_group_3']['name'] = $evolution3->name;
                        }
                    }
                }
                break;
            case 3:
                //2進化
                $evolution3 = $card;
                if (!empty($evolution3)) {
                    $evolution['evolution_map']['evolution_group_3']['id'] = (int)$evolution3->id;
                    $evolution['evolution_map']['evolution_group_3']['name'] = $evolution3->name;

                    if (!empty($evolution3->before_evolution_pokemon_id)) {
                        //1進化
                        $evolution2 = Card::where('id', $evolution3->before_evolution_pokemon_id)->first();
                        if (!empty($evolution2)) {
                            $evolution['evolution_map']['evolution_group_2']['id'] = (int)$evolution2->id;
                            $evolution['evolution_map']['evolution_group_2']['name'] = $evolution2->name;

                            //たね
                            $evolution1 = Card::where('id', $evolution2->before_evolution_pokemon_id)->first();
                            if ($evolution1) {
                                $evolution['evolution_map']['evolution_group_1']['id'] = (int)$evolution1->id;
                                $evolution['evolution_map']['evolution_group_1']['name'] = $evolution1->name;
                            }
                        }
                    }
                }
                break;

        }


        return $evolution;
    }
}
