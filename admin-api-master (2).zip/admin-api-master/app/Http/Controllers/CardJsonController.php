<?php

namespace App\Http\Controllers;

use App\Http\Classes\CardJson;
use App\Models\Card;

class CardJsonController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $card = Card::where('id', $id)->first();

        if (!$card) {
            return [];
        }

        $card_json = new CardJson();
        $template = $card_json->generate($card);

        return response()->json($template);
    }
}
