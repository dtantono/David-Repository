<?php

namespace App\Http\Controllers;

use App\Models\Card;
use App\Models\CardType;
use Illuminate\Http\Request;

class CardTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $card_types = CardType::query();

        if ($request->search) {
            $card_types->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->search . '%')
                    ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->ids) {
            $card_types->whereIn('id', explode(',', $request->ids));
        }

        if ($request->publish_status) {
            $card_types->where('publish_status', $request->publish_status);
        }

        if ($request->category_id) {
            $card_types->where('category_id', $request->category_id);
        }

        $per_page = 10;
        if ($request->per_page) {
            $per_page = $request->per_page;
        }

        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $card_types->orderBy($sort_column, $sort);

        if ($request->csv) {
            return $card_types->get();
        }
        return $card_types->paginate($per_page);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $card_type = new CardType();
        $card_type->name = $request->name;
        $card_type->category_id = $request->category_id;
        $card_type->publish_status = $request->publish_status;
        $card_type->description = $request->description;
        if (!empty($request->updater_name)) {
            $card_type->register_name = $request->updater_name;
            $card_type->updater_name = $request->updater_name;
        }
        $card_type->save();
        return $card_type;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CardType $cardType
     * @return \Illuminate\Http\Response
     */
    public function show(CardType $cardType)
    {
        return $cardType;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\CardType $cardType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CardType $cardType)
    {
        $cardType->name = $request->name;
        $cardType->category_id = $request->category_id;
        $cardType->publish_status = $request->publish_status;
        $cardType->description = $request->description;
        if (!empty($request->updater_name)) {
            $cardType->updater_name = $request->updater_name;
        }
        $cardType->save();
        return $cardType;
    }
}
