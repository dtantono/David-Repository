<?php

namespace App\Http\Controllers;

use App\Http\Classes\CardJson;
use App\Models\Card;
use App\Models\Waza;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use ZipArchive;

class CardZipJsonController extends Controller
{
    /**
     * Display the specified resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $cards = Card::query();

        if ($request->search) {
            $wazas = Waza::select('id')
                ->where('name', 'like', '%' . $request->search . '%')
                ->get()
                ->toArray();

            $cards->where(function ($query) use ($request, $wazas) {
                $query->where('name', 'like', '%' . $request->search . '%');

                if ($wazas) {
                    $query->orwhereIn('waza_id_1', $wazas);
                    $query->orwhereIn('waza_id_2', $wazas);
                    $query->orwhereIn('waza_id_3', $wazas);
                }
            });
        }

        if ($request->ids) {
            $cards->whereIn('id', explode(',', $request->ids));
        }

        /*
        if ($request->publish_status) {
            $publish_status = explode(',', $request->publish_status);
            $cards->whereIn('publish_status', $publish_status);
        }
        */

        $cards->whereIn('publish_status', [1, 2, 3, 4]);
        $cards->orderBy('publish_status', 'ASC');
        $cards->orderBy('card_id', 'ASC');
        $cards->orderBy('updated_at', 'ASC');


        if (!$cards->count()) {
            return [];
        }

        $zip = new ZipArchive();
        $file_name = date('Ymd_His');
        $dir_name = storage_path('/json/' . $file_name);
        $zip_file = $file_name . '.zip';
        $file_path = storage_path('/json/' . $zip_file);
        $zip->open($file_path, ZipArchive::CREATE);

        foreach ($cards->get() as $card) {
            $card_json = new CardJson();
            $template = $card_json->generate($card);
            File::makeDirectory($dir_name, $mode = 0777, true, true);
            file_put_contents($dir_name . '/' . $template->data->card_id . '.json', json_encode($template, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            $zip->addFile($dir_name . '/' . $template->data->card_id . '.json', $template->data->card_id . '.json');
        }
        $zip->close();

        return response()->download($file_path);
    }
}
