<?php

namespace App\Http\Controllers;

use App\Models\CodeMaster;

class CodeMasterController extends Controller
{

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $code_masters = CodeMaster::orderBy('type_name')->orderBy('disp_order')->get();
        $codes = [];
        foreach ($code_masters as $key => $items) {
            $codes[$items->type_name][$items->code] = $items->name;
        }
        return $codes;
    }

}
