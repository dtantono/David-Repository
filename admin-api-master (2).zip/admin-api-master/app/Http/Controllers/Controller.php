<?php

namespace App\Http\Controllers;

use App\Models\FormOption;
use App\Models\FormPart;
use App\Models\Waza;
use App\Models\WazasEnergies;
use App\Models\WazasLogics;
use Validator;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Storage;
use App\Models\Locale;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;


class Controller extends BaseController
{
    // type
    const ALL = 'ALL';
    const TPC = 'TPC';
    const FACEBOOK = 'FACEBOOK';
    // Shade type
    const BRONZE = 'BRONZE';
    const SILVER = 'SILVER';
    const GOLD = 'GOLD';
    const PLATINUM = 'PLATINUM';
    // Battle type
    const RATE = 'RATE';
    const FREE = 'FREE';
    const FRIEND = 'FRIEND';
    const GYM = 'GYM';
    // Team state
    const FOUNDED = 'FOUNDED';
    const DISSOLVED = 'DISSOLVED';
    // Card type
    const NORMAL = 'normal';
    const PURCHASE = 'purchase';
    // Card rarity
    const C = 'C';
    const U = 'U';
    const R = 'R';
    const RR = 'RR';
    const SR = 'SR';
    const HR = 'HR';
    const UR = 'UR';
    const P = 'P';
    const RARITIES = [
        self::C,
        self::U,
        self::R,
        self::RR,
        self::SR,
        self::HR,
        self::UR,
        self::P
    ];
    // Summary
    const SUMMARY = 'summary';
    const TOTAL = 'total';
    const NEW_DATA = 'new';
    // etc
    const TOTALS = 'totals';
    const NEWS = 'news';

    const CONSUMED = 'consumed';
    const PUBLISHED = 'published';
    // Datetime conditions
    const DAILY = 'daily';
    const MONTHLY = 'monthly';
    const YEARLY = 'yearly';

    public $json = [
        'result' => 1,
        'error_code' => '',
        'error_message' => '',
    ];

    public $data = [];
    public $query = [];

    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    function upload_file($request, $path)
    {
        $file = explode(',', $request->image);
        $file = str_replace(' ', '+', $file);
        $file_name = str_random(15);

        $ext = '.jpg';
        if (strpos($file[0], 'image/gif')) {
            $ext = '.gif';
        }
        if (strpos($file[0], 'image/png')) {
            $ext = '.png';
        }

        $file_path = '/images/' . $path . '/' . $file_name . $ext;
        Storage::put($file_path, base64_decode(end($file)));
        return $file_path;
    }


    /*
     * Set validation
     */
    public static function setValidate($request, $rule)
    {
        if (!$rule) {
            return;
        }
        $validator = Validator::make($request->all(), $rule);
        if ($validator->fails()) {
            $errors = '';
            foreach ($validator->errors()->messages() as $k => $v) {
                $errors[$k] = ['msg' => $v[0]];
            }
            return [
                'result' => 2,
                'error_code' => '400001',
                'error_message' => $errors,
            ];
        }
    }

    /*
     * Debug
     */
    public static function debug($msg)
    {
        if (env('APP_DEBUG')) {
            Log::debug(str_replace('//v1/', '', url()->current()), $msg);
        }
    }

    /*
     * データタイプ補完
     *
     * デフォルトでデイリーのデータが返る
     */
    public function complementType($prefix, Request $request)
    {
        return $prefix . ($request->type ?: 1);
    }

    /*
     * データ集計
     */
    public function aggregate($model)
    {
        $query = null;
        $data = [];

        switch (true) {
            case $model instanceof Installation:
                $data['summary']['total'] = $model::all()->count();
                $data['summary']['new'] = $model::whereDate('created_at', '=', Carbon::now()->toDateString())->count();
                $data['totals'] = $this->_selectTotals($model);
                $data['news'] = $this->_selectTotals($model, $cols = [], $conds = [], $new = self::DAILY);
                break;
            case $model instanceof Registration:
                $types = ["ALL", "TPC", "FACEBOOK"];
                foreach ($types as $k => $type) {
                    if ($type == 'ALL') {
                        $data[$type]['summary']['total'] = $model::count();
                        $data[$type]['summary']['new'] = $model::whereDate('created_at', '=', Carbon::now()->toDateString())->count();
                        $data[$type]['totals'] = $this->_selectTotals($model);
                        $data[$type]['news'] = $this->_selectTotals($model, $cols = [], $conds = [], $new = self::DAILY);
                    } else {
                        $conditions = [['type' => $type]];
                        $data[$type]['summary']['total'] = $model::where('type', $type)->count();
                        $data[$type]['summary']['new'] = $model::where('type', $type)->whereDate('created_at', '=', Carbon::now()->toDateString())->count();
                        $data[$type]['totals'] = $this->_selectTotals($model, $cols = [], $conds = $conditions);
                        $data[$type]['news'] = $this->_selectTotals($model, $cols = [], $conds = $conditions, $new = self::DAILY);
                    }
                }
                break;
            case $model instanceof PokeDollar:
            case $model instanceof Jewel:
                $data[self::PUBLISHED] = $this->_selectTotals($model, $cols = ['amount'], $conds = [['state' => self::PUBLISHED]]);
                $data[self::CONSUMED] = $this->_selectTotals($model, $cols = ['amount'], $conds = [['state' => self::CONSUMED]]);
                break;
            case $model instanceof Shade:
                $types = ["BRONZE", "SILVER", "GOLD", "PLATINUM"];
                foreach ($types as $type) {
                    $data[$type][self::PUBLISHED] = $this->_selectTotals($model, $cols = ['amount'], $conds = [['state' => self::PUBLISHED], ['type' => $type]]);
                    $data[$type][self::CONSUMED] = $this->_selectTotals($model, $cols = ['amount'], $conds = [['state' => self::CONSUMED], ['type' => $type]]);
                }
                break;
            case $model instanceof Battle:
                $types = ["RATE", "FREE", "FRIEND", "GYM"];
                foreach ($types as $type) {
                    $data[self::SUMMARY][$type] = $model::where('type', '=', $type)->count();
                    $data[$type] = $this->_selectTotals($model, $cols = [], $conds = [['type' => $type]]);
                }
                break;
            case $model instanceof Team:
                $data[self::SUMMARY][self::TOTAL] = $model::count();
                $data[self::SUMMARY][self::FOUNDED] = $model::where('state', '=', self::FOUNDED)->count();
                $data[self::SUMMARY][self::DISSOLVED] = $model::where('state', '=', self::DISSOLVED)->count();
                $data[self::TOTALS] = $this->_selectTotals($model, $cols = [], $conds = []);
                $data[self::FOUNDED] = $this->_selectTotals($model, $cols = [], $conds = [['state' => self::FOUNDED]]);
                $data[self::DISSOLVED] = $this->_selectTotals($model, $cols = [], $conds = [['state' => self::DISSOLVED]]);
                break;
            case $model instanceof UserScenario:
                $scenarios = Scenario::select('id', 'name')->orderBy('id')->get();
                foreach ($scenarios as $row) {
                    $data[self::SUMMARY][$row['id']] = $model::where('scenario_id', '=', $row['id'])->count();
                    $data[$row['id']] = $this->_selectTotals($model, $cols = [], $conds = [['scenario_id' => $row['id']]]);
                }
                break;
            case $model instanceof Card:
                $data[self::SUMMARY][self::NORMAL] = $model::count();
                $data[self::SUMMARY][self::PURCHASE] = $model::where('type', '=', self::PURCHASE)->count();
                $data[self::NORMAL] = $this->_selectTotalsUsingCase($model, $cols = ['rarity'], $colvals = [self::RARITIES], $conds = [], $new = self::YEARLY, $term = self::DAILY);
                $data[self::PURCHASE] = $this->_selectTotalsUsingCase($model, $cols = ['rarity'], $colvals = [self::RARITIES], $conds = [['type' => self::PURCHASE]], $new = self::YEARLY, $term = self::DAILY);
                break;
            default:
                break;
        }

        return $data;
    }

    /*
     * 累計データ取得
     *
     * $cols: array
     *   集計したいカラムを指定
     *   - 現状1カラムのみ対応
     * $conds: WHERE の条件
     *   $conds = [[key, val], [], ..., []]
     *     key: column name
     *     val: column value
     * $new:
     *   daily; 1日以内のデータのみ対象
     *   monthly: 1ヶ月以内のデータのみ対象
     *   yearly: 1年以内のデータのみ対象
     */
    private function _selectTotals($model, $cols = [], $conds = [], $new = '')
    {
        $totals = [];
        $unformated_totals = "";

        /*
         * 日付絞り込み
         */
        switch ($new) {
            case self::DAILY:
                $query_select = "DATE_FORMAT(created_at, '%Y%m%d') date";
                break;
            case self::MONTHLY:
                $query_select = "DATE_FORMAT(created_at, '%Y%m') date";
                break;
            case self::YEARLY:
                $query_select = "DATE_FORMAT(created_at, '%Y') date";
                break;
            default:
                $query_select = "DATE_FORMAT(created_at, '%Y%m%d') date";
                break;
        }

        /*
         * 集計カラム指定
         */
        if (empty($cols)) {
            $unformated_totals = $model::selectRaw($query_select . ", COUNT('id') cnt");
        } else {
            foreach ($cols as $k => $col) {
                $unformated_totals = $model::selectRaw($query_select . ", SUM(" . $col . ") sum" . $k);
            }
        }

        /*
         * 絞り込み条件付加
         */
        if (!empty($conds)) {
            foreach ($conds as $cond) {
                foreach ($cond as $column_name => $value) {
                    $unformated_totals->where($column_name, $value);
                }
            }
        }

        /*
         * 日付絞り込み
         */
        switch ($new) {
            case self::DAILY:
                $unformated_totals->whereBetween(
                    'created_at',
                    [
                        Carbon::today()->subDay(1),
                        Carbon::now()
                    ]
                )
                    ->groupBy('date');
                break;
            case self::MONTHLY:
                $unformated_totals->whereBetween(
                    'created_at',
                    [
                        Carbon::today()->subMonth(1),
                        Carbon::now()
                    ]
                )
                    ->groupBy('date');
                break;
            case self::YEARLY:
                $unformated_totals->whereBetween(
                    'created_at',
                    [
                        Carbon::today()->subYear(1),
                        Carbon::now()
                    ]
                )
                    ->groupBy('date');
                break;
            default:
                $unformated_totals->whereBetween(
                    'created_at',
                    [
                        Carbon::today()->subMonth(1),
                        Carbon::now()
                    ]
                )
                    ->groupBy('date');
                break;
        }

        foreach ($unformated_totals->get() as $k => $v) {
            $totals[$k] = Array(
                $v['date'],
                (int)$v['cnt'] ?: (int)$v['sum0']
            );
        }

        return $totals;
    }

    /*
     * 集計用メソッド
     *   カラムの値ごとに集計する
     *
     * $cols: array
     *   集計したいカラムを指定
     *   - 現状1カラムのみ対応
     * $collvals: 集計したカラムの値を配列で列挙
     *   e.g. $cols=[['val1', 'val2', ..., 'valN], ..., []]
     *     output => [[{sum_val1}, {sum_val2}, ..., {sum_valN}]
     * $conds: WHERE の条件
     *   $conds = [[key, val], [], ..., []]
     *     key: column name
     *     val: column value
     * $new:
     *   daily; 1日以内のデータのみ対象
     *   monthly: 1ヶ月以内のデータのみ対象
     *   yearly: 1年以内のデータのみ対象
     * $term: 集計日付間隔
     */
    private function _selectTotalsUsingCase($model, $cols = [], $colvals = [], $conds = [], $new = '', $term = '')
    {
        $query = $model;

        /*
         * 日付絞り込み
         */
        switch ($term) {
            case self::DAILY:
                $query_select = DB::raw("DATE_FORMAT(created_at, '%Y%m%d') date");
                break;
            case self::MONTHLY:
                $query_select = DB::raw("DATE_FORMAT(created_at, '%Y%m') date");
                break;
            case self::YEARLY:
                $query_select = DB::raw("DATE_FORMAT(created_at, '%Y') date");
                break;
            default:
                $query_select = DB::raw("created_at date");
                break;
        }

        /*
         * 集計カラム指定
         */
        if (empty($cols)) {
            ;
        } else {
            $query_rows = [];
            foreach ($cols as $k => $col) {
                array_push($query_rows, $query_select);
                foreach ($colvals[$k] as $colval) {
                    array_push($query_rows, DB::raw("CAST(sum(CASE WHEN " . $col . " = '" . $colval . "' THEN 1 ELSE 0 END) AS SIGNED) " . mb_strtolower($colval)));
                }
            }
        }

        /*
         * 絞り込み条件付加
         */
        if (!empty($conds)) {
            foreach ($conds as $cond) {
                foreach ($cond as $column_name => $value) {
                    $query->where($column_name, $value);
                }
            }
        }

        /*
         * 日付絞り込み
         */
        switch ($new) {
            case self::DAILY:
                $selected = $query->select($query_rows)
                    ->whereBetween(
                        'created_at',
                        [
                            Carbon::today()->subDay(1),
                            Carbon::now()
                        ]
                    )
                    ->groupBy('date');
                break;
            case self::MONTHLY:
                $selected = $query->select($query_rows)
                    ->whereBetween(
                        'created_at',
                        [
                            Carbon::today()->subMonth(1),
                            Carbon::now()
                        ]
                    )
                    ->groupBy('date');
                break;
            case self::YEARLY:
                $selected = $query->select($query_rows)
                    ->whereBetween(
                        'created_at',
                        [
                            Carbon::today()->subYear(1),
                            Carbon::now()
                        ]
                    )
                    ->groupBy('date');
                break;
            default:
                $selected = $query->select($query_rows)
                    ->whereDate('created_at', '=', Carbon::now()->toDateString())
                    ->groupBy('date');
                break;
        }

        $data = [];
        foreach ($selected->get() as $k => $record) {
            array_push($data, array_values($record['original']));
        }
        return $data;
    }

    /*
     * 集計データ取得用メソッド
     */
    public function selectAggregatedData($model, $type)
    {
        $selected = $model::select('date', 'data')->where('type', $type)->get();
        $data = [];
        foreach ($selected as $k => $record) {
            array_push($data, [$record['date'], $record['data']]);
        }
        return $data;
    }

    public function searchWaza($request, $query)
    {
        if ($request->keyword) {
            $query->where('name', 'LIKE', '%' . $request->keyword . '%');
        }

        if ($request->category) {
            $query->where('category', $request->category);
        }

        if ($request->status) {
            $status = explode(',', $request->status);
            $query->whereIn('status', $status);
        }
        return $this->query = $query;
    }

    public function saveWaza($request, $id, $type)
    {
        $arr = [];
        switch ($type) {
            case 'new':
                $arr = new Waza;
                if (!empty($request->updater_name)) {
                    $arr->register_name = $request->updater_name;
                    $arr->updater_name = $request->updater_name;
                }
                break;
            case 'update':
                $arr = Waza::where('id', $id)->first();
                if (!empty($request->updater_name)) {
                    $arr->updater_name = $request->updater_name;
                }
                break;
        }
        $arr->name = $request->name;
        $arr->damage = $request->damage;
        $arr->body = $request->attack_text;
        $arr->damage_text = $request->damage_text;
        $arr->waza_type = $request->waza_type;
        $arr->status = $request->status;
        $arr->category = $request->category;
        $arr->memo = $request->memo;
        $arr->energy_number = $request->energy_number;
        $arr->save();

        return $arr;
    }

    public function getWazaEnergies($waza_id)
    {
        $arr = [];
        $energies = WazasEnergies::select('energy_id', 'quantity')
            ->where('waza_id', $waza_id)
            ->get()
            ->toArray();
        if ($energies) {
            foreach ($energies as $k => $v) {
                if (!empty($v['energy_id'])) {
                    $arr[][config('setting.energies')[$v['energy_id']]] = $v['quantity'];
                }
            }
        }

        return $arr;
    }

    public function saveWazaEnergies($request, $waza_id)
    {
        $arr = [];
        foreach ($request->energies as $k => $v) {
            $arr = new WazasEnergies;
            $arr->waza_id = $waza_id;
            $arr->energy_id = array_search(key($v), config('setting.energies'));
            $arr->quantity = $v[key($v)];
            $arr->save();
        }

        return $arr;
    }

    public function getWazaLogics($request, $waza_id)
    {
        $arr = [];
        $logic = WazasLogics::select('json')
            ->where('waza_id', $waza_id)
            ->first();

        if ($logic) {
            $arr = json_decode($logic->json, true);
        }

        $ret_arr = [];
        if (empty($arr)) {
            $arr = [];
        }
        foreach ($arr as $hierarchy) {
            $ret_hierarchies = [];

            foreach ($hierarchy as $components) {
                $ret_item = [];

                $ret_components = [];

                $completed = null;
                $random = null;
                if ($components) {
                    if (array_key_exists("completed", $components)) {
                        $completed = $components["completed"];
                        unset($components["completed"]);
                    }
                    if (array_key_exists("random", $components)) {
                        $random = $components["random"];
                        unset($components["random"]);
                    }

                    foreach ($components as $factor_key => $factor) {
                        // 子要素探索再帰
                        // ロジックの中身がからの場合、子要素を探索しない
                        if (empty($factor)) continue;

                        $ret_factor = self::_diggChildren($request, $factor);

                        $ret_components = array_merge($ret_components, [$factor_key => $ret_factor]);
                    }
                }


                $ret_components["completed"] = $completed ?: true;
                $ret_components["random"] = $random ?: false;

                array_push($ret_hierarchies, $ret_components);
            }

            array_push($ret_arr, $ret_hierarchies);

        }
        return $ret_arr;
    }

    /*
     * 子要素が存在した場合、その下階層の子要素を探す。
     * 子要素が存在しなくなるまで続ける。
     */
    private function _diggChildren($request, $item)
    {
        try {
            $ret_item = $item;
            $added_option = [];
            $children = [];

            // 最も外側の項目のみ別処理
            if (in_array($item["value"], ["tri", "tar", "eff", "app"])) {
                $item = self::_addOptions($request, $item);
            }

            $item = self::_replaceEmptyValue($item);

            // 子要素が存在したら中を見にいく再帰
            if (self::_isDiggable($item)) {
                $children = $item["children"];
                $new_children = [];
                foreach ($children as $key => $child) {
                    $new_choices = [];

                    foreach ($child as $choices) {
                        $added_option = self::_diggChildren($request, $choices);

                        // option が存在しない階層に option をつける
                        $key_option = self::_dispatchKeyName($added_option["type"]);
                        if (!array_key_exists($key_option, $added_option)
                            and $added_option["type"] == 'selectbox'
                        ) {
                            $added_option = self::_addOptions($request, $added_option);
                        }

                        // 下階層までいったら、そこに option をつけたものを返す
                        array_push($new_choices, $added_option);
                    }


                    $new_children[$key] = $new_choices;
                }

                // option つき子要素で更新
                $item["children"] = $new_children;
            } else {
                return self::_addOptions($request, $item);
            }

            return $item;
        } catch (\Exception $e) {
            var_dump($item, $e->getMessage(), $e->getLine(), $e->getTrace());
        }
    }

    /*
     * value が null の項目に 空文字("") を代入する
     *
     * @param array $item
     * @return array
     */
    private function _replaceEmptyValue(array $item): array
    {
        $new_item = [];
        foreach ($item as $key => $value) {
            if (is_null($value)) {
                $new_item[$key] = "";
            } else {
                $new_item[$key] = $value;
            }
        }
        return $new_item;
    }

    /*
     * children が空の場合、空オブジェクトとして返す
     *
     * @param array $item
     * @return $array
     */
    private function _replaceEmptyChildren(array $item): array
    {
        // children は空オブジェクト
        if (empty($item["children"])) {
            $item["children"] = (object)[];
        };
        return $item;
    }

    /*
     * type ごとのキー名を返す
     * type により、フォームに属する選択肢のキー名が異なる
     * type:
     *   toggle: toggle
     *   selectbox: option
     *   checkbox: checkbox
     *   range: なし
     *   textarea: なし
     *
     * @param string $type
     * @return string type ごとのキー名
     */
    private function _dispatchKeyName(string $type)
    {
        switch ($type) {
            case "toggle":
                return "toggle";
            case "selectbox":
                return "option";
            case "checkbox":
                return "checkbox";
            default:
                return "";
        }
    }

    /*
     * 子要素が存在する場合 true
     */
    private function _isDiggable($item)
    {
        if (array_key_exists("children", $item)) {
            if (empty($item["children"])) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    /*
     * 与えられた選択肢と同階層の option を追加する
     */
    private function _addOptions($request, $item)
    {
        $item = self::_replaceEmptyChildren($item);
        $item = self::_replaceEmptyValue($item);

        if ($item["type"] != "selectbox") return $item;

        $value = $item["value"];
        switch ($value) {
            case "trigger":
                $value = "tri";
                break;
            case "target":
                $value = "tar";
                break;
            case "effect":
                $value = "eff";
                break;
            case "applying":
                $value = "app";
                break;
            default:
                break;
        }

        $form_part = FormPart::where('value', $value)
            ->first();
        try {
            $options = FormOption::distinct()->where('form_parts_value', $form_part->value)
                ->pluck('value');
        } catch (\Exception $e) {
//            var_dump($value, $form_part, $item, $e->getMessage(), $e->getLine(), $e->getTrace());
            //dd("$value is not found in form_parts value", $value, $form_part, $item, $e->getMessage(), $e->getLine());
            return $item;
        }

        // 返戻言語指定
        $lang = '';
        if (empty($request->lang)) {
            $lang = 'ja';
        } else {
            $lang = $request->lang;
        }

        $new_options = [];
        foreach ($options as $option) {
            $translated = Locale::where('code', $option)
                ->where('lang', $lang)
                ->value('name');

            $new_option = [];
            $new_option["value"] = $this->format_response_value($option);
            $new_option["body"] = $translated;
            array_push($new_options, $new_option);
        }

        $ret_item = $item;
        $ret_item["option"] = $new_options;
        return $ret_item;
    }

    public function saveWazaLogics($request, $waza_id)
    {
        $arr = new WazasLogics;
        $arr->waza_id = $waza_id;
        $arr->json = json_encode($request->logics, true);
        $arr->save();

        return $arr;
    }

    public function deleteRecord($model, $id, $type)
    {
        switch ($type) {
            case 'energy':
            case 'logic':
                $model::where('waza_id', $id)->delete();
                break;
            default:
                $model::where('id', $id)->delete();
        }
    }

    /*
     * Format response value
     * 先頭4文字でカテゴリ判定しているが、API返戻時は数字のみ。
     *
     * @param $value string
     * @return string
     */
    public function format_response_value($value)
    {
        $excepted_value = ['obj', 'prb'];
        if (in_array(substr($value, 0, 3), $excepted_value)) {
            return $value;
        } else {
            return substr($value, 4, strlen($value));
        }
    }
}
