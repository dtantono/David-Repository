<?php

namespace App\Http\Controllers;

use App\Models\FormOption;
use App\Models\FormOptionsClassifications;
use App\Models\FormPart;
use App\Models\Locale;
use App\Models\WazaChoices;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class CsvController extends Controller
{

    const COL_NUM_CODE = 6;
    const COL_NUM_PARENT_CODE = 7;
    const COL_NUM_LABEL_CODE = 9;
    const COL_NUM_CHOICE = 26;
    const COL_NUM_TYPE = 27;
    const COL_NUM_LABEL = 28;
    const COL_NUM_MASTER = 29;
    const COL_NUM_END = 30;
    const COL_NUM_WAZA = 31;  // ワザ
    const COL_NUM_ABILITY = 32;  // 特性
    const COL_NUM_TI = 33;  // TI(グッズ)
    const COL_NUM_TT = 34;  // TT(ポケモンのどうぐ)
    const COL_NUM_TS = 35;  // TS(サポーター)

    const FORM_TYPE_TEXTAREA = 4;

    private function saveLogicMaster($code, $master_id, $label_code = null, $form_type = 1, $code_suffix = '')
    {
        switch ($master_id) {
            case 'E1M':
            case 'E2M':
            case 'E3M':
            case 'E4M':
            case 'OP1M':
            case 'OP2M':
            case 'OP4M':
            case 'OP6M':
            case 'OP7M':
            case 'Oth3M':
            case 'PP1M':
            case 'PP2M':
            case 'PP3M':
            case 'PP4M':
            case 'PP5M':
            case 'PP6M':
            case 'PP7M':
            case 'PP8M':
            case 'PP10':
            case 'PP10M':
            case 'T1M':
            case 'T3M':
                /*=============================================
                    *	         Form Parts store
                =============================================*/
                $obj2 = new FormPart;
                $obj2->value = $code . $master_id;
                $obj2->form_type_id = 6;
                $obj2->form_range_id = 1;
                $obj2->end = 'false';
                $obj2->label = $label_code;
                $obj2->save();

                /*=============================================
                    *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = $code . $master_id;
                $obj->save();

                foreach (config('logic.' . $master_id) as $k => $v) {
                    /*=============================================
                    *	         Form Options store
                    =============================================*/

                    $form_option = new FormOption;
                    $form_option->form_parts_value = $code . $master_id;
                    $form_option->value = $code . $master_id . $v['code'];
                    $form_option->end = 'true';
                    $form_option->save();

                    /*=============================================
                    *	         Locales store
                    =============================================*/
                    $obj3 = new Locale;
                    //code
                    $obj3->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj3->name = $v['name'];
                    $obj3->lang = 'ja';
                    $obj3->save();

                    $obj4 = new Locale;
                    //code
                    $obj4->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj4->name = $v['name'];
                    $obj4->lang = 'en';
                    $obj4->save();
                }
                break;
            case 'E1':
            case 'PP1':
            case 'PP2':
            case 'PP3':
            case 'PP4':
            case 'PP5':
            case 'PP6':
            case 'PP7':
            case 'PP8':
            case 'PP9':
            case 'OP1':
            case 'OP2':
            case 'OP3':
            case 'OP4':
            case 'OP5':
            case 'OP6':
            case 'OP7':
            case 'OP8':
            case 'OP9':
            case 'OP10':
            case 'T1':
            case 'T2':
            case 'Oth3':
            case 'Oth4':
                /*=============================================
                    *	         Form Parts store
                =============================================*/
                $obj2 = new FormPart;
                $obj2->value = $code . $code_suffix . $master_id;
                $obj2->form_type_id = $form_type;
                $obj2->form_range_id = 1;
                $obj2->end = 'false';
                $obj2->label = $label_code;
                $obj2->save();

                /*=============================================
                    *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = $code . $code_suffix . $master_id;
                $obj->save();

                foreach (config('logic.' . $master_id) as $k => $v) {
                    /*=============================================
                    *	         Form Options store
                    =============================================*/

                    $form_option = new FormOption;
                    $form_option->form_parts_value = $code . $code_suffix . $master_id;
                    $form_option->value = $code . $code_suffix . $master_id . $v['code'];
                    $form_option->end = 'true';
                    $form_option->save();

                    /*=============================================
                    *	         Locales store
                    =============================================*/
                    $obj3 = new Locale;
                    //code
                    $obj3->code = $code . $code_suffix . $master_id . $v['code'];
                    //選択肢
                    $obj3->name = $v['name'];
                    $obj3->lang = 'ja';
                    $obj3->save();

                    $obj4 = new Locale;
                    //code
                    $obj4->code = $code . $code_suffix . $master_id . $v['code'];
                    //選択肢
                    $obj4->name = $v['name'];
                    $obj4->lang = 'en';
                    $obj4->save();
                }
                break;
            case 'E2':
                /*=============================================
                *	         Form Parts store
                =============================================*/
                $obj2 = new FormPart;
                $obj2->value = $code . $master_id;
                $obj2->form_type_id = $form_type;
                $obj2->form_range_id = 1;
                $obj2->end = 'true';
                $obj2->label = $label_code;
                $obj2->save();

                /*=============================================
                    *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = $code . $master_id;
                $obj->save();

                foreach (config('logic.' . $master_id) as $k => $v) {

                    /*=============================================
                    *	         Form Options store
                    =============================================*/
                    $end = '';
                    switch ($k) {
                        case 0:
                            $end = 'false';
                            break;
                        case 1:
                            $end = 'true';
                            break;
                    }

                    $form_option = new FormOption;
                    $form_option->form_parts_value = $code . $master_id;
                    $form_option->value = $code . $master_id . $v['code'];
                    $form_option->end = $end;
                    $form_option->save();


                    /*=============================================
                    *	         Locales store
                    =============================================*/
                    $obj3 = new Locale;
                    //code
                    $obj3->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj3->name = $v['name'];
                    $obj3->lang = 'ja';
                    $obj3->save();

                    $obj4 = new Locale;
                    //code
                    $obj4->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj4->name = $v['name'];
                    $obj4->lang = 'en';
                    $obj4->save();
                }

                $this->saveLogicMaster($code . $master_id . '01', 'OP2', $label_code);

                break;
            case 'Oth1':
                /*=============================================
                *	         Form Parts store
                =============================================*/
                $obj2 = new FormPart;
                $obj2->value = $code . $master_id;
                $obj2->form_type_id = $form_type;
                $obj2->form_range_id = 1;
                $obj2->end = 'false';
                $obj2->label = $label_code;
                $obj2->save();

                $obj2_perfectf_match_text_area_suffix = '0101';
                $obj2_perfectf_match_text_area = new FormPart;
                $obj2_perfectf_match_text_area->value = $code . $master_id . $obj2_perfectf_match_text_area_suffix;
                $obj2_perfectf_match_text_area->form_type_id = self::FORM_TYPE_TEXTAREA;
                $obj2_perfectf_match_text_area->form_range_id = 1;
                $obj2_perfectf_match_text_area->end = 'true';
                $obj2_perfectf_match_text_area->label = $label_code . $obj2_perfectf_match_text_area_suffix;
                $obj2_perfectf_match_text_area->save();

                $obj2_partial_match_text_area_suffix = '0201';
                $obj2_partial_match_text_area = new FormPart;
                $obj2_partial_match_text_area->value = $code . $master_id . $obj2_partial_match_text_area_suffix;
                $obj2_partial_match_text_area->form_type_id = self::FORM_TYPE_TEXTAREA;
                $obj2_partial_match_text_area->form_range_id = 1;
                $obj2_partial_match_text_area->end = 'true';
                $obj2_partial_match_text_area->label = $label_code . $obj2_partial_match_text_area_suffix;
                $obj2_partial_match_text_area->save();

                /*=============================================
                *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = $code . $master_id;
                $obj->save();

                $choice_perfect_match = new WazaChoices;
                $choice_perfect_match->code = $code . $master_id . '01';
                $choice_perfect_match->child_code = $code . $master_id . $obj2_perfectf_match_text_area_suffix;
                $choice_perfect_match->save();

                $choice_partial_match = new WazaChoices;
                $choice_partial_match->code = $code . $master_id . '02';
                $choice_partial_match->child_code = $code . $master_id . $obj2_partial_match_text_area_suffix;
                $choice_partial_match->save();

                foreach (config('logic.' . $master_id) as $k => $v) {

                    /*=============================================
                    *	         Form Options store
                    =============================================*/
                    $end = '';
                    switch ($k) {
                        case 0:
                            $end = 'false';
                            break;
                        case 1:
                            $end = 'true';
                            break;
                    }

                    $form_option = new FormOption;
                    $form_option->form_parts_value = $code . $master_id;
                    $form_option->value = $code . $master_id . $v['code'];
                    $form_option->end = $end;
                    $form_option->save();

                    /*=============================================
                    *	         Locales store
                    =============================================*/
                    $obj3 = new Locale;
                    //code
                    $obj3->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj3->name = $v['name'];
                    $obj3->lang = 'ja';
                    $obj3->save();

                    $obj4 = new Locale;
                    //code
                    $obj4->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj4->name = $v['name'];
                    $obj4->lang = 'en';
                    $obj4->save();
                }

                break;
            case 'Oth2':
                /*=============================================
                *            Waza Choices store
                =============================================*/
                $waza_choice = new WazaChoices;
                $waza_choice->code = $code;
                $waza_choice->child_code = 'prb-01';
                $waza_choice->save();

                $waza_choice = new WazaChoices;
                $waza_choice->code = $code;
                $waza_choice->child_code = 'prb-02';
                $waza_choice->save();

                break;
            case 'T3':
                /*=============================================
                *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = $code . $master_id;
                $obj->save();

                /*=============================================
                *	         Form Parts store
                =============================================*/
                $obj2 = new FormPart;
                $obj2->value = $code . $master_id;
                $obj2->form_type_id = $form_type;
                $obj2->form_range_id = 1;
                $obj2->end = 'true';
                $obj2->label = $label_code;
                $obj2->save();
                foreach (config('logic.' . $master_id) as $k => $v) {
                    /*=============================================
                    *	         Form Options store
                    =============================================*/
                    $end = '';
                    switch ($k) {
                        case 8:
                            $end = 'false';
                            break;
                        default :
                            $end = 'true';
                    }

                    $form_option = new FormOption;
                    $form_option->form_parts_value = $code . $master_id;
                    $form_option->value = $code . $master_id . $v['code'];
                    $form_option->end = $end;
                    $form_option->save();

                    /*=============================================
                    *	         Locales store
                    =============================================*/
                    $obj3 = new Locale;
                    //code
                    $obj3->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj3->name = $v['name'];
                    $obj3->lang = 'ja';
                    $obj3->save();

                    $obj4 = new Locale;
                    //code
                    $obj4->code = $code . $master_id . $v['code'];
                    //選択肢
                    $obj4->name = $v['name'];
                    $obj4->lang = 'en';
                    $obj4->save();
                }

                $this->saveLogicMaster($code . $master_id . '09', 'OP2', $label_code);

                break;
            case 'O1':
                /*=============================================
                *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = 'obj-01';
                $obj->save();
                break;
            case 'O2':
                /*=============================================
                *	         Waza Choices store
                =============================================*/
                $obj = new WazaChoices;
                //parent code
                $obj->code = $code;
                //code
                $obj->child_code = 'obj-02';
                $obj->save();
                break;
            case 'Tr4':
                /*=============================================
                *	         Waza Choices store
                =============================================*/
                //code
                $children_code = [
                    'tri-010501',
                    'tri-010502'
                ];
                foreach ($children_code as $child_code) {
                    $obj = new WazaChoices;
                    //parent code
                    $obj->code = 'tri-010601030203';

                    $obj->child_code = $child_code;
                    $obj->save();
                }

                break;
        }

    }

    public function store(Request $request)
    {
        $sheet_arr = [];
        $prefix_arr = [];

        if ($request->trigger_csv) {
            $sheet_arr[0] = file($request->trigger_csv);
            array_push($prefix_arr, 'tri');
        }
        if ($request->target_csv) {
            $sheet_arr[1] = file($request->target_csv);
            array_push($prefix_arr, 'tar');
        }
        if ($request->effect_csv) {
            $sheet_arr[2] = file($request->effect_csv);
            array_push($prefix_arr, 'eff');
        }
        if ($request->object_csv) {
            $sheet_arr[3] = file($request->object_csv);
            array_push($prefix_arr, 'obj');
        }
        if ($request->probability_csv) {
            $sheet_arr[4] = file($request->probability_csv);
            array_push($prefix_arr, 'prb');
        }
        if ($request->applying_csv) {
            $sheet_arr[5] = file($request->applying_csv);
            array_push($prefix_arr, 'app');
        }

        $row_arr = [];
        if (!$sheet_arr) return $this->json;

        self::_deleteLimitedRecords($prefix_arr);
        DB::table('form_options_classifications')->truncate();

        foreach ($sheet_arr as $k => $v) {
            if (!$v) continue;

            unset($v[0]);
            foreach ($v as $k2 => $v2) {
                $row_arr[$k2] = explode(',', $v2);
            }

            if (!$row_arr) continue;
            foreach (array_values($row_arr) as $k3 => $v3) {
                $code = $v3[self::COL_NUM_CODE];
                $parent_code = $v3[self::COL_NUM_PARENT_CODE];
                $label_code = $v3[self::COL_NUM_LABEL_CODE];
                $choice = str_replace(["\r\n", "\r", "\n"], '', $v3[self::COL_NUM_CHOICE]);
                if (empty($v3[self::COL_NUM_TYPE])) {
                    dd($v3);
                }
                $type = str_replace(["\r\n", "\r", "\n"], '', $v3[self::COL_NUM_TYPE]);
                $master = str_replace(["\r\n", "\r", "\n"], '', $v3[self::COL_NUM_MASTER]);
                $label = str_replace(["\r\n", "\r", "\n"], '', $v3[self::COL_NUM_LABEL]);
                $end = str_replace(["\r\n", "\r", "\n"], '', $v3[self::COL_NUM_END]);

                if ($k == 2) {
                    $classifications = [
                        $v3[self::COL_NUM_WAZA],
                        $v3[self::COL_NUM_ABILITY],
                        $v3[self::COL_NUM_TI],
                        $v3[self::COL_NUM_TT],
                        $v3[self::COL_NUM_TS]
                    ];
                }

                /*=============================================
                *		         Master store
                =============================================*/

                if ($master !== '') {
                    $arr_master = explode('|', $master);
                    $arr_label = explode('|', $label);
                    foreach ($arr_master as $k4 => $v4) {
                        // マスタ名が重複している場合、コードが一意になるよう調整
                        foreach (array_count_values($arr_master) as $master_name => $count) {
                            if ($count >= 2) {
                                $index = 1;
                                while ($index <= $count) {
                                    $code_suffix = '-' . $index;
                                    $this->saveLogicMaster($code, $v4, $label_code . $code_suffix . $v4, $form_type = 1, $code_suffix = '-' . $index);
                                    $index++;
                                }
                            } else {
                                if ($v4 != $master_name) continue;
                                $this->saveLogicMaster($code, $v4, $label_code . $v4);
                            }
                        }
                    }
                }


                /*=============================================
                *		         Waza Choice
                =============================================*/
                $waza_choice = new WazaChoices;
                if ($parent_code !== '') {
                    //parent code
                    $waza_choice->code = $parent_code;
                }
                if ($code !== '') {
                    //code
                    $waza_choice->child_code = $code;
                }

                $waza_choice->save();

                /*=============================================
                *		         Form Part
                =============================================*/

                if ($type != 'option') {
                    $form_part = new FormPart;
                    $form_part->save();
                }

                /*=============================================
                *		         Code store
                =============================================*/
                if ($code !== '' && $choice !== 'N/A') {
                    //code
                    if ($type != 'option') {
                        $form_part->value = $code;
                    }

                    $locale = new Locale;
                    //code
                    $locale->code = $code;
                    //選択肢
                    $locale->name = $choice;
                    $locale->lang = 'ja';
                    $locale->save();

                    $locale = new Locale;
                    //code
                    $locale->code = $code;
                    //選択肢
                    $locale->name = $choice;
                    $locale->lang = 'en';
                    $locale->save();
                }

                /*=============================================
                *		         Label store
                =============================================*/
                if ($master == '') {
                    if ($label_code !== '' && $label !== 'N/A') {
                        //label code
                        if ($type != 'option') {
                            $form_part->label = $label_code;
                        }

                        //check label record
                        $check_label = Locale::where('code', $label_code)
                            ->first();

                        if (empty($check_label)) {

                            $locale = new Locale;
                            //label code
                            $locale->code = $label_code;
                            //選択肢
                            $locale->name = $label;
                            $locale->lang = 'ja';
                            $locale->save();

                            $locale = new Locale;
                            //label code
                            $locale->code = $label_code;
                            //選択肢
                            $locale->name = $label;
                            $locale->lang = 'en';
                            $locale->save();
                        }
                    }
                } else {
                    $arr_master = explode('|', $master);
                    $arr_label = explode('|', $label);

                    $stored_master = '';
                    foreach ($arr_master as $k5 => $v6) {

                        // マスタ名が重複している場合、コードが一意になるよう調整
                        foreach (array_count_values($arr_master) as $master_name => $count) {
                            if ($count >= 2) {

                                if ($v6 != $master_name) continue;
                                if ($master_name == $stored_master) continue;

                                $index = 1;

                                while ($index <= $count) {
                                    $code_suffix = '-' . $index;

                                    if ($type != 'option') {
                                        $form_part->label = $label_code . $v6;
                                    }
                                    //check label record
                                    $check_label = Locale::where('code', $label_code . $v6)
                                        ->first();
                                    if (empty($check_label)) {

                                        $locale = new Locale;
                                        //label code
                                        $locale->code = $label_code . $code_suffix . $v6;
                                        //選択肢
                                        $locale->name = $arr_label[$index - 1];
                                        $locale->lang = 'ja';
                                        $locale->save();

                                        $locale = new Locale;
                                        //label code
                                        $locale->code = $label_code . $code_suffix . $v6;
                                        //選択肢
                                        $locale->name = $arr_label[$index - 1];
                                        $locale->lang = 'en';
                                        $locale->save();
                                    }

                                    $stored_master = $master_name;
                                    $index++;
                                }
                            } else {
                                if ($type != 'option') {
                                    $form_part->label = $label_code . $v6;
                                }
                                //check label record
                                $check_label = Locale::where('code', $label_code . $v6)
                                    ->first();
                                if (empty($check_label)) {

                                    $locale = new Locale;
                                    //label code
                                    $locale->code = $label_code . $v6;
                                    //選択肢
                                    $locale->name = $arr_label[$k5];
                                    $locale->lang = 'ja';
                                    $locale->save();

                                    $locale = new Locale;
                                    //label code
                                    $locale->code = $label_code . $v6;
                                    //選択肢
                                    $locale->name = $arr_label[$k5];
                                    $locale->lang = 'en';
                                    $locale->save();
                                }
                            }
                        }
                    }
                }

                /*=============================================
                *		         End store
                =============================================*/
                if ($end !== '' && $type != 'option') {
                    //end
                    $form_part->end = mb_strtolower($end);
                }

                /*=============================================
                *		         Form Type store
                =============================================*/
                //form_range_id

                switch ($master) {
                    case 'V8':
                        $form_range_id = 8;
                        break;
                    case 'V2':
                        $form_range_id = 2;
                        break;
                    case 'V3':
                        $form_range_id = 3;
                        break;
                    case 'V4':
                        $form_range_id = 4;
                        break;
                    case 'V5':
                        $form_range_id = 9;
                        break;
                    case 'V6':
                        $form_range_id = 5;
                        break;
                    case 'V7':
                        $form_range_id = 6;
                        break;
                    case 'V9':
                        $form_range_id = 7;
                        break;
                    case 'V1':
                        $form_range_id = 10;
                        break;
                    case 'V10':
                        $form_range_id = 11;
                        break;
                    case 'V11':
                        $form_range_id = 12;
                        break;
                    case 'V94':
                        $form_range_id = 94;
                        break;
                    case 'V95':
                        $form_range_id = 95;
                        break;
                    case 'V96':
                        $form_range_id = 96;
                        break;
                    case 'V97':
                        $form_range_id = 97;
                        break;
                    case 'V98':
                        $form_range_id = 98;
                        break;
                    case 'V99':
                        $form_range_id = 99;
                        break;
                    default:
                        $form_range_id = 1;
                }
                if ($type != 'option') {
                    $form_part->form_range_id = $form_range_id;
                }

                if ($type !== '') {
                    //type
                    switch ($type) {
                        case 'selectbox':
                            $form_part->form_type_id = 1;
                            break;
                        case 'range':
                            $form_part->form_type_id = 2;
                            break;
                        case 'toggle':
                            $form_part->form_type_id = 3;
                            break;
                        case 'textarea':
                            $form_part->form_type_id = 4;
                            break;
                        case 'option':
                            $form_option = new FormOption;
                            $form_option->form_parts_value = $parent_code;
                            $form_option->value = $code;
                            $form_option->end = mb_strtolower($end);
                            $form_option->save();

                            if ($k == 2) {
                                // カード種別分類登録
                                foreach ($classifications as $index => $classification) {
                                    if ($classification == 0) continue;

                                    $form_options_classifications = new FormOptionsClassifications();
                                    $form_options_classifications->form_option_id = $form_option->id;
                                    $form_options_classifications->classification_id = config('classifications')['id'][$index];
                                    $form_options_classifications->type = $classification;
                                    $form_options_classifications->save();
                                }
                            }

                            break;
                        case 'checkbox':
                            $form_part->form_type_id = 6;
                            break;
                    }
                }
                if ($type != 'option') {
                    $form_part->save();
                }
            }
        }

        return $this->json;
    }

    /*
     * Hard delete specific records
     *
     * @param array $prefix_arr tri or tar or eff or obj
     * @return void
     */
    private function _deleteLimitedRecords(array $prefix_arr)
    {
        $tables = [
            'waza_choices' => 'code',
            'form_parts' => 'value',
            'form_options' => 'form_parts_value',
            'locales' => 'code'
        ];

        if (empty($prefix_arr)) return;

        foreach ($prefix_arr as $prefix) {
            foreach ($tables as $table => $col) {
                DB::table($table)
                    ->where($col, 'LIKE', '%' . $prefix . '%')
                    ->delete();
            }
        }

        /*DB::table('waza_choices')->truncate();
        DB::table('form_parts')->truncate();
        DB::table('form_options')->truncate();
        DB::table('locales')->truncate();*/
    }

}
