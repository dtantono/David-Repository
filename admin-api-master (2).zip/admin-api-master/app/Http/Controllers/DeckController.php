<?php

namespace App\Http\Controllers;

use App\Models\Deck;
use App\Models\DeckCard;
use Illuminate\Http\Request;

class DeckController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $card_types = Deck::query();

        if ($request->search) {
            $card_types->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->search . '%')
                    ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->ids) {
            $card_types->whereIn('id', explode(',', $request->ids));
        }

        if ($request->publish_status) {
            $card_types->where('publish_status', $request->publish_status);
        }

        $per_page = 10;
        if ($request->per_page) {
            $per_page = $request->per_page;
        }

        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $card_types->orderBy($sort_column, $sort);

        if ($request->csv) {
            return $card_types->get();
        }
        return $card_types->paginate($per_page);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $deck = new Deck();
        $deck->name = $request->name;
        $deck->publish_status = $request->publish_status;
        $deck->description = $request->description;
        if (!empty($request->updater_name)) {
            $deck->register_name = $request->updater_name;
            $deck->updater_name = $request->updater_name;
        }
        $deck->save();

        foreach ($request->card_ids as $key => $card_id) {
            $deck_card = new DeckCard();
            $deck_card->deck_id = $deck->id;
            $deck_card->card_id = $card_id;
            $deck_card->card_no = $request->card_nos[$key];
            $deck_card->save();
            $response[] = clone $deck_card;
        }

        return $deck;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Deck $deck
     * @return \Illuminate\Http\Response
     */
    public function show(Deck $deck)
    {
        $deck_card = DeckCard::where('deck_id', $deck->id)->get();
        $card_ids = [];
        $card_nos = [];

        foreach ($deck_card as $key => $value) {
            $card_ids[] = $value->card_id;
            $card_nos[] = $value->card_no;
        }

        $deck['card_ids'] = $card_ids;
        $deck['card_nos'] = $card_nos;

        return $deck;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Deck $deck
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Deck $deck)
    {
        $deck->name = $request->name;
        $deck->publish_status = $request->publish_status;
        $deck->description = $request->description;
        if (!empty($request->updater_name)) {
            $deck->updater_name = $request->updater_name;
        }
        $deck->save();

        DeckCard::where('deck_id', $deck->id)->delete();

        foreach ($request->card_ids as $key => $card_id) {
            $deck_card = new DeckCard();
            $deck_card->deck_id = $deck->id;
            $deck_card->card_id = $card_id;
            $deck_card->card_no = $request->card_nos[$key];
            $deck_card->save();
            $response[] = clone $deck_card;
        }
        return $deck;
    }
}
