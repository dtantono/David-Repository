<?php

namespace App\Http\Controllers;

use App\Models\Card;
use App\Models\CodeMaster;
use App\Models\Deck;
use App\Models\DeckCard;

class DeckJsonController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $deck = Deck::where('id', $id)->first();

        if (!$deck) {
            return [];
        }

        $table = CodeMaster::get();
        $code_masters = [];
        foreach ($table as $key => $v) {
            $code_masters[$v->type_name][$v->code] = $v->name;
        }

        $deck_cards = DeckCard::where('deck_id', $deck->id)->get();
        $ids = [];
        $nos = [];
        $total = 0;
        foreach ($deck_cards as $deck_card) {
            $ids[] = $deck_card->card_id;
            $nos[$deck_card->card_id] = $deck_card->card_no;
            $total += $deck_card->card_no;
        }
        // カードテンプレートJSON読み込み
        $template = json_decode(file_get_contents(app_path('Console/Commands/template/deck.json')));

        $cards = Card::whereIn('id', $ids)->get();

        $template->data->deck->id = (int)$deck->id;
        $template->data->deck->deck_name = $deck->name;
        $template->data->deck->deck_total = $total;
        $template->data->deck->deck_card = [];
        $template->data->deck->evolution_list = [];

        $card_data = [];
        foreach ($cards as $card) {
            if (!empty($nos[$card->id])) {
                $card_data['card_id'] = $card->card_id;
                $card_data['card_type']['large'] = (int)$card->card_type_large;
                $card_data['card_type']['middle'] = (int)$card->card_type_middle;
                $card_data['card_type']['small'] = (int)$card->card_type_small;
                $card_data['name'] = $card->name;
                $card_data['energy_type'] = $card->energy_type;
                $card_data['value'] = $nos[$card->id];
                $template->data->deck->deck_card[] = $card_data;
                //$template->data->deck->evolution_list = json_decode($card->evolution_map);
            }
        }


        return response()->json($template);
    }
}
