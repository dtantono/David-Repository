<?php

namespace App\Http\Controllers;

use App\Models\Expansion;
use Illuminate\Http\Request;

class ExpansionController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $expansions = Expansion::query();

        if ($request->search) {
            $expansions->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->search . '%')
                    ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->ids) {
            $expansions->whereIn('id', explode(',',$request->ids));
        }

        if ($request->publish_status) {
            $expansions->where('publish_status', $request->publish_status);
        }

        $per_page = 10;
        if ($request->per_page) {
            $per_page = $request->per_page;
        }

        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $expansions->orderBy($sort_column, $sort);

        if ($request->csv) {
            return $expansions->get();
        }
        return $expansions->paginate($per_page);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $expansion = new Expansion();
        $expansion->name = $request->name;
        $expansion->publish_status = $request->publish_status;
        $expansion->description = $request->description;
        if (!empty($request->updater_name)) {
            $expansion->register_name = $request->updater_name;
            $expansion->updater_name = $request->updater_name;
        }
        $expansion->save();
        return $expansion;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Expansion  $expansion
     * @return \Illuminate\Http\Response
     */
    public function show(Expansion $expansion)
    {
        return $expansion;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Expansion  $expansion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Expansion $expansion)
    {
        $expansion->name = $request->name;
        $expansion->publish_status = $request->publish_status;
        $expansion->description = $request->description;
        if (!empty($request->updater_name)) {
            $expansion->updater_name = $request->updater_name;
        }
        $expansion->save();
        return $expansion;
    }
}
