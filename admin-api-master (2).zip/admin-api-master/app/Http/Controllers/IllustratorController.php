<?php

namespace App\Http\Controllers;

use App\Models\Illustrator;
use Illuminate\Http\Request;

class IllustratorController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $illustrators = Illustrator::query();

        if ($request->search) {
            $illustrators->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->search . '%')
                    ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->ids) {
            $illustrators->whereIn('id', explode(',', $request->ids));
        }

        if ($request->publish_status) {
            $illustrators->where('publish_status', $request->publish_status);
        }

        $per_page = 10;
        if ($request->per_page) {
            $per_page = $request->per_page;
        }

        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $illustrators->orderBy($sort_column, $sort);

        if ($request->csv) {
            return $illustrators->get();
        }
        return $illustrators->paginate($per_page);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $count = Illustrator::where('name', $request->name)->count();

        if ($count > 0) {
            return $this->json = [
                'result' => 2,
                'error_code' => '500',
                'error_message' => '既に登録されている名前です。'
            ];
        }

        $illustrator = new Illustrator();
        $illustrator->name = $request->name;
        $illustrator->publish_status = $request->publish_status;
        $illustrator->description = $request->description;
        if (!empty($request->updater_name)) {
            $illustrator->register_name = $request->updater_name;
            $illustrator->updater_name = $request->updater_name;
        }
        $illustrator->save();
        return $illustrator;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Illustrator $illustrator
     * @return \Illuminate\Http\Response
     */
    public function show(Illustrator $illustrator)
    {
        return $illustrator;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Illustrator $illustrator
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Illustrator $illustrator)
    {
        $count = Illustrator::where('name', $request->name)->where('id', '<>', $illustrator->id)->count();

        if ($count > 0) {
            return $this->json = [
                'result' => 2,
                'error_code' => '500',
                'error_message' => '既に登録されている名前です。'
            ];
        }

        $illustrator->name = $request->name;
        $illustrator->publish_status = $request->publish_status;
        $illustrator->description = $request->description;
        if (!empty($request->updater_name)) {
            $illustrator->updater_name = $request->updater_name;
        }
        $illustrator->save();
        return $illustrator;
    }
}
