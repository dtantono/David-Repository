<?php

namespace App\Http\Controllers;

use App\Models\Card;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ImageController extends Controller
{

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return Storage::disk('s3')->download($request->name);
    }

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function card(Request $request, $card_id)
    {
        $ip_lists = json_decode(env('AUTHORIZED_IP'));
        $request::setTrustedProxies([$request->ip()], Request::HEADER_X_FORWARDED_ALL);

        if (!in_array($request->ip(), $ip_lists)) {
            return abort(403, 'Unauthorized action.');
        }

        $card = Card::where('card_id', $card_id)
            ->whereIn('publish_status', [1, 2, 3, 4])
            ->orderBy('publish_status', 'DESC')
            ->orderBy('updated_at', 'DESC')
            ->first();
        if (!empty($card->card_image_path)) {
            return Storage::disk('s3')->download($card->card_image_path);
        } else {
            return 'no_image';
        }
    }
}
