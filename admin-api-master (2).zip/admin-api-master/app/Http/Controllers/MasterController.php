<?php

namespace App\Http\Controllers;

use App\Models\FormOption;
use App\Models\FormType;
use DB;
use Illuminate\Http\Request;

use App\Models\FormPart;
use App\Models\FormRange;
use App\Http\Helper;
use App\Models\Master;
use App\Models\WazaChoices;
use Mockery\Exception;

class MasterController extends Controller
{

    /*
     * Fetch master data.
     *
     * @param Request $request
     * @param int $code Master table code.
     * @return json Master data.
     */
    public function index(Request $request, $code)
    {
        // マスタテーブルコードを渡すと、コードに紐づくテーブルのデータを取得して返す
        try {
            $data = [];

            switch ($code) {
                case 3:
                    $lang = $request->lang;
                    $category = $request->cat;

                    $choices = [];
                    $prefix = '';  // tri/tar/eff
                    switch ($category) {
                        case 'trigger':
                            $prefix = 'tri-';
                            break;
                        case 'target':
                            $prefix = 'tar-';
                            break;
                        case 'effect':
                            $prefix = 'eff-';
                            break;
                        case 'applying':
                            $prefix = 'app-';
                            break;
                        default:
                            break;
                    }

                    // Object, Probability の場合、prefix をつけず、id をそのまま使用する
                    $excepted_prefix = ['obj', 'prb'];
                    if (in_array(substr($request->id, 0, 3), $excepted_prefix)) $prefix = '';


                    switch ($request->id) {
                        case '':
                            $requested_code = $category;
                            break;
                        default:
                            $requested_code = $prefix . $request->id;
                            break;
                    }

                    $waza_choice = new WazaChoices();
                    $form_part = new FormPart();
                    $form_option = new FormOption();
                    $form_type = new FormType();
                    $form_range = new FormRange();

                    $children_codes = $waza_choice->where('code', $requested_code)
                        ->pluck('child_code');

                    $parent_value_arr = [];
                    foreach ($children_codes as $children_code) {
                        $form_parts = $form_part->where('value', $children_code)
                            ->whereNull('deleted_at')
                            ->get();

                        foreach ($form_parts as $part) {
                            $form_options = $form_option->where('form_parts_value', $part->value)
                                ->get();
                            $type = $form_type->where('id', $part->form_type_id)
                                ->value('name');
                            $label = Helper::translate($part->label, $lang);
                            $range = $form_range->find($part->form_range_id);

                            $options = [];
                            $option_value_arr = [];
                            foreach ($form_options as $option) {
                                // DEPRECATED: 重複したレコードを表示しない
                                if (in_array($option["value"], $option_value_arr)) continue;

                                array_push($option_value_arr, $option["value"]);
                                array_push($options, [
                                    'value' => $this->format_response_value($option->value),
                                    'body' => Helper::translate($option->value, $lang),
                                    'end' => $option->end
                                ]);
                            }

                            // DEPRECATED: 重複したレコードを表示しない
                            if (in_array($part->value, $parent_value_arr)) continue;

                            array_push($parent_value_arr, $part->value);
                            if ($type == 'range') {
                                array_push($choices, [
                                    'value' => $part->value,
                                    'type' => $type,
                                    'label' => $label,
                                    'min' => $range->min,
                                    'max' => $range->max,
                                    'step' => $range->step,
                                    'option' => $options
                                ]);
                            } else {
                                array_push($choices, [
                                    'value' => $part->value,
                                    'type' => $type,
                                    'label' => $label,
                                    'option' => $options
                                ]);
                            }
                        }
                    }

                    // 表示項目ソート
                    $choices = self::_sortResponseBase($choices);
                    $choices = self::_sortResponse($requested_code, $choices);

                    $this->json['data'] = $choices;
                    return response()->json($this->json);
                    break;
                default:
                    $master = new Master;
                    $table_name = $master->select('name')
                        ->where('code', $code)
                        ->first()
                        ->name;
                    $data = DB::table($table_name)->select('name')->get();
                    break;
            }

        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        $this->json['data'] = $data;

        return response()->json($this->json);
    }

    /*
     * Default sort display values
     *
     * @param array $choices
     * @return array
     */
    private function _sortResponseBase(array $choices): array
    {
        $new_choices = [];
        foreach ($choices as $key => $choice) {
            $values = [];
            foreach ($choice["option"] as $option) {
                array_push($values, $option["value"]);
            }

            if (count($values) > 1) {
                $options = $choice["option"];
                array_multisort($options, SORT_ASC);
            }
            array_push($new_choices, $choice);
        }
        return $new_choices;
    }

    /*
     * Sort display values
     *
     * @param string $requested_code
     * @param array $choices
     * @return array
     */
    private function _sortResponse(string $requested_code, array $choices): array
    {
        switch ($requested_code) {
            default:
                return $choices;
        }
    }

}
