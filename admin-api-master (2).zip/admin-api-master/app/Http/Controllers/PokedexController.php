<?php

namespace App\Http\Controllers;

use App\Models\Pokedex;
use Illuminate\Http\Request;

class PokedexController extends Controller
{
    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pokedexs = Pokedex::query();

        if ($request->search) {
            $pokedexs->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->ids) {
            $pokedexs->whereIn('id', explode(',', $request->ids));
        }

        if ($request->publish_status) {
            $pokedexs->where('publish_status', $request->publish_status);
        }

        $per_page = 10;
        if ($request->per_page) {
            $per_page = $request->per_page;
        }

        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $pokedexs->orderBy($sort_column, $sort);

        if ($request->csv) {
            return $pokedexs->get();
        }
        return $pokedexs->paginate($per_page);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $image_path = '';
        if ($request->image) {
            $image_path = $this->upload_file($request, 'pokedex');
        }

        $pokedex = new Pokedex();
        $pokedex->name = $request->name;
        $pokedex->pokedex_no = $request->pokedex_no;
        $pokedex->pokedex_type = $request->pokedex_type;
        $pokedex->pokedex_type_name = $request->pokedex_type_name;
        $pokedex->height = $request->height;
        $pokedex->weight = $request->weight;
        $pokedex->flavor_kanji = $request->flavor_kanji;
        $pokedex->flavor_kana = $request->flavor_kana;
        $pokedex->card_image_path = $image_path;
        $pokedex->publish_status = $request->publish_status;
        if (!empty($request->updater_name)) {
            $pokedex->register_name = $request->updater_name;
            $pokedex->updater_name = $request->updater_name;
        }
        $pokedex->save();
        return $pokedex;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PictureBook $pokedex
     * @return \Illuminate\Http\Response
     */
    public function show(Pokedex $pokedex)
    {
        return $pokedex;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\PictureBook $pokedex
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pokedex $pokedex)
    {
        $image_path = '';
        if ($request->image) {
            $image_path = $this->upload_file($request, 'pokedex');
        }
        $pokedex->name = $request->name;
        $pokedex->pokedex_no = $request->pokedex_no;
        $pokedex->pokedex_type = $request->pokedex_type;
        $pokedex->pokedex_type_name = $request->pokedex_type_name;
        $pokedex->height = $request->height;
        $pokedex->weight = $request->weight;
        $pokedex->flavor_kanji = $request->flavor_kanji;
        $pokedex->flavor_kana = $request->flavor_kana;
        if ($image_path) {
            $pokedex->card_image_path = $image_path;
        }
        $pokedex->publish_status = $request->publish_status;
        if (!empty($request->updater_name)) {
            $pokedex->updater_name = $request->updater_name;
        }
        $pokedex->save();
        return $pokedex;
    }
}
