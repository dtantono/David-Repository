<?php

namespace App\Http\Controllers;

use App\Models\Card;
use Illuminate\Http\Request;

class SimpleCardController extends Controller
{

    /**
     * Display a listing of the resource.
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $cards = Card::select(['id', 'name', 'card_id', 'p_other_type'])->whereIn('publish_status', [1,2,3,4])->get();
        return $cards;
    }
}
