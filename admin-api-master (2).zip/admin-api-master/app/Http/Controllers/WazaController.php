<?php

namespace App\Http\Controllers;


use App\Models\CardsWazas;
use App\Models\Categories;
use App\Models\Card;
use App\Models\Waza;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Classes\Csv;

class WazaController extends Controller
{
    /*
     * Index
     */
    public function index(Request $request)
    {
        $rule = config('rules.master.waza.WazaController.index');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }


        $sort = 'DESC';
        $sort_column = 'id';
        if ($request->sort_column) {
            $sort_column = $request->sort_column;
        }
        if ($request->sort) {
            $sort = $request->sort;
        }
        $this->query = Waza::orderBy($sort_column, $sort);;
        if ($request->ids) {
            $this->query->whereIn('id', explode(',', $request->ids));
        }
        if ($request->search) {
            $this->query->where(function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->search . '%');
            });
        }


        $this->searchWaza($request, $this->query);

        $wazas = $this->query->paginate($request->input('per_page', config('setting.per_page')))
            ->toArray();


        $this->json['data'] = [];
        if ($wazas['data']) {
            foreach ($wazas['data'] as $k => $v) {
                $category = Categories::where('id', $v['category'])->first();
                $this->json['data'][$k]['id'] = $v['id'];
                $this->json['data'][$k]['name'] = $v['name'];
                $this->json['data'][$k]['damage'] = $v['damage'];
                $this->json['data'][$k]['attack_text'] = $v['body'];
                $this->json['data'][$k]['memo'] = $v['memo'];
                $this->json['data'][$k]['status'] = null;
                $this->json['data'][$k]['updated_at'] = $v['updated_at'];
                $this->json['data'][$k]['updater_name'] = $v['updater_name'];

                if ($v['status']) {
                    $this->json['data'][$k]['status'] = config('setting.waza_status')[$v['status']];
                }
                $this->json['data'][$k]['category'] = null;
                if (!empty($category)) {
                    $this->json['data'][$k]['category'] = $category->name;
                }
                $this->json['data'][$k]['energies'] = $this->getWazaEnergies($v['id']);
                $this->json['data'][$k]['cards'] = $this->getWazaCard($v['id']);
                $this->json['data'][$k]['total_cards'] = count($this->json['data'][$k]['cards']);
            }
        }

        $this->json['from'] = $wazas['from'];
        $this->json['last_page'] = $wazas['last_page'];
        $this->json['next_page_url'] = $wazas['next_page_url'];
        $this->json['path'] = $wazas['path'];
        $this->json['per_page'] = $wazas['per_page'];
        $this->json['prev_page_url'] = $wazas['prev_page_url'];
        $this->json['to'] = $wazas['to'];
        $this->json['total'] = $wazas['total'];

        if ($request->csv) {
            return $this->csvBuilder($this->json['data']);
        }

        return $this->json;
    }

    protected function getWazaCard($wazaId)
    {
        $arr = [];
        $cardsWazas = CardsWazas::where('waza_id', $wazaId)->get();
        if (count($cardsWazas)) {
            foreach ($cardsWazas as $cardInfo) {
                $card = Card::select('id', 'name')
                    ->where('id', $cardInfo->card_id)
                    ->first();
                if (count($card)) {
                    $arr[] = $card['attributes'];
                }
            }
        }
        return $arr;
    }


    /*
     * Count
     */
    public function count(Request $request)
    {
        $rule = config('rules.master.waza.WazaController.count');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }
        $wazas = Waza::get();
        if ($wazas) {
            $this->json['total'] = count($wazas);
        }

        return $this->json;
    }

    /*
     * Related Card
     */

    public function relatedCard(Request $request)
    {
        $rule = config('rules.master.waza.WazaController.relatedCard');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }

        $related_wazas = CardsWazas::select('card_id')
            ->where('waza_id', $request->waza_id)
            ->get();

        if ($related_wazas) {
            foreach ($related_wazas as $k => $v) {
                $card = Card::where('id', $v['card_id'])->first();

                $this->json['data'][$k]['card_id'] = $v['card_id'];
                $this->json['data'][$k]['name'] = [];
                if ($card->name) {
                    $this->json['data'][$k]['name'] = $card->name;
                }
                $this->json['data'][$k]['uuid'] = [];
                if ($card->uuid) {
                    $this->json['data'][$k]['uuid'] = $card->uuid;
                }
            }
        }

        return $this->json;
    }

    /*
     * Show
     */
    public function show(Request $request, $id)
    {
        $rule = config('rules.master.waza.WazaController.show');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }

        $waza = Waza::where('id', $id)->first();
        if ($waza) {
            $this->json['id'] = $waza['id'];
            $this->json['name'] = $waza['name'];
            $this->json['damage'] = $waza['damage'];
            $this->json['attack_text'] = $waza['body'];
            $this->json['damage_text'] = $waza['damage_text'];
            $this->json['waza_type'] = $waza['waza_type'];
            $this->json['memo'] = $waza['memo'];
            $this->json['status'] = $waza['status'];
            $this->json['created_at'] = (string)$waza['created_at'];
            $this->json['register_name'] = $waza['register_name'];
            $this->json['updated_at'] = (string)$waza['updated_at'];
            $this->json['updater_name'] = $waza['updater_name'];
            $this->json['category'] = $waza['category'];
            $this->json['energies'] = $this->getWazaEnergies($waza['id']);
            $this->json['data'] = $this->getWazaLogics($request, $waza['id']);
            $this->json['energy_number'] = $waza['energy_number'];
        }

        return $this->json;
    }

    /*
     * Store
     */
    public function store(Request $request)
    {
        $rule = config('rules.master.waza.WazaController.store');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }

        try {
            DB::beginTransaction();

            $waza = $this->saveWaza($request, null, 'new');

            if ($request->energies) {
                $this->saveWazaEnergies($request, $waza->id);
            }

            if ($request->logics) {
                $this->saveWazaLogics($request, $waza->id);
            }
            $this->json['id'] = $waza->id;
            DB::commit();

        } catch (\Exception $e) {
            DB::rollback();
            $this->json = [
                'result' => 2,
                'error_code' => '500',
                'error_message' => 'システムエラーが発生しました。' . $e->getMessage()
            ];
        }
        return $this->json;
    }

    /*
     * Update
     */
    public function update(Request $request, $id)
    {
        $rule = config('rules.master.waza.WazaController.update');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }

        try {
            DB::beginTransaction();

            $waza = $this->saveWaza($request, $id, 'update');

            $this->deleteRecord('\App\Models\WazasEnergies', $id, 'energy');
            if ($request->energies) {
                $this->saveWazaEnergies($request, $waza->id);
            }

            $this->deleteRecord('\App\Models\WazasLogics', $id, 'logic');
            if ($request->logics) {
                $this->saveWazaLogics($request, $waza->id);
            }
            $this->json['id'] = $waza->id;
            DB::commit();

        } catch (\Exception $e) {
            DB::rollback();
            $this->json = [
                'result' => 2,
                'error_code' => '500',
                'error_message' => 'システムエラーが発生しました。' . $e->getMessage()
            ];
        }

        return $this->json;
    }

    /*
     * Delete
     */
    public function destroy(Request $request, $id)
    {
        $rule = config('rules.master.waza.WazaController.destroy');
        self::debug($request->all());
        if ($validate = self::setValidate($request, $rule)) {
            return $validate;
        }

        try {
            DB::beginTransaction();

            $this->deleteRecord('\App\Waza', $id, null);
            $this->deleteRecord('\App\WazasEnergies', $id, 'energy');
            $this->deleteRecord('\App\WazasLogics', $id, 'logic');

            DB::commit();

        } catch (\Exception $e) {
            DB::rollback();
            $this->json = [
                'result' => 2,
                'error_code' => '500',
                'error_message' => 'システムエラーが発生しました。' . $e->getMessage()
            ];
        }

        return $this->json;
    }

    private function csvBuilder(array $list)
    {
        if ($list) {
            foreach ($list as $k2 => $v2) {
                $list[$k2]['Costs'] = '';
                if ($v2['energies']) {
                    foreach ($v2['energies'] as $k3 => $v3) {
                        $list[$k2]['Costs'] .= $v3 . '/';

                    }
                }
                unset($list[$k2]['energies'], $list[$k2]['cards']);
            }
            $header = [
                'No',
                'Name',
                'Damage',
                'Description',
                'Memo',
                'Status',
                'Category',
                'Number in use',
                'Costs'
            ];
            return Csv::download($list, $header, 'wazas.csv');
        }
    }

}
