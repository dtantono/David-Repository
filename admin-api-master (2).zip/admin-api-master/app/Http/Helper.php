<?php

namespace App\Http;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class Helper
{

    /*
     * Purchases
     */
    const DAILY_PAID_UU = '10001';
    const WEEKLY_PAID_UU = '10002';
    const MONTHLY_PAID_UU = '10003';

    const DAILY_PAID_UU_RATE = '20001';
    const WEEKLY_PAID_UU_RATE = '20002';
    const MONTHLY_PAID_UU_RATE = '20003';

    const DAILY_ARPPU = '30001';
    const WEEKLY_ARPPU = '30002';
    const MONTHLY_ARPPU = '30003';

    const ARPDAU = '40001';
    const ARPMAU = '40002';

    const DAILY_GROSS_PROFIT = '50001';
    const WEEKLY_GROSS_PROFIT = '50002';
    const MONTHLY_GROSS_PROFIT = '50003';

    /*
     * Users
     */
    const DAILY_PERSISTENCY_RATE = '80001';
    const WEEKLY_PERSISTENCY_RATE = '80003';
    const MONTHLY_PERSISTENCY_RATE = '80002';

    const DAILY_ABANDONMENT_RATE = '90001';
    const WEEKLY_ABANDONMENT_RATE = '90002';
    const MONTHLY_ABANDONMENT_RATE = '90003';

    /*
     * Active User
     */
    const DAILY_ACTIVE_USER = '10101';
    const WEEKLY_ACTIVE_USER = '10102';
    const MONTHLY_ACTIVE_USER = '10103';

    /*
     * 集計データ取得
     *
     * Args:
     *   $model: 集計対象テーブル
     *   $input_model: 集計後データ格納先
     *   $type: 集計間隔
     */
    public static function fetchAggregatedData($model, $input_model, $type)
    {
        // 日付単位で集計
        switch ($type) {
            case self::DAILY_PAID_UU:
                $select_query = "DATE_FORMAT(created_at, '%Y%m%d') date,";
                $term_query = [
                    Carbon::today()->subDay(10),
                    Carbon::now()
                ];
                break;
            case self::WEEKLY_PAID_UU:
                $select_query = "WEEK(created_at) date,";
                $term_query = [
                    Carbon::today()->subYear(1),
                    Carbon::now()
                ];
                break;
            case self::MONTHLY_PAID_UU:
                $select_query = "DATE_FORMAT(created_at, '%Y%m') date,";
                $term_query = [
                    Carbon::today()->subYear(1),
                    Carbon::now()
                ];
                break;
            default:
                $select_query = "DATE_FORMAT(created_at, '%Y%m%d') date,";
                $term_query = [
                    Carbon::today()->subDay(10),
                    Carbon::now()
                ];
                break;
        }

        $input_model::where('type', $type)->delete();
        $data = $model::selectRaw(
            $select_query
            . "COUNT('id') data"
        )->whereBetween(
            'created_at',
            [
                $term_query
            ]
        )->groupBy('date')
            ->get();
        foreach ($data as $row) {
            $aggregate_payments = new $input_model();
            $aggregate_payments->type = $type;
            $aggregate_payments->data = $row->data;
            $aggregate_payments->date = $row->date;
            $aggregate_payments->save();
        }
    }

    /*
     * Paid UU Rate
     */
    public static function fetchAggregatePuuRate($model, $input_model, $type)
    {
        switch ($type) {
            case self::DAILY_PAID_UU_RATE:
                $select_query = "date_format(accesses.access_time, '%Y%m%d') date,"
                    . "COUNT(DISTINCT(payments.user_id)) / COUNT(DISTINCT(accesses.user_id)) data";
                break;
            case self::WEEKLY_PAID_UU_RATE:
                $select_query = "WEEK(accesses.access_time) date,"
                    . "COUNT(DISTINCT(payments.user_id)) / COUNT(DISTINCT(accesses.user_id)) data";
                break;
            case self::MONTHLY_PAID_UU_RATE:
                $select_query = "date_format(accesses.access_time, '%Y%m') date,"
                    . "COUNT(DISTINCT(payments.user_id)) / COUNT(DISTINCT(accesses.user_id)) data";
                break;
            default:
                $select_query = "date_format(accesses.access_time, '%Y%m%d') date,"
                    . "COUNT(DISTINCT(payments.user_id)) / COUNT(DISTINCT(accesses.user_id)) data";
                break;
        }

        $input_model::where('type', $type)->delete();
        $data = $model::selectRaw($select_query)
            ->leftJoin('payments', DB::raw("DATE_FORMAT(accesses.access_time, '%Y%m%d')"), '=', DB::raw("DATE_FORMAT(payments.created_at, '%Y%m%d')"))
            ->groupBy('date')
            ->orderBy('date')
            ->get();
        foreach ($data as $row) {
            $aggregate_payments = new $input_model;
            $aggregate_payments->type = $type;
            $aggregate_payments->data = $row->data;
            $aggregate_payments->date = $row->date;
            $aggregate_payments->save();
        }
    }

    /*
     * ARPPU
     */
    public static function fetchAggregateArppu($model, $input_model, $type)
    {
        switch ($type) {
            case self::DAILY_ARPPU:
                $select_query = "date_format(payments.created_at, '%Y%m%d') date,"
                    . "SUM(payments.amount) / COUNT(DISTINCT(payments.user_id)) data";
                break;
            case self::WEEKLY_ARPPU:
                $select_query = "WEEK(payments.created_at) date,"
                    . "SUM(payments.amount) / COUNT(DISTINCT(payments.user_id)) data";
                break;
            case self::MONTHLY_ARPPU:
                $select_query = "date_format(payments.created_at, '%Y%m') date,"
                    . "SUM(payments.amount) / COUNT(DISTINCT(payments.user_id)) data";
                break;
            default:
                $select_query = "date_format(payments.created_at, '%Y%m%d') date,"
                    . "SUM(payments.amount) / COUNT(DISTINCT(payments.user_id)) data";
                break;
        }

        $input_model::where('type', $type)->delete();
        $data = $model::selectRaw($select_query)
            ->groupBy('date')
            ->orderBy('date')
            ->get();
        foreach ($data as $row) {
            $aggregate_payments = new $input_model;
            $aggregate_payments->type = $type;
            $aggregate_payments->data = $row->data;
            $aggregate_payments->date = $row->date;
            $aggregate_payments->save();
        }
    }

    /*
     * ARPDAU, ARPMAU
     */
    public static function fetchAggregateUser($model, $input_model, $type)
    {
        switch ($type) {
            case self::ARPDAU:
                $select_query = "date_format(payments.created_at, '%Y%m%d') date,"
                    . "IFNULL(SUM(payments.amount) / COUNT(DISTINCT(accesses.user_id)), 0) data";
                $join_query = ['accesses', DB::raw("DATE_FORMAT(accesses.access_time, '%Y%m%d')"), '=', DB::raw("DATE_FORMAT(payments.created_at, '%Y%m%d')")];
                break;
            case self::ARPMAU:
                $select_query = "date_format(payments.created_at, '%Y%m') date,"
                    . "IFNULL(SUM(payments.amount) / COUNT(DISTINCT(accesses.user_id)), 0) data";
                $join_query = ['accesses', DB::raw("DATE_FORMAT(accesses.access_time, '%Y%m')"), '=', DB::raw("DATE_FORMAT(payments.created_at, '%Y%m')")];
                break;
            default:
                $select_query = "date_format(payments.created_at, '%Y%m%d') date,"
                    . "IFNULL(SUM(payments.amount) / COUNT(DISTINCT(accesses.user_id)), 0) data";
                $join_query = ['accesses', DB::raw("DATE_FORMAT(accesses.access_time, '%Y%m%d')"), '=', DB::raw("DATE_FORMAT(payments.created_at, '%Y%m%d')")];
                break;
        }

        $input_model::where('type', $type)->delete();
        $data = $model::selectRaw($select_query)
            ->leftJoin($join_query[0], $join_query[1], $join_query[2], $join_query[3])
            ->groupBy('date')
            ->orderBy('date')
            ->get();
        foreach ($data as $row) {
            $aggregate_payments = new $input_model;
            $aggregate_payments->type = $type;
            $aggregate_payments->data = $row->data;
            $aggregate_payments->date = $row->date;
            $aggregate_payments->save();
        }
    }

    /*
     * Gross Profit
     */
    public static function fetchAggregateGrossProfit($model, $input_model, $type)
    {
        switch ($type) {
            case self::DAILY_GROSS_PROFIT:
                $select_query = "date_format(profits.created_at, '%Y%m%d') date,"
                    . "SUM(profits.amount) data";
                break;
            case self::WEEKLY_GROSS_PROFIT:
                $select_query = "WEEK(profits.created_at) date,"
                    . "SUM(profits.amount) data";
                break;
            case self::MONTHLY_GROSS_PROFIT:
                $select_query = "date_format(profits.created_at, '%Y%m') date,"
                    . "SUM(profits.amount) data";
                break;
            default:
                $select_query = "date_format(profits.created_at, '%Y%m%d') date,"
                    . "SUM(profits.amount) data";
                break;
        }

        $input_model::where('type', $type)->delete();
        $data = $model::selectRaw($select_query)
            ->groupBy('date')
            ->orderBy('date')
            ->get();
        foreach ($data as $row) {
            $aggregate_payments = new $input_model;
            $aggregate_payments->type = $type;
            $aggregate_payments->data = $row->data;
            $aggregate_payments->date = $row->date;
            $aggregate_payments->save();
        }
    }

    /*
     * Persistency Rate
     *
     * 本日ログインユーザのうち前日もログインしているユーザ
     */
    public static function fetchAggregatePersistency($model, $input_model, $type)
    {
        switch ($type) {
            case self::DAILY_PERSISTENCY_RATE:
                $access_format = " date_format(log1.access_time, '%Y%m%d') AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m%d')";
                break;
            case self::WEEKLY_PERSISTENCY_RATE:
                $access_format = " WEEK(log1.access_time) AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, WEEK(log1.access_time)";
                break;
            case self::MONTHLY_PERSISTENCY_RATE:
                $access_format = " date_format(log1.access_time, '%Y%m') AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m')";
                break;
            default:
                $access_format = " date_format(log1.access_time, '%Y%m%d') AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m%d')";
                break;
        }

        // 1日継続人数取得
        $data = DB::select(
            "SELECT "
            . $select_query
            /*. " log.access_time,"
            . " COUNT(log.max_duration = 1 OR NULL) AS cnt"*/
            . " FROM ("
            . " SELECT"
            . "   log1.user_id,"
            . $access_format
//            . "   date_format(log1.access_time, '%Y%m%d') AS access_time,"
            . "   MAX(DATEDIFF(log1.access_time, log2.access_time)) AS max_duration"
            . "   FROM accesses AS log1"
            . "   INNER JOIN accesses AS log2"
            . "   ON date_format(log2.access_time, '%Y%m%d') < date_format(log1.access_time, '%Y%m%d')"
            . "   AND log1.user_id = log2.user_id"
            . $groupby_format
//            . "   GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m%d')"
            . "   ) AS log"
            . " WHERE log.access_time IS NOT NULL"
            . " GROUP BY access_time"
        );

        $input_model::where('type', $type)->delete();
        foreach ($data as $row) {
            $aggregate_userss = new $input_model;
            $aggregate_userss->type = $type;
            $aggregate_userss->data = $row->data;
            $aggregate_userss->date = $row->date;
            $aggregate_userss->save();
        }
    }

    /*
     * Abandonment Rate
     */
    public static function fetchAggregateAbandonment($model, $input_model, $type)
    {
        switch ($type) {
            case self::DAILY_PERSISTENCY_RATE:
                $access_format = " date_format(log1.access_time, '%Y%m%d') AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m%d')";
                break;
            case self::WEEKLY_PERSISTENCY_RATE:
                $access_format = " WEEK(log1.access_time) AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, WEEK(log1.access_time)";
                break;
            case self::MONTHLY_PERSISTENCY_RATE:
                $access_format = " date_format(log1.access_time, '%Y%m') AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m')";
                break;
            default:
                $access_format = " date_format(log1.access_time, '%Y%m%d') AS access_time,";
                $select_query = "log.access_time date,"
                    . "COUNT(log.max_duration = 1 OR NULL) / (SELECT COUNT(DISTINCT(accesses.user_id)) FROM accesses) data";
                $groupby_format = " GROUP BY log1.user_id, date_format(log1.access_time, '%Y%m%d')";
                break;
        }

        // 1日継続人数取得
        $data = DB::select(
            "SELECT "
            . $select_query
            . " FROM accesses ac2"
            . " WHERE ac2.user_id IN ("
            . "   SELECT ac.user_id user_id"
            . "   FROM accesses ac"
            . "   WHERE"
            . "     date_format(ac.access_time, '%Y%m%d') = date_sub(current_date(), INTERVAL 1 day)"
            . "   GROUP BY ac.user_id"
            . " )"
            . " AND date_format(ac2.access_time, '%Y%m%d') = date_format(current_date(), '%Y%m%d');"
        );

        $input_model::where('type', $type)->delete();
        foreach ($data as $row) {
            $aggregate_userss = new $input_model;
            $aggregate_userss->type = $type;
            $aggregate_userss->data = $row->data;
            $aggregate_userss->date = $row->date;
            $aggregate_userss->save();
        }
    }

    /*
     * Active User
     */
    public static function fetchAggregateActiveUser($model, $input_model, $type)
    {
        switch ($type) {
            case self::DAILY_ACTIVE_USER:
                $select_query = " date_format(ac.access_time, '%Y%m%d') date,"
                    . " count(ac.id) data";
                $groupby_format = " GROUP BY date_format(ac.access_time, '%Y%m%d')";
                break;
            case self::WEEKLY_ACTIVE_USER:
                $select_query = " WEEK(ac.access_time) date,"
                    . " count(ac.id) data";
                $groupby_format = " GROUP BY WEEK(ac.access_time)";
                break;
            case self::MONTHLY_ACTIVE_USER:
                $select_query = " date_format(ac.access_time, '%Y%m') date,"
                    . " count(ac.id) data";
                $groupby_format = " GROUP BY date_format(ac.access_time, '%Y%m')";
                break;
            default:
                $select_query = " date_format(ac.access_time, '%Y%m%d') date,"
                    . " count(ac.id) data";
                $groupby_format = " GROUP BY date_format(ac.access_time, '%Y%m%d')";
                break;
        }

        // 1日継続人数取得
        $data = DB::select(
            "SELECT "
            . $select_query
            . " FROM accesses ac"
            . $groupby_format
        );

        $input_model::where('type', $type)->delete();
        foreach ($data as $row) {
            $aggregate_userss = new $input_model;
            $aggregate_userss->type = $type;
            $aggregate_userss->data = $row->data;
            $aggregate_userss->date = $row->date;
            $aggregate_userss->save();
        }
    }

    /*
     * 数値を0梅20桁に変換する
     */
    public static function fillPrefixZero($num)
    {
        return sprintf("%020d", $num);
    }

    /*
     * 言語ごとの文言を返す
     *
     * @param string $code locales.code
     * @param string $lang locales.lang
     * @return string $ret 指定した言語の文言
     */
    public static function translate($code, $lang)
    {
        $ret = '';

        $body = DB::table('locales')
            ->where('code', $code)
            ->where('lang', $lang)
            ->value('name');
        switch ($body) {
            case (null):
                break;
            default:
                $ret = $body;
                break;
        }

        return $ret;
    }

}