<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Log;

class RequestResponseLog
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!empty($request->all())) {
            Log::debug('== Request :[' . $request->method() . '] ' . $request->getUri() . PHP_EOL . json_encode($request->all(), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        } else {
            Log::debug('== Request :[' . $request->method() . '] ' . $request->getUri());
        }

        $response = $next($request);
        if (!empty($response->original)) {
            Log::debug('== Response : [' . $request->method() . '] ' . $request->getUri() . PHP_EOL . json_encode($response->original, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        } else {
            Log::debug('== Response : [' . $request->method() . '] ' . $request->getUri());
        }


        return $response;
    }
}
