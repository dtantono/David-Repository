<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DeckCard extends Model
{
    use SoftDeletes;
    protected $table = 'deck_cards';
    protected $dates = ['deleted_at'];
}
