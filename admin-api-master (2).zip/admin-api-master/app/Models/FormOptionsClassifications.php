<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FormOptionsClassifications extends Model
{
    use SoftDeletes;

    protected $table = 'form_options_classifications';
    protected $dates = ['deleted_at'];
}
