<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WazasLogics extends Model
{
    use SoftDeletes;

    protected $table = 'wazas_logics';
    protected $dates = ['deleted_at'];
}
