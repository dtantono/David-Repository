<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WazasSkillsLogics extends Model
{
    use SoftDeletes;

    protected $table = 'wazas_skills_logics';
    protected $dates = ['deleted_at'];
}
