<?php

return [
	[
		'name' => '自分の手札',
		'code' => '01'
	],
	[
		'name' => '自分の山札',
		'code' => '02'
	],
    [
        'name' => '自分のトラッシュ',
        'code' => '03'
    ],
    [
        'name' => '自分のサイド',
        'code' => '04'
    ],
    [
        'name' => '相手の手札',
        'code' => '05'
    ],
    [
        'name' => '相手の山札',
        'code' => '06'
    ],
    [
        'name' => '相手のトラッシュ',
        'code' => '07'
    ],
    [
        'name' => '相手のサイド',
        'code' => '08'
    ],
    [
        'name' => 'Attached to Pokemon',
        'code' => '09'
    ],
    [
        'name' => 'ロストゾーン',
        'code' => '10'
    ]
];
