<?php

return [
	[
		'name' => '基本',
		'code' => '01'
	],
	[
		'name' => '特殊',
		'code' => '02'
	]
];
