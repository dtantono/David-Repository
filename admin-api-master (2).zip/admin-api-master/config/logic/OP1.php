<?php

return [
	[
		'name' => 'Asleep',
		'code' => '01'
	],
	[
		'name' => 'Burned',
		'code' => '02'
	],
	[
		'name' => 'Confused',
		'code' => '03'
	],
	[
		'name' => 'Paralyzed',
		'code' => '04'
	],
	[
		'name' => 'Poisoned',
		'code' => '05'
	]
];




