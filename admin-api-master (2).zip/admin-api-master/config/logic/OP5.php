<?php

return [
	[
		'name' => 'SELF',
		'code' => '01'
	],
	[
		'name' => 'ENEMY',
		'code' => '02'
	],
	[
		'name' => 'BOTH',
		'code' => '03'
	]
];




