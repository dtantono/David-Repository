<?php

return [
	[
		'name' => 'Battle',
		'code' => '01'
	],
	[
		'name' => 'Bench',
		'code' => '02'
	],
	[
		'name' => 'Hand',
		'code' => '04'
	]
];




