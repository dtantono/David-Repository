<?php

return [
	[
		'name' => 'Battle',
		'code' => '01'
	],
	[
		'name' => 'Bench',
		'code' => '02'
	],
	[
		'name' => 'Hand',
		'code' => '04'
	],
	[
		'name' => 'Deck',
		'code' => '05'
	],
	[
		'name' => 'Trash',
		'code' => '06'
	],
	[
		'name' => 'Side',
		'code' => '07'
	]
];




