<?php

return [
	[
		'name' => 'Player',
		'code' => '01'
	],
	[
		'name' => 'このポケモン',
		'code' => '02'
	],
	[
		'name' => 'Battle',
		'code' => '03'
	],
	[
		'name' => 'Bench',
		'code' => '04'
	],
	[
		'name' => 'Hand',
		'code' => '06'
	],
	[
		'name' => 'Deck',
		'code' => '07'
	],
	[
		'name' => 'Trash',
		'code' => '08'
	],
	[
		'name' => 'Side',
		'code' => '09'
	]
];




