<?php

return [
	[
		'name' => '完全固有名称指定',
		'code' => '01'
	],
	[
		'name' => '部分名称指定',
		'code' => '02'
	]
];