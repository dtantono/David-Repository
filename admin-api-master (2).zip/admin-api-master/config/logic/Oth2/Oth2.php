<?php

return [
	[
		'name' => 'ランダム選択の決定方法',
		'code' => '01',
        'end' => true
	],
	[
		'name' => '【選択肢入力フィールド】+【確率入力】',
		'code' => '02',
        'end' => true
	]
];