<?php

return [
	[
		'name' => '選択項目の種類を指定',
		'code' => '01',
        'end' => false
	],
	[
		'name' => '確率入力',
		'code' => '02',
        'end' => false
	]
];