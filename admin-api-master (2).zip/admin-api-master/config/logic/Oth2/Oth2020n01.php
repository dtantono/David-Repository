<?php

return [
	[
		'name' => '項目名を指定',
		'code' => '01',
        'end' => true
	],
	[
		'name' => '値の範囲を指定',
		'code' => '02',
        'end' => false
	]
];