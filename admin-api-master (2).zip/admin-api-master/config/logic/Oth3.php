<?php

return [
	[
		'name' => 'Pokemon',
		'code' => '01'
	],
	[
		'name' => 'Trainer',
		'code' => '02'
	],
	[
		'name' => 'Suppoerter',
		'code' => '03'
	],
	[
		'name' => 'Item',
		'code' => '04'
	],
	[
		'name' => 'ポケモンのどうぐ',
		'code' => '05'
	],
	[
		'name' => 'ワザマシン',
		'code' => '06'
	],
    [
        'name' => 'Stadium',
        'code' => '07'
    ],
    [
        'name' => 'Energy',
        'code' => '08'
    ]
];
