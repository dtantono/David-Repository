<?php

return [
	[
		'name' => 'Mega Evolution',
		'code' => '01'
	],
	[
		'name' => 'BREAK',
		'code' => '02'
	],
    [
        'name' => '～の化石',
        'code' => '03'
    ],
    [
        'name' => 'EX',
        'code' => '04'
    ],
    [
        'name' => 'GX',
        'code' => '05'
    ],
    [
        'name' => 'デルタ種',
        'code' => '06'
    ],
    [
        'name' => 'Legend',
        'code' => '07'
    ]
];
