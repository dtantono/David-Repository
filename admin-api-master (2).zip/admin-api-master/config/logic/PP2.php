<?php

return [
	[
		'name' => 'None',
		'code' => '01'
	],
	[
		'name' => 'Rainbow',
		'code' => '02'
	],
	[
		'name' => 'Grass',
		'code' => '03'
	],
	[
		'name' => 'Fire',
		'code' => '04'
	],
	[
		'name' => 'Water',
		'code' => '05'
	],
	[
		'name' => 'Lightning',
		'code' => '06'
	],
	[
		'name' => 'Psychic',
		'code' => '07'
	],
	[
		'name' => 'Fighting',
		'code' => '08'
	],
	[
		'name' => 'Darkness',
		'code' => '09'
	],
	[
		'name' => 'Metal',
		'code' => '10'
	],
	[
		'name' => 'Fairy',
		'code' => '11'
	],
	[
		'name' => 'Dragon',
		'code' => '12'
	],
	[
		'name' => 'Colorless',
		'code' => '13'
	]
];