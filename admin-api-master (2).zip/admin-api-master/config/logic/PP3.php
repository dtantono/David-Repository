<?php

return [
	[
		'name' => 'Baby',
		'code' => '01'
	],
	[
		'name' => 'Basic',
		'code' => '02'
	],
	[
		'name' => 'Stage1',
		'code' => '03'
	],
	[
		'name' => 'Stage2',
		'code' => '04'
	],
	[
		'name' => 'レジェンド',
		'code' => '05'
	]
];