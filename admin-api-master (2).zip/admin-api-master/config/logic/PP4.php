<?php

return [
	[
		'name' => 'Mega Evolution',
		'code' => '01'
	],
	[
		'name' => 'BREAK',
		'code' => '02'
	],
    [
        'name' => '～の化石',
        'code' => '03'
    ]
];
