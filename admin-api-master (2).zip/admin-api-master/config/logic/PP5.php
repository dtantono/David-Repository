<?php

return [
	[
		'name' => '覚醒なし',
		'code' => '01'
	],
	[
		'name' => '覚醒',
		'code' => '02'
	],
	[
		'name' => '超覚醒',
		'code' => '03'
	]
];