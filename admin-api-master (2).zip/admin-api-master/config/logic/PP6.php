<?php

return [
	[
		'name' => 'EX',
		'code' => '01'
	],
	[
		'name' => 'GX',
		'code' => '02'
	],
    [
        'name' => 'デルタ種',
        'code' => '04'
    ],
    [
        'name' => 'Legend',
        'code' => '05'
    ],
    [
        'name' => '通常のポケモン',
        'code' => '06'
    ]
];
