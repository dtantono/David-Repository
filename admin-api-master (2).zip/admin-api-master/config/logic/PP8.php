<?php

return [
	[
		'name' => 'None',
		'code' => '01'
	],
	[
		'name' => 'Grass',
		'code' => '02'
	],
	[
		'name' => 'Fire',
		'code' => '03'
	],
	[
		'name' => 'Water',
		'code' => '04'
	],
	[
		'name' => 'Lightning',
		'code' => '05'
	],
	[
		'name' => 'Psychic',
		'code' => '06'
	],
	[
		'name' => 'Fighting',
		'code' => '07'
	],
	[
		'name' => 'Darkness',
		'code' => '08'
	],
	[
		'name' => 'Metal',
		'code' => '09'
	],
	[
		'name' => 'Fairy',
		'code' => '10'
	],
	[
		'name' => 'Dragon',
		'code' => '11'
	],
	[
		'name' => 'Colorless',
		'code' => '12'
	]
];