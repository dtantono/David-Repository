<?php

return [
	[
		'name' => 'ある',
		'code' => '01'
	],
	[
		'name' => 'なし',
		'code' => '02'
	]
];