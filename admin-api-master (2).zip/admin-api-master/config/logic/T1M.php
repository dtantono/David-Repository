<?php

return [
	[
		'name' => 'Supporter',
		'code' => '01'
	],
	[
		'name' => 'Item',
		'code' => '02'
	],
	[
		'name' => 'ポケモンのどうぐ',
		'code' => '03'
	],
    [
        'name' => 'ワザマシン',
        'code' => '04'
    ],
    [
        'name' => 'Stadium',
        'code' => '05'
    ]
];
