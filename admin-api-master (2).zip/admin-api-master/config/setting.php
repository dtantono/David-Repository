<?php

return [
    'per_page' => 30,
    'energies' => [
        1 => 'grass',
        2 => 'fire',
        3 => 'water',
        4 => 'lightning',
        5 => 'psycic',
        6 => 'fighting',
        7 => 'darkness',
        8 => 'metal',
        9 => 'fairy',
        10 => 'dragon',
        11 => 'colorless',
        12 => 'rainbow'
    ],
    'waza_status' => [
        0 => 'なし',
        1 => '利用中',
        2 => '未使用',
        3 => 'ドラフト',
    ],
    'waza_choices_init' => [
        [
            'code' => 'trigger',
            'child_code' => 'tri-01'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-02'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-03'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-04'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-05'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-06'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-07'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-08'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-09'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-10'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-11'
        ],
        [
            'code' => 'trigger',
            'child_code' => 'tri-12'
        ]
    ],
    'form_parts_init' => [
        [
            'value' => 'tri-01',
            'option_value' => '',
            'label' => 'tri-01-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-02',
            'option_value' => 'tri-0201',
            'label' => 'tri-02-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-03',
            'option_value' => 'tri-0301',
            'label' => 'tri-03-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-04',
            'option_value' => 'tri-0401',
            'label' => 'tri-04-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-05',
            'option_value' => 'tri-0501',
            'label' => 'tri-05-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-06',
            'option_value' => 'tri-0601',
            'label' => 'tri-06-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-07',
            'option_value' => 'tri-0701',
            'label' => 'tri-07-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-08',
            'option_value' => 'tri-0801',
            'label' => 'tri-08-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-09',
            'option_value' => 'tri-0901',
            'label' => 'tri-09-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-10',
            'option_value' => 'tri-1001',
            'label' => 'tri-10-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-11',
            'option_value' => 'tri-1101',
            'label' => 'tri-11-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ],
        [
            'value' => 'tri-12',
            'option_value' => 'tri-1201',
            'label' => 'tri-12-label',
            'form_type_id' => 3,
            'form_range_id' => 1,
            'end' => 'false'
        ]
    ]
];
