# How to use
## Auth Setup
```bash
php artisan make:auth
composer require laravel/passport
php artisan migrate
php artisan passport:install

Client ID: 1
Client Secret: DkgcZ74hM1TaZV8CQiNsVW7qrLIVX0nrpdbnghDk
Password grant client created successfully.
Client ID: 2
Client Secret: ZypaH9dHKhNnXXrCdDy1z1Tl85GQ6VgOqnlCrgKv


```


