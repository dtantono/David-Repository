<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['auth:api', 'rr_log']], function () {
    Route::resource('card_types', 'CardTypeController');
    Route::resource('cards', 'CardController');
    Route::resource('deck_cards', 'DeckCardController');
    Route::resource('decks', 'DeckController');
    Route::resource('expansions', 'ExpansionController');
    Route::resource('illustrators', 'IllustratorController');
    Route::resource('pokedexs', 'PokedexController');
    Route::get('code_masters', 'CodeMasterController@index');
    Route::get('images', 'ImageController@index');
    Route::get('simple_cards', 'SimpleCardController@index');

    Route::get('card_json/{id}', 'CardJsonController@show');
    Route::get('deck_json/{id}', 'DeckJsonController@show');

    Route::get('card_zip_json', 'CardZipJsonController@index');


    /*
     * Waza Generator
     */
    Route::group(['prefix' => 'wazas'], function () {
        Route::get('', 'WazaController@index');
        Route::post('', 'WazaController@store');
        Route::get('count', 'WazaController@count');
        Route::get('count/related_card', 'WazaController@relatedCard');
        Route::get('{id}', 'WazaController@show');
        Route::put('{id}', 'WazaController@update');
        Route::delete('{id}', 'WazaController@destroy');

    });

    Route::get('utility/master/{code}', 'MasterController@index');

});


Route::get('images/card/{card_id}', 'ImageController@card');

/*
 * Csv Importer
 */
Route::group(['prefix' => 'csv'], function () {
    Route::post('', 'CsvController@store');

});
