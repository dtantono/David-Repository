Motivo-CRM (ATS)
======================

Stack
-----
- Code written in typescript
- Node.js + Koa.js server
- Amazon S3 for file storage
- Docker for containers
- Mocha + Chai for unit tests and APi tests
- Couchbase as a Database
- Passport (JWT) for authentication
- memory-cache for local server cache
- Pusher for live notifications
- Eslint use for Typescript standards
- PM2 - Live server

Structure
---------
* /src - Project folder 
  * /src - Project source code
    * /app - Main application source code
      * /assets - Asset folder
      * /commands - Schedule commands
      * /controllers - First entry point from routes
      * /db - Contains the the database module
      * /helpers - Pure functions with no database access
      * /models - Database models and typescript interfaces
      * /routes - Routes for the API
      * /server - Server startup and certificates
      * /services - Shared logic between controllers (and should be the only interface to the database)
    * /scripts - Ad-hoc scripts
  * /test - Project test files
  * /dist - Project output (to be run)
    * /test and /src get compiled into here
    * server entry point is /dist/app/server/index.js
    * test entry point is /dist/test/app/index.js
* /docker - Docker setup

Installation
------------
cd docker

docker-compose up

docker exec -it docker_id bash

-> npm run db:index
-> npm run db:seed
-> exit

docker-compose stop
docker-compose start


Configuration
-------------
/docker/docker-app-variables.env - required docker variables for the API

/docker/couchbase/docker-cb-variables.env - required docker variables for Couchbase

/src/config.ts -> /src/dist/config.js - required config for the API

/src/app/server/certs/cert.pem - required for HTTPS

/src/app/server/certs/key.pem - required for HTTPS

Operations
----------
Commands ran periodically can be found in /src/src/app/commands (and /src/dist/src/app/commands).

| File name | Description | Schedule |
|-----------|-------------|----------|
| cacheApplicantData  | Calculates the vacancies and number of applications for the dashboard  | 10pm daily |
| generateOpeningSearchTags | Generates the tags that can be used to search | On server startup |
|           |             |          |
|           |             |          |


LICENSE
-------
[PROPIETARY](LICENSE.md)