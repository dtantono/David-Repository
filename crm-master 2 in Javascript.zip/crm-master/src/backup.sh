HOST=localhost
LOGIN=Administrator
PASSWORD=∂
BUCKET=motivo
NOW=$(date +"%m_%d_%Y")

# S3_BUCKET="s3://motivo/couchbase/$NOW/"

# Backup the database into backup folder
docker exec -it couchbase cbbackup http://$HOST:8091 -u $LOGIN -p $PASSWORD -b $BUCKET /srv/backup
docker cp couchbase:/srv/backup ./

# Upload content to S3
# CONFIG="--config $HOME/.s3cfg"
# cd backup
# s3cmd --recursive $CONFIG sync * $S3_BUCKET

