#!/bin/bash
# build-typescript.sh
tsc -p .
cp -R src/app/assets dist/src/app/assets
cp -R src/app/server/certs dist/src/app/server/certs