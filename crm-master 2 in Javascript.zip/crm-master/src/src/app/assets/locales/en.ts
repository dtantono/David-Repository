export default {
	// Validation
	minLength: '? is not long enough',
	format: "? hasn't got the correct format",
	enum: 'Must be a valid ?',
	required: 'Must be a valid ?',
	EmailAddress: 'Email address',
	Password: 'Password',
	ConfirmPassword: 'Confirm password',
	match: '? doesnt match',
	LastName: 'Last name',
	FirstName: 'First name',
	greater: '? must be greater',
	Name: 'Name',
	Type: 'Type',
	PipelineId: 'Pipeline',
	RejectionReason: 'Rejection Reason',
	Done: 'Done',
	Id: 'Id',
	TodoList: 'Todo list',
	type: 'Incorrect type',

	// Emails
	RegistrationConfirmationEmailSubject: 'Registration confirmation required',
	RegistrationConfirmationEmailBody: `Dear ?name, <br/>Thank you for registration with Motivo. <br/>To complete your registration, please click the follow link: <a href='?url?confirmLink'>Link</a>`,
	ResetPasswordEmailSubject: 'Reset password mail',
	ResetPasswordEmailBody: `Dear ?name, <br/>We have received a request to reset your password. <br/>To complete this action, please click the follow link: <a href='?url?confirmLink'>Link</a>`,
	ConfirmResetPasswordEmailSubject: 'Confirmed password reset mail',
	ConfirmResetPasswordEmailBody: `Dear ?name, <br/>You have successfully reset your password.`,
	InvitationSubject: 'Motivo Invitation',
	InvitationBody: `Dear ?name, <br/>You have been invited to the Motivo recruitment platform. <br/>To register, please click the follow link: <a href='?url'>Link</a>`,
	InvitationWithCustomSubject: 'Motivo Invitation',
	InvitationWithCustomBody: `Dear ?name, <br/>You have been invited to the Motivo recruitment platform. <br/> <p>?message</p> <br/>To register, please click the follow link: <a href='?url'>Link</a>`
};
