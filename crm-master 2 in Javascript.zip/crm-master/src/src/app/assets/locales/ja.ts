export default {
	minLength: '?は短すぎます',
	format: '?のフォーマットは間違っています',
	enum: '?はリストを入っているはずです',
	required: '?を入力ください',
	match: '?は同じではないです',
	EmailAddress: 'メール',
	Password: 'パスワード',
	ConfirmPassword: 'パスワードの確認',
	greater: '?はほうが後はずです',
	RegistrationConfirmationEmailSubject: '登録確認必要あります',
	RegistrationConfirmationEmailBody: `?nameさん, <br/>Motivoのサービスで登録してありがとうございます。<br/>登録完了のため、このリンクを押してください；<a href='?url?confirmLink'>リンク</a>`,
	ResetPasswordEmailSubject: 'Reset password mail',
	ResetPasswordEmailBody: `Dear ?name, <br/>We have received a request to reset your password. <br/>To complete this action, please click the follow link: <a href='?url?confirmLink'>Link</a>`,
	ConfirmResetPasswordEmailSubject: 'Confirmed password reset mail',
	ConfirmResetPasswordEmailBody: `Dear ?name, <br/>You have successfully reset your password.`
};
