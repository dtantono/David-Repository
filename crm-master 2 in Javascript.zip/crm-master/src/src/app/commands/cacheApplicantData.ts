import { Opening } from '../models/Opening';

const db = require('../db/database');
import config from '../../../config';
import { asyncForEach } from '../helpers/arrayHelpers';

export const run = async () => {
	console.log('Running cache applicant data.');
	const data = await db.openings.newQuery().executeQuery(`
	SELECT opening, Meta(opening).id, ARRAY_COUNT(application) as ApplicationCount
	FROM ${config.DATABASE.NAME} opening
	left nest ${config.DATABASE.NAME} application on key application.OpeningId for opening
	where opening.type = "Opening"
`, false);
	await asyncForEach(data, async (openingData) => {
		const toUpdate = new Opening();
		toUpdate.fill(openingData.opening);
		const applicationCount = openingData.ApplicationCount || 0;
		toUpdate.ReadOnly = {
			ApplicationCount: applicationCount,
			VacanciesUnfilled: openingData.opening.RequiredCandidates - applicationCount
		};
		await db.openings.save(toUpdate);
	});
	console.log(`Finish cache applicant data`);
};
