import {Company} from "../models/Company";

const db = require('../db/database');
import { asyncForEach } from '../helpers/arrayHelpers';

export const run = async () => {
	console.log('Running cache company statistics.');
	const data = await db.companies.all();
	const countJobPosts = db.openings.newQuery().count('CompanyId');
	const countHires = db.applications.with('Opening')
		.where('Status', 6)
		.count('Opening.CompanyId');
	const countDropped = db.applications.with('Opening')
		.where('Status', 3)
		.count('Opening.CompanyId');
	let counts : any = {};
	await Promise.all([countJobPosts, countHires, countDropped]).then(data => {
		counts = {
			JobPosts: data[0],
			Hires: data[1],
			Dropped: data[2],
		}
	});
	await asyncForEach(data, async (company: Company) => {
		const myJobPosts = counts.JobPosts.filter(x => x.CompanyId === company.getFullKey());
		const myHires = counts.Hires.filter(x => x.CompanyId === company.getFullKey());
		const myDropped = counts.Dropped.filter(x => x.CompanyId === company.getFullKey());

		company.ReadOnly = {
			JobPosts: myJobPosts.length ? myJobPosts[0].count : 0,
			Hires: myHires.length ? myHires[0].count : 0,
			Dropped: myDropped.length ? myDropped[0].count : 0,
		};
		await db.companies.save(company);
	});
	console.log(`Finish cache applicant data`);
};
