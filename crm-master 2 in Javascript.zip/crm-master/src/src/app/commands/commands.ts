const CronJob = require('cron').CronJob;
const cacheApplicationData = require('./cacheApplicantData');
const cacheCompanyStatistics = require('./cacheCompanyStatistics');
const generateOpeningSearchTags = require('./generateOpeningSearchTags');

cacheApplicationData.run();
generateOpeningSearchTags.run();
cacheCompanyStatistics.run();

new CronJob('0 22 * * *', () => {
	const startTime = Date.now();
	console.log('Running daily tasks');
	cacheApplicationData.run();
	cacheCompanyStatistics.run();
	const timeDiff = Math.round((Date.now() - startTime) / 1000);
	console.log(`Finished daily tasks, taking ${timeDiff}s`);
}, null, true, 'Asia/Tokyo');
