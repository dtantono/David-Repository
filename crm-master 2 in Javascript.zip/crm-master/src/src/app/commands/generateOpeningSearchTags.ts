import {asyncForEach} from "../helpers/arrayHelpers";

const db = require('../db/database');
const aiService = require('../services/ai');
import config from '../../../config';

export const run = async () => {
	console.log('Running generate opening search tags.');

	const data = await db.openings.newQuery().executeQuery(`SELECT AdditionalSkills, Compensation, Description, Location, JobType, OtherRequirements, Position, RequiredEducation, RequiredExperience
	FROM ${config.DATABASE.NAME} opening WHERE opening.type = 'Opening'`, false);
	const tags = await aiService.generateOpeningTags(data);
	db.openings.newQuery().upsert('tags', tags);

	const data2 = await db.resumes.all();
	await asyncForEach(data2, async (resume) => {
		const tags = await aiService.generateResumeTags([resume]);
		resume.Tags = tags;
		await db.resumes.save(resume);
	});


	console.log(`Finish generate opening search tags.`);
};
