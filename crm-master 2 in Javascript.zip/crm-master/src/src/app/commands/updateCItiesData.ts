import * as http from "http";
import * as fs from "fs";
import {asyncForEach} from "../helpers/arrayHelpers";

const options = (locale: string, countryCode: string) => ({
	host: 'api.geonames.org',
	port: 80,
	path: `/searchJSON?formatted=true&lang=${locale}&username=XXX&cities=cities15000&country=${countryCode}`,
	method: 'GET'
});

export interface ICityInfo {
	adminCode1: string;
	lng: string;
	geonameId: number;
	toponymName: string;
	countryId: string;
	fcl: string;
	population: number;
	countryCode: string;
	name: string;
	fclName: string;
	adminCodes1: any;
	countryName: string;
	fcodeName: string;
	adminName1: string;
	lat: string;
	fcode: string;
}

const getRequest = async (options: object) => new Promise((resolve) => {
	console.log('Requesting ', `${options.host}/${options.path}`);
	http.request(options, function(res) {
		const chunks = [];
		res.on('data', data => chunks.push(data));
		res.on('end', () => {
			let body = JSON.parse(Buffer.concat(chunks));
			resolve(body)
		});
		res.on('error', (err) => resolve(err));
	}).end();
});
interface IResponseData {
	geonames: ICityInfo[]
}
function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

export const run = async () => {
	console.log('Getting city information.');
	fs.readFile( `${__dirname}/output/countries.json`,(err, data) => {
		const all = JSON.parse(data);
		const allResult = {};
		const total = Object.keys(all).length;
		asyncForEach(Object.keys(all), async (code, i) => {
			const data: IResponseData = await getRequest(options('ja', code));
			allResult[code] = {};
			data.geonames.forEach(x => allResult[code][x.toponymName] = { ja: x.name, name: x.toponymName });
			console.log(`${i} out of ${total}`);
			fs.writeFile(`${__dirname}/output/cities.json`, JSON.stringify(allResult), (err) => console.log(err));
			await sleep(1000);
		}).then(() => {
			console.log('your file is at: ', `${__dirname}/output/cities.json`);
		})
	});

	console.log(`Finish cache applicant data`);
};
