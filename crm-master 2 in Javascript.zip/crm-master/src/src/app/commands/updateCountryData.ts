import * as http from "http";
import * as fs from "fs";
import {error} from "util";

const options = (locale: string) => ({
	host: 'api.geonames.org',
	port: 80,
	path: `/countryInfoJSON?formatted=true&lang=${locale}&username=XXX`,
	method: 'GET'
});

export interface ICountryInfo {
	continent: string;
	capital: string;
	languages: string;
	geonameId: number;
	south: number;
	isoAlpha3: string;
	north: number;
	fipsCode: string;
	population: string;
	east: number;
	isoNumeric: string;
	areaInSqKm: string;
	countryCode: string;
	west: number;
	countryName: string;
	continentName: string;
	currencyCode: string;
}

const getRequest = async (options: object) => new Promise((resolve) => {
	console.log('Requesting ', `${options.host}/${options.path}`);
	http.request(options, function(res) {
		const chunks = [];
		res.on('data', data => chunks.push(data));
		res.on('end', () => {
			let body = JSON.parse(Buffer.concat(chunks));
			resolve(body)
		});
		res.on('error', (err) => resolve(err));
	}).end();
});
interface IResponseData {
	geonames: ICountryInfo[]
}
export const run = async () => {
	console.log('Getting country information.');
	await Promise.all([getRequest(options('en')), getRequest(options('ja'))]).then((data: [IResponseData, IResponseData]) => {
		const getList = (res: IResponseData) => res.geonames.reduce((t, x) => {
			t[x.countryCode] = { name: x.countryName};
			return t;
		}, {});
		const list = getList(data[1]);
		const newData = Object.keys(list).reduce((t, key) => {
			t[key].ja = list[key].name;
			return t;
		}, getList(data[0]));
		fs.writeFile(`${__dirname}/output/countries.json`, JSON.stringify(newData), (err) => console.log(err));
		console.log('your file is at: ', `${__dirname}/output/countries.json`);
	});
	console.log(`Finish cache applicant data`);
};
