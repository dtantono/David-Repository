import { Candidate, User } from '../models/Candidate';
import { getCandidateByEmailAddress, getThirdPartyUser, saveCandidate } from '../services/candidates';
import { BaseModel } from '../models/ModelRegister';

import * as passport from 'koa-passport';
import { Strategy as LocalStrategy } from 'passport-local';
import { ExtractJwt, Strategy as JWTStrategy } from 'passport-jwt';
import * as jwt from 'jsonwebtoken';
import * as db from '../db/database';
import * as helper from '../helpers/apiResponseHelper';
import * as bcrypt from 'bcrypt';
import { OAuth2Strategy as GoogleStrategy } from 'passport-google-oauth';
import { Strategy as LinkedInStrategy } from 'passport-linkedin-oauth2';
import { Strategy as GithubStrategy } from 'passport-github';
import { JWT } from '../models/JWT';
import { Account } from '../models/Account';

import config from '../../../config';
import { getRecruiterUserByEmail } from '../services/recruiters';
import {getCompanyUserByEmailAddress, getCompanyUserByEmailAddressWithCompany} from "../services/companies";
import {RecruiterUser} from "../models/RecruiterUser";
import {CompanyUser, CompanyUserWithRecruiterId} from "../models/CompanyUser";
const expiryTime = 86400;

passport.serializeUser((user, done) => {
	done(null, user.id);
});

passport.deserializeUser((user, done) => {
	done(null, user);
});

passport.use(new LocalStrategy({
	// by default, local strategy uses username and password, we will override with email
	usernameField: 'EmailAddress',
	passwordField: 'Password',
	passReqToCallback: true // allows us to pass back the entire request to the callback
}, async (ctx, EmailAddress, Password, done) => {
	let user : Candidate | RecruiterUser | CompanyUser;
	switch (ctx.body.type) {
		case 'Candidate':
			user = await getCandidateByEmailAddress(EmailAddress);
			break;
		case 'Recruiter':
			user = await getRecruiterUserByEmail(EmailAddress);
			break;
		case 'Company':
			user = await getCompanyUserByEmailAddress(EmailAddress);
			break;
		default:
			user = await getCandidateByEmailAddress(EmailAddress);
			break;
	}
	// if not, supplied an authentication problem response
	if (!user) {
		return done({ Code: 400, Error: { Password: 'Invalid credentials. Please try again or click the sign up link.' } });
	}
	if (user.Active) {
		if (bcrypt.compareSync(Password, user.HashPassword)) {
			return done(user);
		}
		return done({ Code: 400, Error: { Password: 'Invalid credentials. Please try again or click the sign up link.' } });
	}
	return done({ Code: 400, Error: { EmailAddress: 'Please confirm your email first.' } });
}));

interface JWTPayload {
	id: string,
	type: string
	exp: number,
	iat: number
}
passport.use('jwt', new JWTStrategy({
	jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
	secretOrKey: config.secret
}, async (jwtPayload : JWTPayload, cb) => {
	if (!await db.jwt.find(jwtPayload.exp.toString())) {
		let account;
		switch (jwtPayload.type) {
			case 'Candidate':
				account = await db.accounts.find(jwtPayload.id);
				break;
			case 'Recruiter':
				account = await db.recruiterUsers.find(jwtPayload.id);
				break;
			case 'Company':
				account = await db.companyUsers.with('Company').where('id', jwtPayload.id).first();
				account.RecruiterId = account.Relations.Company.RecruiterId;
				break;
			default:
				break;
		}
		return cb({ ...account, type: jwtPayload.type, id: account.getFullKey() } as Account | CompanyUserWithRecruiterId | RecruiterUser);
	}
	return cb(null);
}
));

export const authError = (ctx) => {
	if (ctx.body === undefined) {
		ctx.status = 401;
		ctx.body = helper.apiError('You are not authorised', ctx.status);
	}
};

export const sign = (accountId, type) => jwt.sign({ id: accountId, type: type }, config.secret, {
	expiresIn: expiryTime // expires in 24 hours
});

async function getFunction(ctx, id: string, type: string) {
	let data : User;
	switch (ctx.body.type) {
		case 'Candidate':
			data = await getThirdPartyUser(id, type);
			return data ? data : new Candidate();
		default:
			data = await getThirdPartyUser(id, type);
			return data ? data : new Candidate();
	}
}

async function saveFunction(ctx, details) {
	let saveFunc: (model: BaseModel) => any;
	switch (ctx.body.type) {
		case 'Candidate':
			saveFunc = saveCandidate;
			break;
		default:
			saveFunc = saveCandidate;
			break;
	}
	return await saveFunc(details);
}

passport.use(new GoogleStrategy({
	clientID: config.google.clientId,
	clientSecret: config.google.secret,
	callbackURL: `${config.url}/api/auth/google/callback`,
	passReqToCallback: true
}, async (ctx, accessToken, refreshToken, profile, done) => {
	const user = await getFunction(ctx, profile.id, 'google');
	if (!user.hasOwnProperty('EmailAddress')) {
		user.fill({
			ThirdPartyId: profile.id,
			ThirdPartyType: 'google',
			FirstName: profile.name.givenName,
			LastName: profile.name.familyName,
			EmailAddress: profile.emails[0].value,
			Active: false,
			type: ctx.body.type
		});
		const ret: ThirdPartyUser = { NewUser: true, User: user };
		await saveFunction(ctx, user);
		done(null, ret);
	}
	const ret: ThirdPartyUser = { NewUser: false, User: user };
	done(null, ret);
}));

export interface ThirdPartyUser {
	NewUser: boolean,
	User: User
}

passport.use(new LinkedInStrategy({
	clientID: config.linkedin.clientId,
	clientSecret: config.linkedin.secret,
	callbackURL: `${config.url}/api/auth/linkedin/callback`,
	passReqToCallback: true
}, async (ctx, accessToken, refreshToken, profile, done: (error: string, user: ThirdPartyUser) => void) => {
	const user = await getFunction(ctx, profile.id, 'linkedin');
	if (!user.hasOwnProperty('EmailAddress')) {
		user.fill({
			ThirdPartyId: profile.id,
			ThirdPartyType: 'linkedin',
			FirstName: profile.name.givenName,
			LastName: profile.name.familyName,
			EmailAddress: profile.emails[0].value,
			Active: false,
			type: ctx.body.type
		});
		const ret: ThirdPartyUser = { NewUser: true, User: user };
		await saveFunction(ctx, user);
		done(null, ret);
	}
	const ret: ThirdPartyUser = { NewUser: false, User: user };
	done(null, ret);
}));

passport.use(new GithubStrategy({
	clientID: config.github.clientId,
	clientSecret: config.github.secret,
	passReqToCallback: true
}, async (ctx, accessToken, refreshToken, profile, done) => {
	const user = await getFunction(ctx, profile.id, 'github');
	if (!user.hasOwnProperty('EmailAddress')) {
		user.fill({
			ThirdPartyId: profile.id,
			ThirdPartyType: 'github',
			FirstName: profile._json.name ? profile._json.name.split(' ')[0] : '',
			LastName: profile._json.name ? profile._json.name.split(' ')[1] : '',
			EmailAddress: profile._json.email ? profile._json.email : '',
			GithubHandle: profile.username,
			Active: false,
			type: ctx.body.type
		});
		const ret: ThirdPartyUser = { NewUser: true, User: user };
		await saveFunction(ctx, user);
		done(null, ret);
	}
	const ret: ThirdPartyUser = { NewUser: false, User: user };
	done(null, ret);
}));

export const expire = async (ctx) => {
	await new Promise((resolve) => {
		passport.authenticate('jwt', { session: false }, async (user) => {
			if (user) {
				const jwt = new JWT();
				jwt.fill({ UserId: user.id, id: user.exp });
				const result = await db.jwt.save(jwt);
				resolve(result);
			}
			resolve(null);
		})(ctx);
	});
};
