import { BaseModel } from '../models/ModelRegister';
import * as bcrypt from 'bcrypt';
import { Candidate } from '../models/Candidate';
import * as auth from './auth';
import * as hash from '../helpers/hash';
import { wrapResponse } from './main';

const helper = require('../helpers/apiResponseHelper');
import { validate } from '../helpers/validation/Validation';
const recruiterService = require('../services/recruiters');
const mailer = require('../helpers/mailer');
const passport = require('koa-passport');
import config from '../../../config';
import {Account} from "../models/Account";
import {randomKey} from "../helpers/hash";
const type = 'Candidate';
const candidateService = require('../services/candidates');
const infoService = require('../services/info');

// AUTHENTICATION --------
// Login function
export const loginThirdParty = async (ctx, thirdParty) => {
	ctx.request.body.type = type;
	const res: (auth.ThirdPartyUser | null) = await new Promise((resolve) => {
		passport.authenticate(thirdParty, { failureRedirect: `${config.candidateUrl}/login` }, (err: string, user: auth.ThirdPartyUser) => {
			if (err) {
				console.log(err);
				resolve(null);
			}
			resolve(user);
		})(ctx);
	}) as auth.ThirdPartyUser;
	if (res) {
		const candidate = res.User as Candidate;
		if (res.NewUser || !candidate.Active) {
			const key = hash.createRegistrationKey(
				candidate.getFullKey(),
				candidate.EmailAddress,
				candidate.ThirdPartyId
			);
			const redirect_url = `${config.candidateUrl}/register/information/${candidate.getKey()}?AuthKey=${key}&FirstName=${
				candidate.FirstName ? encodeURIComponent(candidate.FirstName) : ''
				}&LastName=${candidate.LastName ? encodeURIComponent(candidate.LastName) : ''}&EmailAddress=${
				candidate.EmailAddress ? candidate.EmailAddress : ''
				}`;
			console.log(redirect_url);
			ctx.redirect(redirect_url);
			return;
		}
		const activeAccount = await candidateService.getActiveAccount(candidate.getFullKey());
		const token = auth.sign(activeAccount.getFullKey(), type);
		ctx.redirect(`${config.candidateUrl}/auth?token=${token}`);
		return;
	}
	ctx.body = 'Error, code already use (please get a new one)';
};

export const login = async (ctx) => {
	// first validate the json
	const valErrors = await validate(ctx, 'loginSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// check that the user exists in the database
		ctx.request.body.type = 'Candidate';
		const result = await new Promise((resolve) => {
			passport.authenticate('local', { session: false }, async (user: BaseModel | any) => {
				if (user.Error === undefined) {
					const activeAccount = await candidateService.getActiveAccount(user.getFullKey());
					const token = auth.sign(activeAccount.getFullKey(), user.getType());
					ctx.status = 200;
					// Invitation - if the url contains a query
					if (ctx.query.key) {
						const relation = await candidateService.getAccountById(ctx.query.key);
						if (
							hash.isRegistrationKeyValid(ctx.query.key, user.FirstName, user.EmailAddress, relation.CreatedAt)
						) {
							relation.Candidate = user.getFullKey();
							relation.UpdatedAt = Date.now();
							await candidateService.saveAccount(relation);
						}
					}
					resolve({ token: token, UserId: activeAccount.getFullKey() });
				} else {
					ctx.status = user.Code;
					ctx.body = helper.apiError(user.Error, ctx.status);
					resolve(false);
				}
			})(ctx);
		});
		if (result) {
			ctx.body = helper.apiResponse(result, ctx.status);
		}
	}
};

// Logout function
export const logout = async (ctx) => {
	// simply expire the JWT token, as next time it's supplied, it wont be valid
	await auth.expire(ctx);
	ctx.status = 204;
};
// AUTHENTICATION --------

// REGISTRATION --------

export const validatePersonalInformation = async (ctx) => {
	const valErrors = await validate(ctx, 'candidatePersonalInformationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const data = await candidateService.getCandidateByEmailAddress(ctx.request.body.EmailAddress);
		if (data && data.length !== 0) {
			ctx.status = 400;
			ctx.body = helper.apiError([{ EmailAddress: 'This user already exists within the system' }], ctx.status);
			return;
		}
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
	}
};

export const getPersonality = async (ctx) => {
	const res = await candidateService.getPersonalityQuestions(ctx.request.user.AccountEntityId);
	return wrapResponse(res, ctx);
};
export const getPersonalitySkills = async (ctx) => {
	const res = await candidateService.getPersonalityQuestions(ctx.request.user.AccountEntityId);
	const skills = (await infoService.getKeyValue()).FeatureSkills;
	return wrapResponse(res.Skills ? Object.keys(res.Skills).map(skill => ({
		...skills[skill], ...{
			level: res.Skills[skill],
			name: skill
		}
	})) : [], ctx);
};

export const registerPersonality = async (ctx) => {
	await candidateService.updatePersonalityQuestions(ctx.request.user.AccountEntityId, ctx.request.body);
	ctx.status = 204;
};

// Register function
export const register = async (ctx) => {
	// first validate the json
	const valErrors = await validate(ctx, ctx.request.body.hasOwnProperty('UserId') ? 'candidateRegistrationThirdPartySchema' : 'candidateRegistrationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// check if the user exists in the database already
		let data = await candidateService.getCandidateByEmailAddress(ctx.request.body.PersonalInformation.EmailAddress);
		let notDuplicate = true;
		if (ctx.request.body.UserId) {
			const authkey = ctx.query.AuthKey;
			data =
				data && data.id === `Candidate/${ctx.request.body.UserId}` ?
					data :
					await candidateService.getCandidateById(`Candidate/${ctx.request.body.UserId}`, false);
			notDuplicate = !hash.isRegistrationKeyValid(
				authkey,
				ctx.request.body.UserId,
				data.EmailAddress,
				data.ThirdPartyId
			);
		} else {
			notDuplicate = data === null;
		}
		// If the user doesn't exist, then proceed, otherwise reject the registration
		if (notDuplicate) {
			// fit the body into the model
			let newCandidate;
			if (ctx.request.body.hasOwnProperty('UserId')) {
				const details = ctx.request.body.Account;
				details.Active = true;
				newCandidate = await candidateService.updateCandidateById(
					ctx.request.body.UserId,
					false,
					details
				);
			} else {
				newCandidate = await candidateService.register(ctx.request.body);
			}
			// Invitation
			// if the url contains a query
			if (ctx.query.key) {
				// update the relation object
				const relation : Account = await candidateService.getAccountByInvitationKey(ctx.query.key);
				if (relation) {
					relation.AccountEntityId = newCandidate.getFullKey();
					relation.DeletedAt = 0;
					await candidateService.saveAccount(relation);
				}
				// TODO what should happen if the invitation fails
			}
			const adminRecruiter = await recruiterService.getAdminRecruiter();
			const RecruiterId = adminRecruiter.getFullKey();
			const account = await candidateService.createAccount(newCandidate.getFullKey(), RecruiterId);

			if (!ctx.request.body.hasOwnProperty('UserId')) {
				const confirmationKey = hash.createRegistrationKey(
					newCandidate.getFullKey(),
					newCandidate.EmailAddress,
					newCandidate.CreatedAt
				);
				mailer.sendRegistrationMail(
					ctx.request.user.Locale,
					newCandidate.EmailAddress,
					newCandidate.FirstName,
					`/api/candidates/register/confirm?key=${confirmationKey}&email=${encodeURIComponent(
						newCandidate.EmailAddress
					)}`
				);
			}
			ctx.status = 200;
			const token = auth.sign(account.getFullKey(), type);
			const payload = {
				token: token
			};
			// Add response.body to avoid JSON error on frontend
			ctx.body = helper.apiResponse(payload, ctx.status);
		} else {
			ctx.status = 409;
			ctx.body = helper.apiError({ EmailAddress: 'This user already exists' }, ctx.status);
		}
	}
};

// RECRUITERS --------

export const checkPassword = async (ctx) => {
	let valErrors: any = await validate(ctx, 'checkPasswordSchema');
	const candidate = await candidateService.getCandidateById(ctx.request.user.AccountEntityId, false);
	const authorised = bcrypt.compareSync(ctx.request.body.CurrentPassword, candidate.HashPassword);
	if (!authorised) {
		valErrors = valErrors ? valErrors : [];
		valErrors = {...valErrors, ...{ CurrentPassword: 'Incorrect password, try again.' }};
	}
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
	}
};

export const confirmRegistration = async (ctx) => {
	if (ctx.query.key !== '' && ctx.query.email !== '') {
		const candidate = await candidateService.getCandidateByEmailAddress(ctx.query.email);
		if (candidate) {
			if (hash.isRegistrationKeyValid(ctx.query.key, candidate.getFullKey(), candidate.EmailAddress, candidate.CreatedAt)) {
				candidate.Active = true;
				await candidateService.saveCandidate(candidate);
				ctx.status = 302;
				ctx.set({ Location: `${config.candidateUrl}/login?message=Email address confirmed` });
				return;
			}
		}
	}
	ctx.status = 302;
	ctx.set({ Location: `${config.candidateUrl}/login?message=Email confirmation failed` });
};
