import * as companyService from '../services/companies';
const passport = require('koa-passport');
import * as recruiterService from '../services/recruiters';
import * as auth from './auth';
import * as helper from '../helpers/apiResponseHelper';
import * as hash from '../helpers/hash';
import * as mailer from '../helpers/mailer';
import * as db from '../db/database';
import { validate } from '../helpers/validation/Validation';
import {BaseModel} from "../models/ModelRegister";
import {ICompanyContext} from "../models/GlobalClasses";
import {wrapResponse} from "./main";

const type = 'Company';

// AUTHENTICATION
export const validateSignup = async (ctx) => {
	const valErrors = await validate(ctx, 'recruiterRegisterSignupSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const data = await companyService.getCompanyUserByEmailAddress(ctx.request.body.EmailAddress);
		if (data) {
			ctx.status = 400;
			ctx.body = helper.apiError({ EmailAddress: 'This user already exists within the system' }, ctx.status);
			return;
		}
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
	}
};

export const register = async (ctx) => {
	// first validate the json
	const valErrors = await validate(ctx, 'companyRegistrationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const details : recruiterService.IRecruiterRegister = ctx.request.body;
		// check if the user exists in the database already
		const member = await companyService.getCompanyUserByEmailAddress(details.Signup.EmailAddress);
		// If the user doesn't exist, then proceed, otherwise reject the registration
		if (member) {
			ctx.status = 400;
			ctx.body = helper.apiError({EmailAddress: 'This email already exists'}, ctx.status);
		} else {
			const companyUser = await companyService.registerCompany(details, ctx.params.key);
			// enter into the database
			const token = auth.sign(companyUser.getFullKey(), type);
			const payload = { token: token };
			ctx.status = 200;
			ctx.body = helper.apiResponse(payload, ctx.status);
		}
	}
};

export const getMyCompany = async (ctx : ICompanyContext) => {
	let res;
	if(ctx.request.user.type === 'Company') {
		res = await companyService.getCompanyWithOpeningsById(ctx.request.user.CompanyId);
	}
	return await wrapResponse(res, ctx);
};

export const inviteMember = async (ctx) => {
	// check if company is logged in
	if (ctx.request.user === null) {
		auth.authError(ctx);
	} else {
		// MEMBER
		// check if user already in members list
		const member = await db.companyUsers.newQuery().where('EmailAddress', ctx.request.body.EmailAddress).first();
		if (member) {
			ctx.status = 400;
			ctx.body = helper.apiError('already exists', ctx.status);
		} else {
			// store initial information
			const details = {
				EmailAddress: ctx.request.body.EmailAddress,
				FirstName: ctx.request.body.FirstName,
				LastName: ctx.request.body.LastName,
				Active: false,
				Role: 1
			};
			// create a member
			const newMember = await companyService.createMember(ctx.request.user.RecruiterId, details);
			// MAIL
			// create key
			const invitationKey = hash.createRegistrationKey(
				details.FirstName,
				details.EmailAddress,
				Date.now()
			);
			// send invitation
			mailer.sendRegistrationMail(
				ctx.request.user.Locale,
				details.EmailAddress,
				details.FirstName,
				`/api/companies/members/${newMember.getKey()}/register?&key=${invitationKey}`
			);
			ctx.status = 201;
			ctx.body = helper.apiResponse(
				{ invitationKey, id: newMember.getKey() },
				ctx.status
			);
		}
	}
};

export const registerCompleteInvitation = async (ctx) => {
	if (!('key' in ctx.query)) {
		ctx.status = 400;
		ctx.body = helper.apiError('You have not been invited', ctx.status);
		return;
	}
	const valErrors = await validate(ctx, 'companyUserRegistrationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	// when member click link in email (from registerInvitation) he has to register missing details
	const member = await db.companyUsers.newQuery().where('InvitationKey', ctx.query.key).first();
	if (!member) {
		ctx.status = 400;
		ctx.body = helper.apiError('No invitation exists', ctx.status);
		return;
	}
	member.fill({ ...ctx.request.body.Personal, ...ctx.request.body.Signup, Active: true });
	await companyService.saveCompanyUser(member);
	const token = auth.sign(member.getFullKey(), type);
	ctx.status = 200;
	ctx.body = helper.apiResponse({ token: token }, ctx.status);
};

export const getMembers = async (ctx) => {
	if (ctx.request.user && ctx.request.user.type === 'Company') {
		const members = await companyService.getCompanyUsersByCompanyId(ctx.request.user.RecruiterId);
		if (members) {
			ctx.status = 200;
			ctx.body = helper.apiResponse(members, ctx.status);
			return;
		}
	} else {
		auth.authError(ctx);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError('An error occurred', ctx.status);
};

export const login = async (ctx) => {
	// first validate the json
	const valErrors = await validate(ctx, 'loginSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// check that the user exists in the database
		ctx.request.body.type = 'Company';
		const result = await new Promise((resolve) => {
			passport.authenticate('local', { session: false }, async (user: BaseModel | any) => {
				if (user.Error === undefined) {
					const activeAccount = await companyService.getCompanyUserById(user.getFullKey(), false);
					const token = auth.sign(activeAccount.getFullKey(), type);
					ctx.status = 200;
					resolve({ token: token, UserId: activeAccount.getFullKey() });
				} else {
					ctx.status = user.Code;
					ctx.body = helper.apiError(user.Error, ctx.status);
					resolve(false);
				}
			})(ctx);
		});
		if (result) {
			ctx.body = helper.apiResponse(result, ctx.status);
		}
	}
};

export const logout = async (ctx) => await auth.expire(ctx);
