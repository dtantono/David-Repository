import {IContext} from "../models/GlobalClasses";
import * as localisationService from "../services/localisation";

const info = require('../services/info');
const apiHelper = require('../helpers/apiResponseHelper');

info.getReferenceData();

export const getReferenceData = async (ctx) => {
	const result = await info.getReferenceData();
	if (ctx.request.query.filter) {
		let toReturn = Object.assign({}, ctx.request.query.filter.split(',').reduce((t, x) => {
			let all = result[x];
			if (x === 'Cities') {
				const cityFilter = ctx.request.query.filter2 || 'JP';
				all = all[cityFilter];
			}
			all = ctx.request.query.query ? Object.keys(all).reduce((t2,x2) => {
				if (all[x2].name.toLowerCase().includes(ctx.request.query.query.toLowerCase()) ||
					(all[x2].ja && all[x2].ja.includes(ctx.request.query.query))) {
					t2[x2] = all[x2];
				}
				return t2;
			}, {}) : all;

			t[x] = info.jsonToNameValue(all, ['Cities', 'Countries'].includes(x) ? 'en' : ctx.request.user.Locale);
			return t;
		}, {}));

		ctx.status = 200;
		ctx.response.body = apiHelper.apiResponse(toReturn, 200);
		return;
	}
	ctx.status = 200;
	ctx.response.body = apiHelper.apiResponse(await info.getNameValue(result), 200);
	// ctx.response.body = apiHelper.apiResponse(result, 200);
};

export const createWord = async (ctx : IContext) => {
	ctx.status = 200;
	ctx.body = await localisationService.createWord(ctx.params.word, ctx.request.body);
};
export const deleteWord = async (ctx : IContext) => {
	ctx.status = 200;
	ctx.body = await localisationService.deleteWord(ctx.params.word);
};
export const updateWord = async (ctx : IContext) => {
	ctx.status = 200;
	ctx.body = await localisationService.updateWord(ctx.params.word, ctx.request.body);
};

export const getAllWords = async (ctx: IContext) => {
	ctx.status = 200;
	ctx.body = (await localisationService.getAll()).Words;
};