// VALIDATION
import { Application } from '../models/Application';
import { Event } from '../models/Event';
import { Opening } from '../models/Opening';
import {Candidate, User} from '../models/Candidate';
import {apiResponse} from '../helpers/apiResponseHelper';
import * as cache from '../helpers/cache';
import * as bcrypt from 'bcrypt';
import { authError } from './auth';
import {IRequest, validate} from '../helpers/validation/Validation';
import config from "../../../config";
import * as fs from 'fs';
import * as csv from "fast-csv";
import {RecruiterUser} from "../models/RecruiterUser";
import {CompanyUser, CompanyUserWithRecruiterId} from "../models/CompanyUser";
import {Account} from "../models/Account";
import {ICandidateContext, ICompanyContext, IContext, IRecruiterContext} from "../models/GlobalClasses";
import {Resume} from "../models/Resume";

// SERVICES
const eventsService = require('../services/events');
const openingService = require('../services/openings');
const resumesService = require('../services/resumes');
const pipelinesService = require('../services/pipelines');
const recruiterService = require('../services/recruiters');
const applicationService = require('../services/applications');
const candidateService = require('../services/candidates');
const companyService = require('../services/companies');
const notificationService = require('../services/notifications');
const messagesService = require('../services/messages');

// HELPERS
const auth = require('./auth');
const helper = require('../helpers/apiResponseHelper');
const hash = require('../helpers/hash');
const mailer = require('../helpers/mailer');
const paginator = require('../helpers/paginate');

export const wrapResponse = async (res, ctx, goodStatusCode = 200) => {
	const response = await res;
	ctx.status = response === null ? 404 : goodStatusCode;
	ctx.body = response === null ? helper.apiError('An error occurred', ctx.status) : helper.apiResponse(response, ctx.status);
};

// Request reset password function
export const requestResetPassword = async (ctx : IContext, type : string) => {
	const valErrors: any = await validate(ctx, 'requestResetPasswordSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		let user : User, saveFunction : (user: User) => void, mailFunction: (locale : string, receiveeEmail : string, receiveeName : string, confirmationLink : string) => void;
		switch(type) {
			case 'Candidate':
				user = await candidateService.getCandidateByEmailAddress(ctx.request.body.EmailAddress);
				saveFunction = candidateService.saveCandidate;
				mailFunction = mailer.sendResetPasswordMail;
				break;
			case 'Recruiter':
				user = await recruiterService.getRecruiterUserByEmail(ctx.request.body.EmailAddress);
				saveFunction = recruiterService.saveAccount;
				mailFunction = mailer.sendRecruiterResetPasswordMail;
				break;
			case 'Company':
				user = await companyService.getCompanyUserByEmailAddress(ctx.request.body.EmailAddress);
				saveFunction = companyService.saveCompanyUser;
				mailFunction = mailer.sendCompanyResetPasswordMail;
				break;
			default:
				break;
		}
		if (user) {
			const confirmationKey = hash.randomKey(20);
			user.ResetPasswordToken = confirmationKey;
			await saveFunction(user);
			mailFunction(
				ctx.request.user.Locale,
				user.EmailAddress,
				user.FirstName,
				`/reset/password?key=${confirmationKey}&email=${encodeURIComponent(user.EmailAddress)}`
			);
		}
		ctx.status = 200;
		ctx.body = helper.apiResponse(
			'If this user exists in the system, then you will receive an email shortly.',
			ctx.status
		);
	}
};

// Reset password function
export const resetPassword = async (ctx : IContext, type : string) => {
	const valErrors = await validate(ctx, 'resetPasswordSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	let user : User, saveFunction : (user: User) => void, mailFunction: (locale : string, receiveeEmail : string, receiveeName : string) => void;
	switch(type) {
		case 'Candidate':
			user = await candidateService.getCandidateByEmailAddress(ctx.query.email);
			saveFunction = candidateService.saveCandidate;
			mailFunction = mailer.sendResetPasswordConfirmationMail;
			break;
		case 'Recruiter':
			user = await recruiterService.getRecruiterUserByEmail(ctx.query.email);
			saveFunction = recruiterService.saveAccount;
			mailFunction = mailer.sendResetPasswordConfirmationMail;
			break;
		case 'Company':
			user = await companyService.getCompanyUserByEmailAddress(ctx.query.email);
			saveFunction = companyService.saveCompanyUser;
			mailFunction = mailer.sendResetPasswordConfirmationMail;
			break;
		default:
			break;
	}
	if (user) {
		const authorised = ctx.query.key === user.ResetPasswordToken && user.ResetPasswordToken !== '';
		if (authorised) {
			user.updatePassword(ctx.request.body.Password);
			await saveFunction(user);
			mailFunction(ctx.request.user.Locale, user.EmailAddress, user.FirstName);
			ctx.status = 200;
			ctx.body = helper.apiResponse('success', ctx.status);
			return;
		}
		ctx.status = 400;
		ctx.body = helper.apiError({ Password: 'Password reset failed'}, ctx.status);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError({ Password: 'Password reset failed'}, ctx.status);
};

// EXPORTS AND FUNCTIONS
export const timeline = async (ctx : IContext) => {
	interface timelineEvent {
		Date: number,
		Description: string,
		Type: string
	}

	const companyFilterId : string = ctx.query.CompanyId;

	const applications = companyFilterId ?
		await applicationService.getApplicationsByCandidateIdAndCompanyId(ctx.request.user.id, companyFilterId)
		: await applicationService.getApplicationsByCandidateId(ctx.request.user.id);

	const account = await candidateService.getAccountById(ctx.request.user.id);
	const timeline: timelineEvent[] = [];
	timeline.push({ Date: account.CreatedAt, Description: 'You joined Motivo!', Type: 'Notes' });
	applications.forEach((application) => {
		timeline.push({
			Date: application.CreatedAt,
			Description: `Applied for [${application.Opening.Position}] with [${application.Company.CompanyName}]`,
			Type: 'Calls'
		});
		if (application.RejectionReason !== '') {
			timeline.push({
				Date: application.ActionDate,
				Description: `Rejected for [${application.Opening.Position}] with [${application.Company.CompanyName}]`,
				Type: 'Log Activity'
			});
		}
	});
	ctx.status = 200;
	ctx.body = apiResponse(timeline.sort((a, b) => a.Date - b.Date), ctx.status);
};
export const profile = async (ctx : IContext) => {
	let data;

	const promises = [];
	const cachedBody = await cache.get(ctx.request.user.id, 'profile');
	switch (ctx.request.user.type) {
		case 'Candidate':
			if (cachedBody) {
				data = cachedBody;
				break;
			}
			promises.push(candidateService.getCandidateById((ctx as ICandidateContext).request.user.AccountEntityId, true));
			promises.push(recruiterService.getRecruiterById(ctx.request.user.RecruiterId, true));
			await Promise.all(promises).then((values) => {
				data = { Candidate: {...values[0], Locale: ctx.request.user.Locale}, Recruiter: values[1] };
			});
			cache.put(ctx.request.user.id, 'profile', data);
			break;
		case 'Recruiter':
			data = await recruiterService.getRecruiterUserById(ctx.request.user.id, true);
			break;
		case 'Company':
			data = await companyService.getCompanyUserById(ctx.request.user.id, true);
			break;
		default:
			data = null;
			break;
	}

	return await wrapResponse(data, ctx);
};

export const updateLocale = async (ctx : IContext) => {
	if (['en', 'ja'].includes(ctx.params.locale)) {
		let account : Account | RecruiterUser | CompanyUser = null;

		const updateLocale = (x : Account | RecruiterUser | CompanyUser) => { x.Locale = ctx.params.locale };
		let updateFunction : (user: Account | RecruiterUser | CompanyUser) => Promise<any> = null;

		switch (ctx.request.user.type) {
			case 'Candidate':
				account = await candidateService.getAccountById(ctx.request.user.id);
				updateFunction = candidateService.saveAccount;
				break;
			case 'Recruiter':
				account = await recruiterService.getRecruiterUserById(ctx.request.user.id, false);
				updateFunction = recruiterService.saveRecruiterUser;
				break;
			case 'Company':
				account = await candidateService.getAccountById(ctx.request.user.id);
				updateFunction = companyService.saveCompanyUser;
				break;
			default:
				break;
		}

		updateLocale(account);
		await updateFunction(account);
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiResponse('failed', ctx.status);
};

export const changePassword = async (ctx : IContext) => {
	let valErrors: any = await validate(ctx, 'changePasswordSchema');
	let user, service;
	switch(ctx.request.user.type) {
		case 'Candidate':
			user = await candidateService.getCandidateById((ctx as ICandidateContext).request.user.AccountEntityId, false);
			service = candidateService;
			break;
		case 'Recruiter':
			user = await recruiterService.getRecruiterUserById(ctx.request.user.id, false);
			service = recruiterService;
			break;
		case 'Company':
			user = await companyService.getCompanyUserById(ctx.request.user.id, false);
			service = companyService;
			break;
		default:
			break;
	}
	const authorised = bcrypt.compareSync(ctx.request.body.CurrentPassword, user.HashPassword);
	if (!authorised) {
		valErrors = {...valErrors, CurrentPassword: 'Incorrect, try again.'}
	}
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else if (user) {
		await service.resetPassword(user, ctx.request.body.Password);
		mailer.sendResetPasswordConfirmationMail(ctx.request.user.Locale, user.EmailAddress, user.FirstName);
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
	} else {
		ctx.status = 400;
		ctx.body = helper.apiError('There was a mistake processing your request.', ctx.status);
	}
};

export const updateProfile = async (ctx : IContext) => {
	// var model = null;
	let valErrors : any = [{ Error: 'An error occurred' }];
	let updateFunction : (id: string, details: object) => Promise<any>;
	switch (ctx.request.user.type) {
		case 'Candidate':
			valErrors = await validate(ctx, 'candidateUpdateProfileSchema');
			updateFunction = (id: string, details: object) => candidateService.updateCandidateById(id, true, details);
			break;
		case 'Recruiter':
			valErrors = await validate(ctx, 'recruiterUserUpdateProfileSchema');
			updateFunction = recruiterService.updateRecruiterUserById;
			break;
		case 'Company':
			valErrors = await validate(ctx, 'recruiterUserUpdateProfileSchema');
			updateFunction = companyService.updateCompanyUserById;
			break;
		default:
			break;
	}
	if (!valErrors) {
		const result = await updateFunction(ctx.request.user.id, ctx.request.body);
		if (result) {
			ctx.status = 200;
			ctx.body = helper.apiResponse('success', ctx.status);
			return;
		}
	}
	ctx.status = 400;
	ctx.body = helper.apiError(valErrors, ctx.status);
};

export const uploadPicture = async (ctx : IContext) => {
	// var model = null;
	const valErrors : any = await validate(ctx, 'updateProfilePicture');
	let updateFunction : (id: string, details: object) => Promise<Candidate | RecruiterUser | CompanyUser>;
	switch (ctx.request.user.type) {
		case 'Candidate':
			updateFunction = (id: string, details: object) => candidateService.updateCandidateById(id, true, details);
			break;
		case 'Recruiter':
			updateFunction = recruiterService.updateRecruiterUserById;
			break;
		case 'Company':
			updateFunction = companyService.updateCompanyUserById;
			break;
		default:
			break;
	}
	if (!valErrors) {
		const result = (await updateFunction(ctx.request.user.id, ctx.request.body)).public();
		if (result) {
			ctx.status = 200;
			ctx.body = helper.apiResponse(result.ProfilePicture, ctx.status);
			return;
		}
	}
	ctx.status = 400;
	ctx.body = helper.apiError(valErrors, ctx.status);
};

// EVENTS --------
// get events function
export const getEvents = async (ctx : IContext) => {
	// get all events by user
	const data = await eventsService.getEventsByUser(ctx.request.user);
	// even if the user has no events, data would be supplied and therefore if it's null there has been a big error
	if (data === null) {
		ctx.status = 500;
		ctx.body = helper.apiError('Database error', ctx.status);
	} else {
		// finally return the array back to the user
		ctx.status = 200;
		ctx.body = helper.apiResponse(
			data,
			ctx.status
		);
	}
};
// get a single event function
export const getEvent = async (ctx : IContext) => {
	// get the single event from the database
	const event = await eventsService.getEventsByIdAndUserId(ctx.params.id, ctx.request.user);
	return await wrapResponse(event ? event.public() : null, ctx);
};
// create event function
export const createEvent = async (ctx : IContext) => {
	// first validate the json
	const valErrors = await validate(ctx, 'eventRegistrationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const json = ctx.request.body;
		await eventsService.create(json, ctx.request.user.id);
		ctx.status = 201;
	}
};

export const deleteEvent = async (ctx : IContext) => {
	const result = await eventsService.deleteEvent(
		ctx.params.id,
		ctx.request.user.id
	);
	if(result) {
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError('Not authorised', ctx.status);
};

// update event function
export const updateEvent = async (ctx : IContext) => {
	// first validate the json body
	const valErrors = await validate(ctx, 'eventRegistrationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// if there are no problems, then update the candidate event
		const result = await eventsService.updateEvent(ctx.params.id, ctx.request.body, ctx.request.user.id);
		if (result) {
			ctx.status = 201;
		} else {
			ctx.status = 400;
			ctx.body = helper.apiError('Event not found', ctx.status);
		}
	}
};
// EVENTS --------

// RESUMES --------
export const validateResumePart = async (ctx : IContext, section: string) => {
	const valErrors = await validate(ctx, section);
	if (!valErrors) {
		ctx.status = 200;
		ctx.body = helper.apiResponse('', ctx.status);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError(valErrors, ctx.status);
};

// get resumes
export const getResumes = async (ctx : IContext) => {
	// get all resumes by user
	const data = await resumesService.getResumesByUser(ctx.request.user.id, ctx.query.query);
	if (data === null) {
		ctx.status = 500;
		ctx.body = helper.apiError('Database error', ctx.status);
	} else {
		ctx.status = 200;
		ctx.body = helper.apiResponse(
			data,
			ctx.status
		);
	}
};
// get a single resume
export const getResume = async (ctx : IContext) => {
	// get a single resume by id
	const resume = await resumesService.getResumesByIdAndCandidateId(ctx.params.id, ctx.request.user.id);
	return await wrapResponse(resume ? resume.public() : null, ctx);
};

export const getDefaultResume = async (ctx : IContext) => {
	const resume = await resumesService.getDefaultResume(ctx.request.user.id);
	await wrapResponse(resume ? resume.public() : {}, ctx, 200);
};

// download a single resume
export const downloadResume = async (ctx : IContext) => {
	// get a single resume by id
	const resume = await resumesService.downloadResumeById(ctx.params.id);
	// if it doesn't exist, return a 404
	if (resume === null) {
		ctx.status = 404;
		ctx.body = helper.apiError('An error occurred', ctx.status);
		return;
	}
	// check that the resume does indeed belong to the user, and return it to them
	ctx.status = 200;
	ctx.body = resume.filestream;
	ctx.set('Content-disposition', `attachment; filename=${resume.filename}`);
	ctx.set('Content-type', resume.mimetype);
};
// download a single resume
export const previewResume = async (ctx : IContext) => {
	// get a single resume by id
	const resume = await resumesService.getResumePreviewById(ctx.request.user.RecruiterId, ctx.params.id);
	return await wrapResponse(resume, ctx);
};
export const makeResumeDefault = async (ctx : IContext) => {
	await resumesService.makeResumeDefault(ctx.request.user.id, ctx.params.id);
	ctx.status = 204;
};
// create a resume
export const createResume = async (ctx : IContext) => {
	// first validate the json
	const valErrors = await validate(ctx, 'createResumeSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		await resumesService.create(ctx.request.body, ctx.request.user.id);
		ctx.status = 201;
	}
};
// update resume
export const updateResume = async (ctx : IContext) => {
	// first validate the json matches the schema
	const valErrors = await validate(ctx, 'createResumeSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const result = await resumesService.updateCandidateResume(
			ctx.params.id,
			ctx.request.body,
			ctx.request.user.id
		);
		if (result) {
			ctx.status = 201;
		} else {
			ctx.status = 400;
			ctx.body = helper.apiError('An error occurred', ctx.status);
		}
	}
};
export const deleteResume = async (ctx : IContext) => {
	const result = await resumesService.deleteResumeById(ctx.params.id, ctx.request.user.id);
	if (result) {
		ctx.status = 204;
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError('An error occurred', ctx.status);
};
// RESUMES --------

// OPENINGS --------
// get my openings
export const getMyOpenings = async(ctx) => {

	let data = null;
	let promises = [];
	switch (ctx.request.user.type) {
		case 'Company':
		case 'Recruiter':
			promises.push(await openingService.getOpeningsByUserId(ctx.request.user.id, 'Active'));
			promises.push(await openingService.getOpeningsByUserId(ctx.request.user.id, 'Draft'));
			promises.push(await openingService.getOpeningsByUserId(ctx.request.user.id, 'Closed'));
			await Promise.all(promises).then(values => {
				data = {
					Active: values[0],
					Draft: values[1],
					Closed: values[2]
				}
			});
			break;
		default:
			break;
	}
	ctx.status = 200;
	ctx.body = helper.apiResponse(data, ctx.status);
};

// delete opening
export const deleteOpening = async (ctx : IContext) => {
	const result = await openingService.deleteOpeningById(ctx.params.id, ctx.request.user.id);
	if(result) {
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
		return;
	}
	ctx.status = 404;
	ctx.body = helper.apiError('You are not authorised to delete this.', ctx.status);
};

// get openings
export const getOpenings = async (ctx : IContext) => {
	let data;
	const resultLimit = ctx.query.limit ? ctx.query.limit : 10;
	const pageNumber = ctx.query.page ? ctx.query.page : 1;
	switch (ctx.request.user.type) {
		case 'Candidate':
			data = await openingService.getOpeningsByRecruiterId(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body, ctx.request.user.id, true);
			break;
		case 'Recruiter':
			data = await openingService.getOpeningsByRecruiterId(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body, null, true);
			break;
		case 'Company':
			data = await openingService.getOpeningsByCompanyId((ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	// get all the openings from the database, should always return an array
	if (data === null) {
		ctx.status = 500;
		ctx.body = helper.apiError('Database error', ctx.status);
	} else {
		ctx.status = 200;
		ctx.body = helper.apiResponse(
			data,
			ctx.status,
			null // paginator.paginateResponse(data, resultLimit, pageNumber)
		);
	}
};

export const advancedSearchOpenings = async (ctx : IContext) => {
	let data;
	const resultLimit = ctx.query.limit ? ctx.query.limit : 10;
	const pageNumber = ctx.query.page ? ctx.query.page : 1;
	switch (ctx.request.user.type) {
		case 'Candidate':
			data = await openingService.getAdvancedSearchOpenings(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body, ctx.request.user.id);
			break;
		case 'Recruiter':
			data = await openingService.getAdvancedSearchOpenings(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body);
			break;
		default:
			data = null;
			break;
	}
	if (data === null) {
		ctx.status = 500;
		ctx.body = helper.apiError('Database error', ctx.status);
	} else {
		ctx.status = 200;
		ctx.body = helper.apiResponse(
			data,
			ctx.status,
			{} // paginator.paginateResponse(data, resultLimit, pageNumber)
		)
	}
};

// get a single opening
export const getOpening = async (ctx : IContext) => {
	// get opening by id from database
	let data;
	switch (ctx.request.user.type) {
		case 'Candidate':
			data = await openingService.getOpeningByIdAndRecruiterId(ctx.params.id, ctx.request.user.RecruiterId, ctx.request.user.id);
			break;
		case 'Recruiter':
			data = await openingService.getOpeningByIdAndRecruiterId(ctx.params.id, ctx.request.user.RecruiterId);
			if(data) {
				data.RecommendedCandidates = await candidateService.getCandidatesByTags(data.Tags, ctx.request.user.RecruiterId);
			}
			break;
		case 'Company':
			data = await openingService.getOpeningByIdAndCompanyId(ctx.params.id, (ctx as ICompanyContext).request.user.CompanyId);
			if(data) {
				data.RecommendedCandidates = await candidateService.getCandidatesByTags(data.Tags, ctx.request.user.RecruiterId);
			}
			break;
		default:
			break;
	}
	return await wrapResponse(data, ctx);
};
// get a single opening - public version
export const getOpeningPublic = async (ctx : IContext) => {
	// get opening by id from database
	const data = await openingService.getOpeningById(`opening/${ctx.params.id}`);
	return await wrapResponse(data, ctx);
};
export const createOpening = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	// first validate the json
	const valErrors = await validate(ctx, 'createOpeningSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// create the pipeline in database and return 201
		let result;
		if (ctx.request.user.type === 'Company') {
			result = await openingService.create(ctx.request.body, `Company/${ctx.request.body.CompanyId}`, ctx.request.user.id);
		} else {
			result = await openingService.createOnBehalf(ctx.request.body, `Company/${ctx.request.body.CompanyId}`, ctx.request.user.id, ctx.request.user.RecruiterId);
		}
		if (result) {
			ctx.status = 201;
		}
	}
};

export const updateOpening = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	const valErrors = await validate(ctx, 'createOpeningSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// create the pipeline in database and return 201
		let result;
		if (ctx.request.user.type === 'Company') {
			result = await openingService.updateOpening(`Opening/${ctx.params.id}`, ctx.request.body, ctx.request.user.RecruiterId);
		} else {
			result = await openingService.updateOnBehalf(ctx.params.id, ctx.request.body, `Company/${ctx.request.body.CompanyId}`, ctx.request.user.RecruiterId);
		}
		if (result) {
			ctx.status = 201;
			return;
		}
	}

	ctx.status = 400;
	ctx.body = helper.apiError('Opening not found', ctx.status);
};
// OPENINGS --------

// PIPELINES --------
// get pipelines
export const getPipelines = async (ctx : IContext) => {
	let data = null;
	switch (ctx.request.user.type) {
		case 'Recruiter':
			data = await pipelinesService.getPipelinesByRecruiterId((ctx as IRecruiterContext).request.user.RecruiterId);
			break;
		case 'Company':
			data = await pipelinesService.getPipelinesByCompanyId((ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			return authError(ctx);
	}
	// get all the pipelines from the database, should always return an array
	return await wrapResponse(data ? data.public() : null, ctx);
};
// get a single pipeline
export const getPipeline = async (ctx : IContext) => {
	// get pipeline by id from database
	let data;
	switch (ctx.request.user.type) {
		case 'Recruiter':
			data = await pipelinesService.getPipelineByIdAndRecruiterId(ctx.params.id, (ctx as IRecruiterContext).request.user.RecruiterId);
			break;
		case 'Company':
			data = await pipelinesService.getPipelineByIdAndCompanyId(ctx.params.id, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			return authError(ctx);
	}
	return await wrapResponse(data, ctx);
};

export const getTasks = async (ctx : IContext) => {
	// get pipeline by id from database
	let data;
	switch (ctx.request.user.type) {
		case 'Company':
			data = await pipelinesService.getTasks((ctx as ICompanyContext).request.user.CompanyId);
			break;
		case 'Recruiter':
			data = await pipelinesService.getTasks((ctx as IRecruiterContext).request.user.RecruiterId);
			break;
		default:
			break;
	}

	return await wrapResponse(data, ctx);
};

export const getTask = async (ctx : IContext) => {
	// get pipeline by id from database
	let data;
	switch (ctx.request.user.type) {
		case 'Company':
			data = await pipelinesService.getTaskById(ctx.params.id, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		case 'Recruiter':
			data = await pipelinesService.getTaskById(ctx.params.id, (ctx as IRecruiterContext).request.user.RecruiterId);
			break;
		default:
			break;
	}
	return await wrapResponse(data, ctx);
};

export const deleteTask = async (ctx : IContext) => {
	// get pipeline by id from database
	let data;
	switch (ctx.request.user.type) {
		case 'Company':
			data = await pipelinesService.deleteTaskById(ctx.params.id, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		case 'Recruiter':
			data = await pipelinesService.deleteTaskById(ctx.params.id, (ctx as IRecruiterContext).request.user.RecruiterId);
			break;
		default:
			break;
	}
	return await wrapResponse(data, ctx);
};

export const createTask = async (ctx : IContext, type: string) => {
	// get pipeline by id from database
	let data, createFunction, schema;
	switch(type) {
		case 'todo':
			createFunction = pipelinesService.createTodoTask;
			schema = 'createTodoTask';
			break;
		case 'document':
			createFunction = pipelinesService.createDocumentTask;
			schema = 'createDocumentTask';
			break;
		case 'interview':
			createFunction = pipelinesService.createInterviewTask;
			schema = 'createInterviewTask';
			break;
		default:
			return;
	}
	let valErrors = await validate(ctx, schema);
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	switch (ctx.request.user.type) {
		case 'Recruiter':
			data = await createFunction(ctx.request.body, (ctx as IRecruiterContext).request.user.RecruiterId);
			break;
		case 'Company':
			data = await createFunction(ctx.request.body, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	if (data) {
		ctx.status = 201;
		return;
	}
	ctx.status = 404;
	ctx.body = helper.apiError('An error occurred', ctx.status);
};

export const updateTask = async (ctx : IContext) => {
	// get pipeline by id from database
	let data;
	switch (ctx.request.user.type) {
		case 'Recruiter':
			data = await pipelinesService.updateTask(ctx.params.id, ctx.request.body, ctx.request.user.RecruiterId);
			break;
		case 'Company':
			data = await pipelinesService.updateTask(ctx.params.id, ctx.request.body, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	return await wrapResponse(data, ctx);
};

export const getNotifications = async (ctx : IContext) => {
	if (ctx.query.read === 'true') {
		await notificationService.readNotifications(ctx.request.user.id);
	}
	const res = await notificationService.getNotifications(ctx.request.user);

	return await wrapResponse(res, ctx);
};
export const getChatRoom = async (ctx : IContext) => {
	const res = await messagesService.getChatRooms(ctx.request.user);
	return await wrapResponse(res, ctx);
};
export const latestMessages = async (ctx : IContext) => {
	const res = await messagesService.latestMessages(ctx.request.user);
	return await wrapResponse(res, ctx);
};

export const sentMessages = async (ctx : IContext) => {
	const res = await messagesService.sentMessages(ctx.request.user);
	return await wrapResponse(res, ctx);
};
export const receivedMessages = async (ctx : IContext) => {
	const res = await messagesService.receivedMessages(ctx.request.user);
	return await wrapResponse(res, ctx);
};

export const getTemplates = async (ctx : IContext) => {
	const res = await messagesService.getTemplatesByUserId(ctx.request.user.id);
	return await wrapResponse(res, ctx);
};

export const createChatRoom = async (ctx : IContext) => {
	const valErrors = await validate(ctx, 'createChatRoomSchema');
	if(valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	const res = await messagesService.startChatRoom(ctx.request.body, ctx.request.user.id);
	return await wrapResponse(res, ctx);
};
export const sendChatRoomMessage = async (ctx : IContext) => {
	const res = await messagesService.addMessage(ctx.params.id, ctx.request.user.id, ctx.request.body.Message, ctx.request.body.Attachment);
	return await wrapResponse(res, ctx);
};
export const searchMessages = async (ctx : IContext) => {
	if (ctx.request.user === null) {
		auth.authError(ctx);
		return;
	}
	const res = messagesService.searchMessages(ctx.request.user, ctx.query.query);
	return await wrapResponse(res, ctx);
};

export const deleteChatRoom = async (ctx : IContext) => await wrapResponse(messagesService.deleteChatRoom(ctx.params.id), ctx);
export const archiveChatRoom = async (ctx : IContext) => await wrapResponse(messagesService.archiveChatRoom(ctx.params.id), ctx);
export const getArchivedChatRoom = async (ctx : IContext) => await wrapResponse((await messagesService.getArchivedChatRoom(ctx.request.user)).public(), ctx);
export const getDeletedChatRooms = async (ctx : IContext) => await wrapResponse((await messagesService.getDeletedChatRooms(ctx.request.user)).public(), ctx);
export const printChatRoom = async (ctx : IContext) => {
	const pdf = await messagesService.printChatRoom(ctx.params.id, ctx.request.user);
	console.log(pdf);
	if (pdf === null) {
		ctx.status = 404;
		ctx.body = helper.apiError('An error occurred', ctx.status);
		return;
	}
	// check that the resume does indeed belong to the user, and return it to them
	ctx.status = 200;
	ctx.body = pdf.filestream;
	ctx.set('Content-disposition', `attachment; filename=${pdf.filename}`);
	ctx.set('Content-type', pdf.mimetype);
};

export const getChatRoomMessages = async (ctx : IContext) => {
	const resultLimit = ctx.query.limit ? ctx.query.limit : 2;
	const pageNumber = ctx.query.page ? ctx.query.page : 1;

	const res = await messagesService.getMessages(ctx.params.id, paginator.paginateInput(pageNumber, resultLimit), ctx.request.user);
	if (res) {
		ctx.status = 200;
		ctx.body = helper.apiResponse(res.data, ctx.status, null); // paginator.paginateResponse(res, resultLimit, pageNumber));
		return;
	}
	ctx.status = 404;
};
export const getContacts = async (ctx : IContext) => {
	const res = await messagesService.getContacts(ctx.request.user);
	return await wrapResponse(res, ctx);
};

export const createPipeline = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	// first validate the json
	let result = await validate(ctx, 'createPipelineSchema');
	if (!result) {
		// create the pipeline in database and return 201
		const json = ctx.request.body;
		json.UserId = ctx.request.user.id;
		const ownerId = ctx.request.user.type === 'Company' ? (ctx as ICompanyContext).request.user.CompanyId : ctx.request.user.RecruiterId;
		result = await pipelinesService.create(json, ownerId, ctx.request.user.id);
		return await wrapResponse(result, ctx, 201);
	}
	ctx.status = 404;
	ctx.body = result;
};

export const updatePipeline = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	const valErrors = await validate(ctx, 'createPipelineSchema');
	let result = null;
	if (!valErrors) {
		const id = ctx.request.user.type === 'Recruiter' ? ctx.request.user.RecruiterId : (ctx as ICompanyContext).request.user.CompanyId;
		result = await pipelinesService.updatePipeline(ctx.params.id, ctx.request.body, id);
		return await wrapResponse(result, ctx, 201);
	}
	ctx.status = 404;
	ctx.body = valErrors;
};
export const deletePipeline = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	const id = ctx.request.user.type === 'Recruiter' ? ctx.request.user.RecruiterId : (ctx as ICompanyContext).request.user.CompanyId;
	const result = await pipelinesService.deletePipeline(ctx.params.id, id);
	return await wrapResponse(result, ctx, 200);
};
// PIPELINES --------

// RECRUITERS --------
export const getRecruitersList = async (ctx : IContext) => {
	// get recruiters ids from relation objects
	let recruiters;
	switch(ctx.request.user.type) {
		case 'Candidate':
			recruiters = await candidateService.getAllAccounts((ctx as ICandidateContext).request.user.AccountEntityId);
			break;
		case 'Recruiter':
			recruiters = await recruiterService.getRecruiters(ctx.request.user.RecruiterId);
			break;
		default:
			break;
	}
	return await wrapResponse(recruiters, ctx);

};

export const getRecruiterProfile = async (ctx : IRecruiterContext) => {
	const res = await recruiterService.getRecruiterById(ctx.request.user.RecruiterId, true);
	ctx.status = 200;
	ctx.body = helper.apiResponse(res, ctx.status);
};

export const updateRecruiterProfile = async (ctx : IRecruiterContext) => {
	const valErrors = await validate(ctx, 'recruiterUpdateProfileSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	const res = await recruiterService.updateRecruiterById(ctx.request.user.RecruiterId, ctx.request.body);
	return await wrapResponse(res, ctx);
};
export const getCompanyProfile = async (ctx : ICompanyContext) => {
	const res = await companyService.getCompanyById(ctx.request.user.CompanyId);
	ctx.status = 200;
	ctx.body = helper.apiResponse(res ? res.public() : res, ctx.status);
};

export const updateCompanyProfile = async (ctx : ICompanyContext) => {
	const valErrors = await validate(ctx, 'companyUpdateProfileSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	const res = await companyService.updateCompanyById(ctx.request.user.CompanyId, ctx.request.body);
	return await wrapResponse(res, ctx);
};


export const updateUsersTeams = async (ctx) => {
	const valErrors = await validate(ctx, 'recruiterUserUpdateTeamSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	switch(ctx.request.user.type) {
		case 'Recruiter':
			await recruiterService.updateUsersTeams(ctx.request.body.Teams, `RecruiterUser/${ctx.params.id}`, ctx.request.user.RecruiterId);
			break;
		case 'Company':
			await companyService.updateUsersTeams(ctx.request.body.Teams, `CompanyUser/${ctx.params.id}`, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	ctx.status = 200;
	ctx.body = helper.apiResponse('success', ctx.status);
};

export const createTeam = async (ctx) => {
	const valErrors = await validate(ctx, 'recruiterCreateTeamSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	switch(ctx.request.user.type) {
		case 'Recruiter':
			await recruiterService.createTeam(ctx.request.body, ctx.request.user.RecruiterId);
			break;
		case 'Company':
			await companyService.createTeam(ctx.request.body, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	ctx.status = 200;
	ctx.body = helper.apiResponse('success', ctx.status);
};

export const getTeams = async (ctx) => {
	let result;
	switch(ctx.request.user.type) {
		case 'Recruiter':
			result = await recruiterService.getTeams(ctx.request.user.RecruiterId);
			break;
		case 'Company':
			result = await companyService.getTeams((ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	return await wrapResponse(result, ctx)
};

export const getUserList = async (ctx : IContext) => {
	// get recruiters ids from relation objects
	let users;
	switch(ctx.request.user.type) {
		case 'Recruiter':
			users = await recruiterService.getRecruiterUsersByRecruiter(ctx.request.user.RecruiterId);
			break;
		case 'Company':
			users = await companyService.getCompanyUsersByCompanyId((ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}

	return await wrapResponse(users, ctx);
};

export const updateRecruiterUserById = async (ctx : IContext) => {
	// get recruiters ids from relation objects
	const recruiterUsers = await recruiterService.updateRecruiterUserById(ctx.params.id, ctx.request.body);
	return await wrapResponse(recruiterUsers, ctx);
};

export const updateCompanyUserById = async (ctx : IContext) => {
	// get recruiters ids from relation objects
	const result = await companyService.updateCompanyUserById(ctx.params.id, ctx.request.body);
	return await wrapResponse(result, ctx);
};

// CANDIDATES --------
export const getCandidatesList = async (ctx : IRecruiterContext | ICompanyContext, bookmarked : boolean = false) => {
	let data;
	const resultLimit = ctx.query.limit ? ctx.query.limit : 10;
	const pageNumber = ctx.query.page ? ctx.query.page : 1;
	switch (ctx.request.user.type) {
		case 'Recruiter':
			data = await candidateService.searchCandidatesByRecruiterId(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body, true, null, ctx.request.user, bookmarked);
			break;
		case 'Company':
			data = await candidateService.searchCandidatesByRecruiterId(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body, true, null, ctx.request.user, bookmarked);
			break;
		default:
			break;
	}
	// get all the openings from the database, should always return an array
	if (data === null) {
		ctx.status = 500;
		ctx.body = helper.apiError('Database error', ctx.status);
	} else {
		ctx.status = 200;
		ctx.body = helper.apiResponse(
			data,
			ctx.status,
			null // paginator.paginateResponse(data, resultLimit, pageNumber)
		);
	}
};



export const advancedSearchCandidates = async (ctx : IContext) => {
	const resultLimit = ctx.query.limit ? ctx.query.limit : 10;
	const pageNumber = ctx.query.page ? ctx.query.page : 1;
	const data = await candidateService.advancedSearchCandidates(ctx.request.user.RecruiterId, paginator.paginateInput(pageNumber, resultLimit), ctx.request.body);
	return wrapResponse(data, ctx);
};

export const getCompaniesInfoList = async (ctx : IContext) => {
	let companies = await companyService.getCompaniesByRecruiterId(ctx.request.user.RecruiterId, ctx.query.query);
	companies = companies.map((x) => ({
		name: x.CompanyName,
		value: x.id
	}));
	return await wrapResponse(companies, ctx);
};
export const getCompaniesList = async (ctx : IContext) => {
	const companies = await companyService.getCompaniesByRecruiterId(ctx.request.user.RecruiterId, ctx.query.query);
	return await wrapResponse(companies, ctx);
};
export const getCompanyById = async (ctx : IContext) => {
	const companies = await companyService.getCompanyWithOpeningsById(ctx.params.id);
	return await wrapResponse(companies, ctx);
};

export const bookmarkCandidate = async (ctx: IContext) => {
	let res;
	switch(ctx.request.user.type) {
		case 'Recruiter':
			res = await recruiterService.bookmarkCandidate(ctx.request.user.id, ctx.params.id);
			break;
		case 'Company':
			res = await companyService.bookmarkCandidate(ctx.request.user.id, ctx.params.id);
			break;
		default:
			break;
	}
	return await wrapResponse(res, ctx);
};
export const getCandidate = async (ctx : IContext) => {
	const promises = [];
	promises.push(candidateService.getCandidateByAccountId(ctx.params.id));
	promises.push(resumesService.getDefaultResume(`Account/${ctx.params.id}`));
	await Promise.all(promises).then(async (values) => {
		if (values[0]) {
			ctx.status = 200;
			const profile = values[0].public();
			ctx.body = helper.apiResponse({ Profile: profile, Resume: values[1].public() }, ctx.status);
		} else {
			ctx.status = 404;
		}
	});
};

export const acceptInvite = async (ctx : IContext) => {
	const account = await candidateService.getAccountByInvitationKey(ctx.params.id);
	if(account) {
		account.DeletedAt = 0;
		await candidateService.saveAccount(account);
		ctx.redirect(`${config.candidateUrl}/dashboard`)
	}
};

const InvitiationResultCodes = {
	ALREADY_EXIST: 0,
	INVITE_SENT: 1,
	BAD_DATA: 2,
	EXIST_BUT_OTHER_RECRUITER: 3,
	FAILED: 4
};

const performInvite = async (User: RecruiterUser | CompanyUserWithRecruiterId, ToUserType: string, Body: IInvitationBody) : Promise<number> => {

	const ctx : IRequest = {
		request: {
			user: User,
			body: Body
		}
	};
	if(await validate(ctx, 'recruiterInviteSchema')) {
		return InvitiationResultCodes.BAD_DATA;
	}

	let data : Candidate | RecruiterUser | CompanyUser = null;
	switch (User.type) {
		case 'Candidate':
			return InvitiationResultCodes.FAILED;
		case 'Recruiter':
			switch (ToUserType) {
				case 'Candidate':
					data = await candidateService.getCandidateByEmailAddress(Body.EmailAddress);
					break;
				case 'Recruiter':
				case 'RecruiterUser':
					data = await recruiterService.getRecruiterUserByEmail(Body.EmailAddress);
					break;
				case 'Company':
				case 'CompanyUser':
					data = await companyService.getCompanyUserByEmailAddress(Body.EmailAddress);
					break;
				default:
					return InvitiationResultCodes.FAILED;
			}
			break;
		case 'Company':
			switch (ToUserType) {
				case 'Candidate':
					data = await candidateService.getCandidateByEmailAddress(Body.EmailAddress);
					break;
				case 'CompanyUser':
					data = await companyService.getCompanyUserByEmailAddress(Body.EmailAddress);
					break;
				default:
					return InvitiationResultCodes.FAILED;
			}
			break;
		default:
			return InvitiationResultCodes.FAILED;
	}


	const createRelation = async (userId : string = null, type) => {
		// create sha key
		const date = Date.now();
		const invitationKey = hash.createRegistrationKey(Body.FirstName, Body.EmailAddress, date);
		let url = null;
		// insert the relation model in the database
		switch(type) {
			case 'Candidate':
				await candidateService.createAccount(userId, User.RecruiterId, invitationKey, true);
				url = userId ? `${config.url}/api/invite/${invitationKey}` : `${config.candidateUrl}/register/signup?key=${invitationKey}&email=${(Body.EmailAddress)}`;
				break;
			case 'Recruiter':
			case 'RecruiterUser':
				if(userId) {
					return false;
				}
				await recruiterService.createMember(User.RecruiterId, { FirstName: ctx.request.body.FirstName, EmailAddress: `<${ctx.request.body.EmailAddress}>` }, invitationKey, type);
				url = `${config.recruiterUrl}/register/signup?key=${invitationKey}&email=${(Body.EmailAddress)}&type=${type}`;
				break;
			case 'Company':
				if(userId) {
					return false;
				}
				await companyService.createMember(User.RecruiterId, { FirstName: ctx.request.body.FirstName, EmailAddress: `<${ctx.request.body.EmailAddress}>` }, invitationKey, type);
				url = `${config.companyUrl}/register/signup?key=${invitationKey}&email=${(Body.EmailAddress)}&type=${type}`;
				break;
			case 'CompanyUser':
				if(userId) {
					return false;
				}
				await companyService.createMember((User as CompanyUserWithRecruiterId).CompanyId, { FirstName: ctx.request.body.FirstName, EmailAddress: `<${ctx.request.body.EmailAddress}>` }, invitationKey, type);
				url = `${config.companyUrl}/register/signup?key=${invitationKey}&email=${(Body.EmailAddress)}&type=${type}`;
				break;
			default:
				return false;
		}
		// then send the invitation mail
		mailer.sendInvitationMail(User.Locale, Body.EmailAddress, Body.FirstName, Body.Message, url);
		return true;
	};

	if (data) {
		// check if the relation already exists
		const relationExists = await recruiterService.getAccountByRecruiterAndCandidate(User.RecruiterId, data.getFullKey());
		if (relationExists) {
			return InvitiationResultCodes.ALREADY_EXIST;
		}
	}
	// if candidate does not exist yet, create new relation upon register
	const res = await createRelation(data ? data.getFullKey() : null, ToUserType);
	return res ? InvitiationResultCodes.INVITE_SENT : InvitiationResultCodes.FAILED;
};

const inviteResultCodeToOutput = (code: number) => {
	let message : string | object = '';
	let error: boolean = false;
	switch(code) {
		case InvitiationResultCodes.INVITE_SENT:
			error = false;
			message = 'Invite sent';
			break;
		case InvitiationResultCodes.BAD_DATA:
			error = true;
			message = 'Bad format';
			break;
		case InvitiationResultCodes.EXIST_BUT_OTHER_RECRUITER:
			error = false;
			message = 'Existed for other recruiter, but invited';
			break;
		case InvitiationResultCodes.ALREADY_EXIST:
			message = 'You already have this candidate';
			error = true;
			break;
		case InvitiationResultCodes.FAILED:
			message = 'You already have this candidate';
			error = true;
			break;
		default:
			error = true;
			message = 'Unexpected outcome';
			break;
	}
	return { error, message };
};

interface IInvitationBody {
	EmailAddress: string;
	FirstName: string;
	Message: string;
}


export const bulkInvite = async (ctx : IRecruiterContext) => {
	if(ctx.request.files) {
		const file = ctx.request.files.file;
		const reader = fs.createReadStream(file.path);
		await new Promise(resolve => {
			const res = [];
			csv.fromStream(reader).
			transform(async (data, next) => {
				const body : IInvitationBody = {
					EmailAddress: data[0], FirstName: data[1], Message: ''
				};
				const invitationResult = inviteResultCodeToOutput(await performInvite(ctx.request.user, 'Candidate', body));
				res.push({...body, Error: invitationResult.error, Result: invitationResult.message});
				return next(null, data);
			}).
			// eslint-disable-next-line no-empty-function
			on("data", () => {}).
			// eslint-disable-next-line no-empty-function
			on("data-invalid", () => {}).
			on('error', function() {
				ctx.status = 400;
				ctx.body = helper.apiError('Invalid CSV', ctx.status);
				return resolve();
			}).
			on("end", function() {
				ctx.status = 200;
				ctx.body = helper.apiResponse(res, ctx.status);
				return resolve();
			});
		});
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError('failed', ctx.status);
};

export const invite = async (ctx : IRecruiterContext) => {
	// if the error array from validator is empty
	const inviteResult = await performInvite(ctx.request.user, ctx.query.type, ctx.request.body);
	const res = inviteResultCodeToOutput(inviteResult);

	if(res.error) {
		ctx.status = 400;
		ctx.body = helper.apiError(res.message, ctx.status);
		return;
	}
	ctx.status = 200;
	ctx.body = helper.apiResponse(res.message, ctx.status);
};

export const createApplication = async (ctx : ICandidateContext) => {
	if (ctx.request.user.type !== 'Candidate') {
		auth.authError(ctx);
		return;
	}
	// first validate the json
	const valErrors = await validate(ctx, 'createApplicationSchema');
	let result = null;
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// create the application in the database and return 201
		const json = ctx.request.body;
		json.UserId = ctx.request.user.id;
		result = await applicationService.create(json, ctx.request.user, ctx.params.id);
		if (result) {
			await cache.remove(ctx.request.user.id, 'dashboard');
		}
	}
	return await wrapResponse(result, ctx);
};
export const getApplications = async (ctx : IContext) => {
	let data = null;
	switch (ctx.request.user.type) {
		case 'Candidate':
			data = await applicationService.getApplicationsByCandidateId(ctx.request.user.id);
			break;
		case 'Recruiter':
			data = await applicationService.getApplicationsByRecruiterId(ctx.request.user.RecruiterId, true, ctx.request.body.query);
			break;
		case 'Company':
			data = await applicationService.getApplicationsByCompanyId((ctx as ICompanyContext).request.user.CompanyId, true, ctx.request.body.query);
			break;
		default:
			return;
	}
	return await wrapResponse(data, ctx);
};


export const getApplicationsForOpening = async (ctx : IContext) => {
	let data = null;
	switch (ctx.request.user.type) {
		case 'Recruiter':
			data = await applicationService.getApplicationsByOpeningIdAndRecruiterId(ctx.params.id, ctx.request.user.RecruiterId);
			break;
		case 'Company':
			data = await applicationService.getApplicationsByOpeningIdAndCompanyId(ctx.params.id, ctx.request.user.RecruiterId);
			break;
		default:
			break;
	}
	return await wrapResponse(data, ctx);
};
export const getApplication = async (ctx : IContext, wrap : boolean = true) => {
	let data = null;
	switch (ctx.request.user.type) {
		case 'Candidate':
			data = await applicationService.getApplicationByIdAndCandidateId(ctx.params.id, ctx.request.user.id, true, true);
			break;
		case 'Recruiter':
			data = await applicationService.getApplicationByIdAndRecruiterId(ctx.params.id, ctx.request.user.RecruiterId);
			break;
		case 'Company':
			data = await applicationService.getApplicationByIdAndCompanyId(ctx.params.id, (ctx as ICompanyContext).request.user.CompanyId);
			break;
		default:
			break;
	}
	return wrap ? await wrapResponse(data, ctx) : data;
};

// export const createApplicationTask = async (ctx : IContext) => {
// 	let result : any = await validate(ctx, 'createApplicationTaskSchema');
// 	if (!result) {
// 		switch (ctx.request.user.type) {
// 			case 'Candidate':
// 				result = await applicationService.createTaskForApplication(ctx.params.id, ctx.request.user.id, ctx.request.body);
// 				break;
// 			default:
// 				break;
// 		}
// 	}
// 	return await wrapReponse(result, ctx, 204);
// };
export const cancelApplication = async (ctx : IContext) => {
	let result = null;
	switch (ctx.request.user.type) {
		case 'Candidate':
			result = await applicationService.cancelApplication(ctx.params.id, ctx.request.user.id);
			break;
		default:
			break;
	}
	return await wrapResponse(result, ctx, 204);
};

export const acceptApplication = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	const valErrors = await validate(ctx, 'acceptApplicationSchema');
	let result = valErrors;
	if (!valErrors) {
		// create the application in database and return 200
		result = await applicationService.acceptApplication(ctx.params.id, ctx.request.user.RecruiterId, ctx.request.user.id, ctx.request.body.PipelineId);
	}
	return await wrapResponse(result, ctx, 200);
};

export const makeOffer = async (ctx, update: boolean = false) => {
	const ownerId = ctx.request.user.type === 'Recruiter' ? ctx.request.user.RecruiterId : ctx.request.user.CompanyId;
	const result : boolean = await applicationService.giveOfferForApplication(ctx.params.id, ownerId, ctx.request.user.id, ctx.request.body, ctx.request.user.Locale, update);
	return wrapResponse(result, ctx);
};

export const acceptApplicationOffer = async (ctx) => {
	return await applicationService.acceptApplicationOffer(ctx.params.id, ctx.request.user.id,
		ctx.request.user.Locale);
};
export const declineApplicationOffer = async(ctx) => {
	return await applicationService.declineApplicationOffer(ctx.params.id, ctx.request.user.id,
		ctx.request.user.Locale);
};
export const negotiateApplicationOffer = async (ctx) => {
	const result = await applicationService.negotiateApplicationOffer(ctx.params.id, ctx.request.user);
	return wrapResponse(result, ctx);
};


export const rejectApplication = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		auth.authError(ctx);
		return;
	}
	const valErrors = await validate(ctx, 'rejectApplicationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	// create the application in database and return 200
	const result = await applicationService.rejectApplication(ctx.params.id, ctx.request.user.RecruiterId, ctx.request.user.id, ctx.request.body.RejectionReason,
		ctx.request.user.Locale);
	return wrapResponse(result, ctx);
};
export const updateTodoTask = async (ctx : IContext) => {
	const valErrors = await validate(ctx, 'updateTaskSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	const result = await applicationService.updateTodoTasks(`Application/${ctx.params.applicationId}`, ctx.params.taskId, ctx.request.user.id, ctx.request.body);
	return wrapResponse(result, ctx);
};

export const getApplicationTask = async (ctx : IContext) => {
	const task = await applicationService.getApplicationTask(ctx.params.applicationId, ctx.params.taskId, ctx.request.user.id);
	return wrapResponse(task, ctx);
};

export const completeApplicationTask = async (ctx: IContext) => {
	const result = await applicationService.completeTask(`Application/${ctx.params.applicationId}`, ctx.params.taskId, ctx.request.user.id);
	return wrapResponse(result, ctx);
};

export const checkApplicationComplete = async (ctx: IContext) => {
	const application: any = await getApplication(ctx, false);
	const completed = !application.CandidatePipeline.map(item => item.Status).some(status => status !== 'Completed');
	const result = { completed };
	return wrapResponse(result, ctx);
};

export const addTaskComment = async (ctx : IContext) => {
	const valErrors = await validate(ctx, 'addTaskCommentSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	}
	const task = await applicationService.addTaskComment(ctx.params.applicationId, ctx.params.taskId, ctx.request.user.id, ctx.request.body.Message);
	return wrapResponse(task, ctx);
};

export const downloadDocumentTask = async (ctx : IContext) => {
	// get a single resume by id
	const resume = await applicationService.downloadDocumentTask(ctx.params.applicationId, ctx.params.taskId, ctx.request.user.id);
	// if it doesn't exist, return a 404
	if (resume === null) {
		ctx.status = 404;
		ctx.body = helper.apiError('An error occurred', ctx.status);
		return;
	}
	// check that the resume does indeed belong to the user, and return it to them
	ctx.status = 200;
	ctx.body = resume.filestream;
	ctx.set('Content-disposition', `attachment; filename=${resume.filename}`);
	ctx.set('Content-type', resume.mimetype);
};

export const updateDocumentTask = async (ctx : IContext) => {
	const valErrors = await validate(ctx, 'updateDocumentSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	const result = await applicationService.updateDocumentTasks(ctx.params.applicationId, ctx.params.taskId, ctx.request.user.id, ctx.request.body, ctx.request.user.type === 'Candidate');
	if (result) {
		ctx.status = 204;
		return;
	}

	ctx.status = 400;
	ctx.body = helper.apiError('An unexpected error occured', ctx.status);
};

export const reorderTasks = async (ctx : IContext) => {
	const valErrors = await validate(ctx, 'reorderTasksSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	const result = await applicationService.updateTaskOrderAndStatus(ctx.params.id, ctx.request.user.id, ctx.request.body.CandidatePipeline);
	if (result) {
		ctx.status = 204;
		return;
	}

	ctx.status = 400;
	ctx.body = helper.apiError('An unexpected error occured', ctx.status);
};

export const getTags = async (ctx : IContext) => {
	ctx.status = 200;
	if (ctx.query.query) {
		ctx.body = helper.apiResponse(await openingService.getOpeningTags(ctx.query.query), ctx.status);
	}
};

interface Dashboard {
	applications: Application[],
	profile: Candidate,
	droppedApplications: Application[],
	upcomingEvents: Event[],
	recommendedOpenings: Opening[],
	offers: {}
}

export const dashboard = async (ctx : IContext) => {
	let data: Dashboard | any;
	const cachedBody = await cache.get(ctx.request.user.id, 'dashboard');
	const promises = [];

	if (cachedBody) {
		data = cachedBody;
	} else {
		switch (ctx.request.user.type) {
			case 'Candidate':

				promises.push(applicationService.getApplicationsByCandidateIdAndStatusId(ctx.request.user.id, 2, '<=', ctx.request.user.RecruiterId, 1));
				promises.push(candidateService.getCandidateById((ctx as ICandidateContext).request.user.AccountEntityId, true));
				promises.push(applicationService.getApplicationsByCandidateIdAndStatusId(ctx.request.user.id, 3, '=', ctx.request.user.RecruiterId));
				promises.push(eventsService.getEventsByUser(ctx.request.user));
				promises.push(openingService.getRecommendationsByCandidateId(ctx.request.user.id));
				promises.push(applicationService.getApplicationsByCandidateIdAndStatusId(ctx.request.user.id, 5, '=', ctx.request.user.RecruiterId));
				await Promise.all(promises).then((values) => {
					data = {
						applications: values[0],
						profile: values[1],
						droppedApplications: values[2],
						upcomingEvents: values[3],
						recommendedOpenings: values[4],
						offers: values[5]
					};
					cache.put(ctx.request.user.id, 'dashboard', data);
				});
				break;
			case 'Recruiter':
				promises.push(applicationService.getApplicationsByRecruiterIdAndStatusId(2, '<=', ctx.request.user.RecruiterId));
				promises.push(eventsService.getEventsByUser(ctx.request.user));
				promises.push(openingService.getRecentOpeningsByRecruiter(ctx.request.user.RecruiterId));
				promises.push(candidateService.getRecentCandidatesByRecruiter(ctx.request.user.RecruiterId));
				promises.push(applicationService.getApplicationsByRecruiterIdAndStatusId(3, '=', ctx.request.user.RecruiterId));
				const date = new Date(), y = date.getFullYear(), m = date.getMonth();
				const startDate = new Date(y, m-3, 1);
				const endDate = new Date(y, m + 2, 0);
				promises.push(applicationService.getApplicationReport(startDate, endDate, ctx.request.user.RecruiterId));
				await Promise.all(promises).then((values) => {
					data = {
						applications: values[0],
						upcomingEvents: values[1],
						recentOpenings: values[2],
						recentCandidates: values[3],
						droppedApplications: values[4],
						report: values[5],
					};
				});
				break;
			case 'Company':
				promises.push(applicationService.getApplicationsByCompanyIdAndStatusId(2, '<=', (ctx as ICompanyContext).request.user.CompanyId));
				promises.push(eventsService.getEventsByUser(ctx.request.user));
				promises.push(openingService.getRecentOpeningsByCompany((ctx as ICompanyContext).request.user.CompanyId));
				promises.push(candidateService.getRecentCandidatesByRecruiter(ctx.request.user.RecruiterId));
				promises.push(applicationService.getApplicationsByCompanyIdAndStatusId(3, '=', (ctx as ICompanyContext).request.user.CompanyId));
				await Promise.all(promises).then((values) => {
					data = {
						applications: values[0],
						upcomingEvents: values[1],
						recentOpenings: values[2],
						recentCandidates: values[3],
						droppedApplications: values[4],
					};
				});
				break;
			default:
				ctx.status = 404;
				return;
		}
	}
	if (data) {
		ctx.status = 200;
		ctx.body = helper.apiResponse(data, ctx.status);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError('An unexpected error occured', ctx.status);
};

export const makeRecommendation = async (ctx : IContext) => {
	if (ctx.request.user.type === 'Candidate') {
		return auth.authError(ctx);
	}

	const valErrors = await validate(ctx, 'recommendToCandidateSchema');

	if(valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}

	const res = await recruiterService.addRecommendationByCandidateId(`Candidate/${ctx.request.body.CandidateId}`, ctx.request.user.RecruiterId, ctx.params.id);
	if (res) {
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
		return;
	}
	ctx.status = 400;
	ctx.body = helper.apiError({OpeningId: 'Please select a valid opening'}, ctx.status);
};
