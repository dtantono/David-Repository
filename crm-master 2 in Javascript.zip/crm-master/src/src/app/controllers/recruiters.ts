import * as db from '../db/database';
import { validate } from '../helpers/validation/Validation';
import {IRecruiterRegister} from "../services/recruiters";

const bcrypt = require('bcrypt');

const auth = require('./auth');
const helper = require('../helpers/apiResponseHelper');
const recruiterService = require('../services/recruiters'););
const type = 'Recruiter';

import * as cache from '../helpers/cache';

// AUTHENTICATION
export const validateSignup = async (ctx) => {
	const valErrors = await validate(ctx, 'recruiterRegisterSignupSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const data = await recruiterService.getRecruiterUserByEmail(ctx.request.body.EmailAddress);
		if (data && data.length !== 0) {
			ctx.status = 400;
			ctx.body = helper.apiError({ EmailAddress: 'This user already exists within the system' }, ctx.status);
			return;
		}
		ctx.status = 200;
		ctx.body = helper.apiResponse('success', ctx.status);
	}
};

export const register = async (ctx) => {
	// first validate the json
	const valErrors = await validate(ctx, 'recruiterRegistrationSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		const details : IRecruiterRegister = ctx.request.body;
		// check if the user exists in the database already
		const member = await recruiterService.getRecruiterUserByEmail(details.Signup.EmailAddress);
		// If the user doesn't exist, then proceed, otherwise reject the registration
		if (member) {
			ctx.status = 400;
			ctx.body = helper.apiError('This recruiter already exists', ctx.status);
		} else {
			const recruiterUser = await recruiterService.registerRecruiter(details, ctx.params.key);
			// enter into the database
			const token = auth.sign(recruiterUser.getFullKey(), type);
			const payload = { token: token };
			ctx.status = 200;
			ctx.body = helper.apiResponse(payload, ctx.status);
		}
	}
};

export const registerCompleteInvitation = async (ctx) => {
	if(!('key' in ctx.query)) {
		ctx.status = 400;
		ctx.body = helper.apiError('You have not been invited', ctx.status);
		return;
	}
	const valErrors = await validate(ctx, 'recruiterUserRegistrationSchema');
	if(valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
		return;
	}
	// when member click link in email (from registerInvitation) he has to register missing details
	const member = await db.recruiterUsers.newQuery().where('InvitationKey', ctx.query.key).first();
	if(!member) {
		ctx.status = 400;
		ctx.body = helper.apiError('No invitation exists', ctx.status);
		return
	}
	await recruiterService.updateRecruiterUserById(member.getFullKey(), {...ctx.request.body.Personal, ...ctx.request.body.Signup, Active: true});
	const token = auth.sign(member.getFullKey(), type);
	ctx.status = 200;
	ctx.body = helper.apiResponse({token: token}, ctx.status);
	return
};

export const login = async (ctx) => {
	// first validate the json
	const valErrors = await validate(ctx, 'loginSchema');
	if (valErrors) {
		ctx.status = 400;
		ctx.body = helper.apiError(valErrors, ctx.status);
	} else {
		// check that the user exists in the database
		const user = await recruiterService.getRecruiterUserByEmail(ctx.request.body.EmailAddress);
		// if not, supplied an authentication problem response
		if (user && user.Active) {
			// If the user exists in the DB, check the password matches
			const password = ctx.request.body.Password;
			if (bcrypt.compareSync(password, user.HashPassword)) {
				// if it matches, supply a JWT and return it to the user
				const token = auth.sign(user.id, type);
				ctx.status = 200;
				const payload = { token: token };
				ctx.body = helper.apiResponse(payload, ctx.status);
			} else {
				// if the password doesn't match, supply an authentication problem error
				ctx.status = 401;
				ctx.body = helper.apiError({EmailAddress: 'Invalid credentials'}, ctx.status);
			}
		} else {
			ctx.status = 401;
			ctx.body = helper.apiError({EmailAddress: 'Invalid credentials'}, ctx.status);
		}
	}
};

export const switchAccount = async (ctx) => {
	if (ctx.request.user) {
		if (ctx.request.user.RecruiterId === `${type}/${ctx.params.id}`) {
			ctx.status = 200;
			ctx.body = helper.apiResponse(
				'You are already logged in to this account',
				ctx.status
			);
			return;
		}
		const res = await recruiterService.loginAccount(`${type}/${ctx.params.id}`, ctx.request.user.AccountEntityId);
		if(res) {
			await auth.expire(ctx);
			await cache.remove(ctx.request.user.id, 'dashboard');
			await cache.remove(ctx.request.user.id, 'profile');
			ctx.status = 200;
			ctx.body = helper.apiResponse(
				{
					token: auth.sign(res, ctx.request.user.type)
				},
				ctx.status
			);
			return;
		}
	}
	ctx.status = 401;
};

