import { Config } from './DatabaseModule/DatabaseBuilder';

const couchbase = require('couchbase');
const N1qlQuery = couchbase.N1qlQuery;

import configFile from '../../../config';
const config = new Config(configFile);

// initiate the couchbase cluster
const cluster = new couchbase.Cluster(`${config.HOST_NAME}:${config.PORT}`);
cluster.authenticate(config.USERNAME, config.PASSWORD);
// console.log(config.database);
const bucket = cluster.openBucket(`${config.DATABASE}`, (error) => {
	if (error) {
		throw error;
	}
});

async function asyncForEach(array, callback) {
	for (let index = 0; index < array.length; index++) {
		// eslint-disable-next-line callback-return
		await callback(array[index], index, array);
	}
}

async function createIndexes() {
	const indexes = [
		`CREATE PRIMARY INDEX ON ${config.DATABASE} USING GSI;`,
		`CREATE INDEX index_type ON ${config.DATABASE}(type) USING GSI WITH {"defer_build":true};`,
		`CREATE INDEX company_index_recruiterid ON ${
			config.DATABASE
		}(RecruiterId,type) WHERE (type = "company") USING GSI WITH {"defer_build":true};`,
		`CREATE INDEX index_RecruiterId ON ${
			config.DATABASE
		}(RecruiterId) USING GSI WITH {"defer_build":true};`,
		`CREATE INDEX index_applications ON ${
			config.DATABASE
		}(CandidateId,Status,type) WHERE (type = "application") USING GSI WITH {"defer_build":true};`,
		`CREATE INDEX index_openings ON ${
			config.DATABASE
		}((distinct (array array_element for array_element in Tags end)),type, Active) WHERE (type = "opening") USING GSI WITH {"defer_build":true};`,
		`CREATE INDEX idx_opening ON ${config.DATABASE}(OpeningId) USING GSI WITH {"defer_build":true};`
	];
	await asyncForEach(indexes, async (index) => new Promise((resolve) => {
		const query = N1qlQuery.fromString(index);
		bucket.query(query, (err) => {
			if (err) {
				console.log(err);
				resolve(null);
			}
			resolve(true);
		});
	}));
	await new Promise((resolve) => bucket.query(N1qlQuery.fromString(`BUILD INDEX ON ${config.DATABASE} (index_type, company_index_recruiterid, index_RecruiterId, index_applications, index_openings, idx_opening)`), () => resolve(true)));
}

createIndexes().then(() => console.log('Completed'));
