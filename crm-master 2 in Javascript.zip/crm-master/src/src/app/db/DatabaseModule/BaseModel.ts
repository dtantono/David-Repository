import {unCache} from "../../helpers/cache";

const uuid = require('uuid');
const _ = require('lodash');

export interface IModel {
	getKey(): string;

	getType(): string;

	validate(): boolean;

	fill(data: object, backup: boolean);

	all(): object;

	public(...excludeProperties: string[]): object;

	update(): void;
}

export interface BaseModelRegister {

}

export class Model<T extends BaseModelRegister> implements IModel {
	public id: string;
	public type: string;
	protected schema: object;
	protected Previous: any = null;
	public DeletedAt: number | null = 0;
	public UpdatedAt: number | null;
	public CreatedAt: number | null;
	public Relations: T;

	constructor() {
		this.id = uuid();
	}

	delete() {
		this.DeletedAt = Date.now();
	}

	update() {
		const updateDate = Date.now();
		this.CreatedAt = this.CreatedAt === null || this.CreatedAt === undefined ? updateDate : this.CreatedAt;
		this.UpdatedAt = updateDate;
	}

	getFullKey() {
		return `${this.type}/${this.id}`;
	}

	getKey() {
		return this.id;
	}

	getType() {
		return this.type;
	}

	validate() {
		return true;
	}

	isDeleted() {
		return this.DeletedAt !== null && this.DeletedAt !== undefined && this.DeletedAt !== 0;
	}

	fill(data: object, backup: boolean = false) {
		data = data || {};
		const defaults = Object.keys(this.schema).reduce((all, key) => ({
			...all,
			[key]: this.schema[key].defaultValue
		}), {});
		const newData = _.pick(_.defaults(data, this, defaults), [..._.keys(this.schema), 'id', 'Relations', 'UpdatedAt', 'CreatedAt', 'DeletedAt']);
		Object.keys(newData).forEach((x) => this[x] = newData[x]);
		if(backup) {
			this.Previous = {...this};
		}
	}

	all() {
		const schema = _.pick(this, _.keys(this.schema));
		schema.id = this.id === '' ? uuid() : this.id;
		schema.type = this.type;
		schema.UpdatedAt = this.UpdatedAt;
		schema.CreatedAt = this.CreatedAt;
		schema.DeletedAt = this.DeletedAt;
		return schema;
	}

	public(...excludeProperties: string[]) {
		let response = Object.assign({}, this);
		delete response.schema;
		response = { ...response, ...this.Relations };
		delete response.Relations;
		excludeProperties.forEach((prop) => {
			if (prop) {
				const propLevels = prop.split('.');
				const lastProp = propLevels.pop();
				const parent = propLevels.reduce((obj, key) => obj[key], response);
				if(lastProp in parent) {
					delete parent[lastProp];
				}
			}
		});
		return response;
	}
}
