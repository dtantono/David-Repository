import { IDatabaseBuilder } from './Interfaces/IDatabaseBuilder';
import { IAggregration } from './Interfaces/IAggregration';
import { IWhere } from './Interfaces/IWhere';
import { INest } from './Interfaces/INest';
import { IJoin } from './Interfaces/IJoin';
import { IBuilder } from './Interfaces/IBuilder';
import { IModel } from './BaseModel';
import {arrayToCouchbaseArray} from "./Helper";

const couchbase = require('couchbase');
const N1qlQuery = couchbase.N1qlQuery;

interface UPDATE {
	value: any,
	field: string
}

export const whereLogic = (field, value) => {
	if (field === 'id' && value.includes('/')) {
		value = value.split('/')[1];
	}
	return value;
};
interface OrderBy {
	field: string,
	asc: boolean,
	raw: boolean
}

export class Builder implements IBuilder {
	SELECT: string;
	JOINS: (Join | Nest)[];
	COUNT: boolean;
	GROUP_BY: string;
	DELETE: boolean;
	WHERE: Where;
	FROM: string;
	AGGREGATIONS: Aggregration[];
	LIMIT: number;
	OFFSET: number;
	UPDATE: UPDATE;
	ORDER_BY: OrderBy;
	ACTIVE_ONLY: boolean;
	DELETED_ONLY: boolean;
}

export class Config {
	HOST_NAME: string;
	PORT: number;
	DATABASE: string;
	USERNAME: string;
	PASSWORD: string;

	constructor(file: any) {
		this.DATABASE = file.DATABASE.NAME;
		this.HOST_NAME = file.DATABASE.HOST_NAME;
		this.PORT = file.DATABASE.PORT;
		this.USERNAME = file.DATABASE.USERNAME;
		this.PASSWORD = file.DATABASE.PASSWORD;
	}
}

class Join implements IJoin {
	fromTable: string;
	toTable: string;
	foreignKey: string;
	type: string = 'join';

	constructor(fromTable, toTable, foreignKey) {
		this.fromTable = fromTable;
		this.toTable = toTable;
		this.foreignKey = foreignKey;
	}

	getQuery(database: string) {
		return `LEFT JOIN ${database} ${this.toTable} ON KEYS ${this.fromTable}.${this.foreignKey} `;
	}
}

class Nest implements INest {
	field: string;
	type: string = 'nest';

	constructor(field) {
		this.field = field;
	}

	getQuery(database: string) {
		return `UNNEST ${this.field}`;
	}
}

class Aggregration implements IAggregration {

}

class Where implements IWhere {
	field: string;
	and: boolean;
	value: any;
	comparison: string;
	embedded: Where[];
	table: string;
	any: boolean;
	nestedProperty: string;

	addToIndex(index: number[], where: Where) {
		const i = Object.assign([], index);
		if (i.length) {
			this.embedded[i[0]].addToIndex(i.splice(1), where);
		} else {
			this.embedded.push(where);
		}
	}

	highestIndex() {
		return this.embedded.length ? [this.embedded.length - 1, ...this.embedded[this.embedded.length - 1].highestIndex()] : [];
	}

	setIndex(index: number[], where: Where) {
		if (index.length) {
			this.embedded[index[0]].setIndex(index.splice(1), where);
		} else {
			this.field = where.field;
			this.and = where.and;
			this.value = where.value;
			this.comparison = where.comparison;
			this.embedded = where.embedded;
		}
	}

	getQuery(first: boolean): string {
		if (this.value !== undefined) {
			let query = '';
			if (!first) {
				query += this.and ? ' AND ' : ' OR ';
			}
			query += '(';
			this.comparison = this.comparison.toUpperCase();
			if (this.embedded.length > 0) {
				query += this.embedded.map((w, i) => w.getQuery(i === 0)).join(' ');
			} else {
				let value = this.value;
				// TODO other value types
				if (value.constructor === String) {
					value = this.comparison === 'LIKE' ? `"%${this.value.toString().toLowerCase()}%"` : `"${this.value}"`;
				} else if(value.constructor === Array) {
					value = arrayToCouchbaseArray(value, this.field.substr(-2).toLowerCase() !== 'id');
				}
				if (this.any) {
					query += `ANY x in ${this.table}.${this.field} satisfies LOWER(x${this.nestedProperty ? `.${this.nestedProperty}` : ''}) ${this.comparison} ${value.toLowerCase()} END`;
				} else if (this.comparison === 'LIKE' || this.comparison === 'IN') {
					query += `LOWER(${this.table}.${this.field}) ${this.comparison} ${value}`;
				} else {
					query += `${this.table}.\`${this.field}\` ${this.comparison} ${value}`;
				}
			}
			query += ')';
			return query;
		}
		return '';
	}

	constructor(value: any, comparison: string, field: string, and: boolean, table: string, any: boolean = false, nestedProperty = null) {
		this.value = value;
		this.comparison = comparison;
		this.field = field;
		this.and = and;
		this.embedded = [];
		this.table = table;
		this.any = any;
		this.nestedProperty = nestedProperty;
	}
}

function initiateConnection(config: Config) {
	// initiate the couchbase cluster
	const cluster = new couchbase.Cluster(`${config.HOST_NAME}:${config.PORT}`);
	cluster.authenticate(config.USERNAME, config.PASSWORD);
	return cluster.openBucket(config.DATABASE, (error) => {
		if (error) {
			throw error;
		}
	});
}

import configFile from '../../../../config';
import { PaginatedList, ResultSet } from './ListTypes';
const config = new Config(configFile);
const connection = initiateConnection(config);

// TODO where not missing / where has relation
// TODO nest / unnest
// TODO where array satisfies
export class DatabaseBuilder<T extends IModel> implements IDatabaseBuilder<T> {
	private readonly table: string;
	private debugMode: boolean;
	private currentBuilder: Builder;
	private currentWhere: number[];
	private deconstructor: (item: DatabaseBuilder<T>) => void;

	constructor(private Type: new() => T, deconstructor: (item: DatabaseBuilder<T>) => void, debugMode: boolean = true) {
		this.table = (new Type()).getType();
		this.debugMode = debugMode;
		this.deconstructor = deconstructor;
		this.refreshBuilder();
	}

	getQuery(): string {
		let query;
		if (this.currentBuilder.UPDATE) {
			query = `UPDATE ${config.DATABASE} ${this.currentBuilder.FROM} SET ${this.currentBuilder.UPDATE.field} = ${this.currentBuilder.UPDATE.value} `;
		} else {
			if (this.currentBuilder.DELETE === true) {
				query = 'DELETE ';
			} else if (this.currentBuilder.COUNT === true) {
				query = `SELECT ${this.currentBuilder.GROUP_BY === '' ? '' : this.currentBuilder.GROUP_BY + ','} count(${this.currentBuilder.FROM}) as count `;
			} else {
				query = `SELECT ${this.currentBuilder.SELECT === '' ? '*' : this.currentBuilder.SELECT} `;
			}
			query += `FROM \`${config.DATABASE}\` ${this.currentBuilder.FROM} `;
		}

		query += this.currentBuilder.JOINS.map((join) => join.getQuery(config.DATABASE)).join(' ') + ' ';
		const where = this.currentBuilder.WHERE.getQuery(true);
		query += where === '' ? '' : `WHERE ${where} `;
		if (this.currentBuilder.ACTIVE_ONLY) {
			const deletedQuery = `${this.currentBuilder.FROM}.DeletedAt is missing or ${this.currentBuilder.FROM}.DeletedAt = 0`;
			query += where === '' ? `WHERE ${deletedQuery}` : ` AND (${deletedQuery})`;
		} else if(this.currentBuilder.DELETED_ONLY) {
			const deletedQuery = `${this.currentBuilder.FROM}.DeletedAt != 0`;
			query += where === '' ? `WHERE ${deletedQuery}` : ` AND (${deletedQuery})`;
		}
		if(this.currentBuilder.JOINS.length > 0) {
			const whereNotMissing = this.currentBuilder.JOINS.map(x => `${x.type === 'join' ? (x as Join).toTable : (x as Nest).field} is not missing `).join(' and ');
			query += where === '' ? `WHERE ${whereNotMissing}` : ` AND (${whereNotMissing})`;
		}
		query += this.currentBuilder.GROUP_BY === '' ? '' : ' GROUP BY ' + this.currentBuilder.GROUP_BY;
		query += this.currentBuilder.ORDER_BY ? ' ORDER BY ' + (this.currentBuilder.ORDER_BY.raw ? this.currentBuilder.ORDER_BY.field : `LOWER(${this.currentBuilder.ORDER_BY.field})`) + ` ${this.currentBuilder.ORDER_BY.asc ? 'ASC' : 'DESC'} ` : '';
		query += this.currentBuilder.LIMIT === 0 ? '' : ` LIMIT ${this.currentBuilder.LIMIT} `;
		query += this.currentBuilder.OFFSET === 0 ? '' : ` OFFSET ${this.currentBuilder.OFFSET} `;

		return query;
	}

	deleted() {
		this.currentBuilder.DELETED_ONLY = true;
		return this;
	}

	active() {
		this.currentBuilder.ACTIVE_ONLY = true;
		return this;
	}

	upsert(key: string, data: object): Promise<string> {
		const self = this;
		return new Promise((resolve) => {
			connection.upsert(key, data, (err) => {
				if (err) {
					console.log('UPSERT', err);
					resolve(null);
				}
				resolve(key);
				self.deconstructor(self);
			});
		});
	}

	delete() {
		this.currentBuilder.DELETE = true;
		return this.execute();
	}

	find(key: string): Promise<T | null> {
		const self = this;
		return new Promise((resolve) => {
			connection.get(key, (err, data: any) => {
				if (err) {
					console.log('FIND', err);
					resolve(null);
				} else if (data) {
					const res = new this.Type();
					res.fill(data.value);
					resolve(res);
				} else {
					resolve(null);
				}
				self.deconstructor(self);
			});
		});
	}

	async paginate(offset: number, limit: number) {
		if (limit !== 0) {
			this.currentBuilder.LIMIT = limit;
			this.currentBuilder.OFFSET = offset;
			const result = new ResultSet<T>(await this.execute());
			this.currentBuilder.LIMIT = 0;
			this.currentBuilder.OFFSET = 0;
			const count = await this.count();
			return new PaginatedList<T>(result, Math.floor(offset / limit), limit, count, count > offset + result.length);
		}
		return new PaginatedList<T>(new ResultSet<T>(), 0, 0, 0, false);
	}

	limit(limit: number) {
		if(limit !== 0) {
			this.currentBuilder.LIMIT = limit;
		}
		return this;
	}

	refreshBuilder() {
		this.currentBuilder = {
			AGGREGATIONS: [],
			FROM: this.table,
			COUNT: false,
			JOINS: [],
			DELETE: false,
			GROUP_BY: '',
			SELECT: '',
			WHERE: new Where('', '=', '', true, this.table),
			LIMIT: 0,
			OFFSET: 0,
			UPDATE: null,
			ACTIVE_ONLY: false,
			DELETED_ONLY: false,
			ORDER_BY: null
		};
		this.currentWhere = [];
	}

	checkBuilder() {
		if (!this.currentBuilder) {
			throw new Error('Please instantiate the builder with refreshBuilder()');
		}
	}

	// Select fields from the table. Defaults to * if no fields specified.
	select(...fields: string[]): this {
		this.checkBuilder();
		this.currentBuilder.SELECT = fields.join(',');
		return this;
	}

	update(field: string, value: any): this {
		this.checkBuilder();
		this.currentBuilder.UPDATE = { value, field };
		return this;
	}

	// returns the count of rows selected
	async count(groupBy: string = ''): Promise<number> {
		this.checkBuilder();
		this.currentBuilder.COUNT = true;
		this.currentBuilder.GROUP_BY = groupBy;
		const result = (await this.execute(false));
		return groupBy === '' ? result[0].count : result;
	}

	// executes the current command and returns a result set
	async get(map: boolean = true) : Promise<ResultSet<T> | any> {
		this.checkBuilder();
		const data = await this.execute(map);
		return map ? new ResultSet<T>(data) : data;
	}

	// executes the current command and returns the first item or null
	async first() : Promise<T | null> {
		this.checkBuilder();
		this.currentBuilder.LIMIT = 1;
		const result = await this.execute();
		return result.length ? result[0] : null;
	}

	unnest(field: string): this {
		this.checkBuilder();
		this.currentBuilder.JOINS.push(new Nest(field));
		return this;
	}

	whereAny(field: string, value: any, comparison: string = '=', nestedProperty: string = null, table: string = null): this {
		this.checkBuilder();
		value = whereLogic(field, value);
		this.currentBuilder.WHERE.addToIndex(this.currentWhere, new Where(value, comparison, field, true, table || this.table, true, nestedProperty));
		return this;
	}

	orWhereAny(field: string, value: any, comparison: string = '=', nestedProperty: string = null, table: string = null): this {
		this.checkBuilder();
		value = whereLogic(field, value);
		this.currentBuilder.WHERE.addToIndex(this.currentWhere, new Where(value, comparison, field, false, table || this.table, true, nestedProperty));
		return this;
	}

	// Adds an "AND" where statement to the query, defaults to the current table
	where(field: string, value: any, comparison: string = '=', table: string = null): this {
		this.checkBuilder();
		value = whereLogic(field, value);
		this.currentBuilder.WHERE.addToIndex(this.currentWhere, new Where(value, comparison, field, true, table || this.table));
		return this;
	}

	// Adds an "OR" where statement to the query, defaults to the current table
	orWhere(field: string, value: any, comparison: string = '=', table: string = null): this {
		this.checkBuilder();
		value = whereLogic(field, value);
		this.currentBuilder.WHERE.addToIndex(this.currentWhere, new Where(value, comparison, field, false, table || this.table));
		return this;
	}

	// Adds an "AND" where group statement to the query, which allows separation of wheres into groups
	whereGroup(whereFunction: (builder: this) => any): this {
		this.checkBuilder();
		this.currentBuilder.WHERE.addToIndex(this.currentWhere, new Where('', '=', '', true, this.table));
		this.currentWhere = this.currentBuilder.WHERE.highestIndex();
		whereFunction(this);
		this.currentWhere.splice(-1);
		return this;
	}

	// Adds an "OR" where group statement to the query, which allows separation of wheres into groups
	orWhereGroup(whereFunction: (builder: this) => any): this {
		this.checkBuilder();
		this.currentBuilder.WHERE.addToIndex(this.currentWhere, new Where('', '=', '', false, this.table));
		this.currentWhere = this.currentBuilder.WHERE.highestIndex();
		whereFunction(this);
		this.currentWhere.splice(-1);
		return this;
	}

	orderBy(field: string, asc : boolean = true) {
		this.checkBuilder();
		this.currentBuilder.ORDER_BY = { field: field, asc: asc, raw: false };
		return this;
	}

	orderByRaw(field: string, asc : boolean = true) {
		this.checkBuilder();
		this.currentBuilder.ORDER_BY = { field: field, asc: asc, raw: true };
		return this;
	}

	async executeQuery(query, map = false): Promise<T[]> {
		return this.execute(map, query);
	}

	// Executes the current command and returns an array
	async execute(map: boolean = true, queryString = this.getQuery()): Promise<T[] | any> {
		const self = this;
		if (this.debugMode) {
			console.log(queryString);
		}
		return new Promise<T[]>((resolve) => {
			const query = N1qlQuery.fromString(queryString);
			connection.query(query, (err, res) => {
				if (err) {
					// resolve null to handle errors, and handle the null in the service/controller instead
					console.log(err);
					resolve(null);
				} else {
					// { ...data, relations{} }
					resolve(map ? res.map((data) => {
						const relations = Object.assign({}, data);
						delete relations[self.table];
						const result = new self.Type();
						result.fill({ ...data[self.table], Relations: relations }, false);
						return result;
					}) : res);
				}
				self.deconstructor(self);
			});
		});
	}

	// adds a left join to the current query
	leftJoin(fromTable: string, toTable: string, foreignKey: string = null): this {
		if (foreignKey === null) {
			foreignKey = `${toTable}Id`;
		}
		this.currentBuilder.JOINS.push(new Join(fromTable, toTable, foreignKey));
		return this;
	}
}