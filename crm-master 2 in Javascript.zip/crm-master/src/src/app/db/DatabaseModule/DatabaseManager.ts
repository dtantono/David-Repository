import { DatabaseBuilder } from './DatabaseBuilder';
import { BaseModelRegister, Model } from './BaseModel';
import { RelationManager } from './RelationManager';
import { IDatabaseManager } from './Interfaces/IDatabaseManager';
import { ResultSet } from './ListTypes';

export class DatabaseManager<T extends Model<BaseModelRegister>> implements IDatabaseManager<T> {
	private readonly builders: DatabaseBuilder<T>[];
	private readonly type: string;
	private relations: RelationManager;

	constructor(private Model: new() => T, relations: RelationManager) {
		this.type = (new Model()).getType();
		this.builders = [];
		this.relations = relations;
		this.deconstructBuilder = this.deconstructBuilder.bind(this);
	}

	all(): Promise<ResultSet<T>> {
		const b = this.newQuery();
		return b.get();
	}

	async find(id: string): Promise<T | null> {
		const data: Model<BaseModelRegister> = await this.newBuilder().find(id.includes('/') ? id : `${this.type}/${id}`);
		if (data && !data.isDeleted()) {
			const model = new this.Model() as T;
			model.fill(data, true);
			return model;
		}
		return null;
	}

	private newBuilder() {
		this.builders.push(new DatabaseBuilder<T>(this.Model, this.deconstructBuilder));
		return this.builders[this.builders.length - 1];
	}

	with(...types: string[]) {
		const builder = this.newQuery();
		types.forEach((type) => {
			if (this.relations.hasRelation(this.type, type)) {
				builder.leftJoin(this.type, type, this.relations.getRelation(this.type, type));
			} else {
				console.log(this.type, 'and', type, 'have no relation');
			}
		});
		return builder;
	}

	newQuery(filterDeleted : boolean = true, filterActive : boolean = false) {
		let query = this.newBuilder().where('type', this.type);
		query = filterDeleted ? query.active() : query;
		query = filterActive ? query.deleted() : query;
		return query;
	}

	deconstructBuilder(item) {
		this.builders.splice(this.builders.indexOf(item), 1);
	}

	count() {
		return this.newQuery().count();
	}

	save(model: T) {
		model.update();
		return this.newBuilder().upsert(`${model.getType()}/${model.getKey()}`, model.all());
	}

	delete(model: T) {
		model.delete();
		return this.save(model);
	}
}
