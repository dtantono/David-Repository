

export const arrayToCouchbaseArray = (array: string[], lower: boolean = true) : string => `["${lower ? array.join(`","`).toLowerCase() : array.join(`","`)}"]`;