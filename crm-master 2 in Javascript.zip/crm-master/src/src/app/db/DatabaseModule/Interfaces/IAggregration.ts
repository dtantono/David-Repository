export interface IAggregration {

}
