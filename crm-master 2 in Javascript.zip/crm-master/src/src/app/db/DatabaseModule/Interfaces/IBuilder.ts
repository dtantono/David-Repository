import { IAggregration } from './IAggregration';
import { INest } from './INest';
import { IWhere } from './IWhere';
import { IJoin } from './IJoin';

export interface IBuilder {
	SELECT: string,
	JOINS: (IJoin | INest)[];
	COUNT: boolean,
	WHERE: IWhere,
	DELETE: boolean,
	FROM: string,
	AGGREGATIONS: IAggregration[],
	LIMIT: number,
	OFFSET: number
}
