export interface IDatabaseBuilder<T> {

	getQuery(): string;

	upsert(key: string, data: object): Promise<string>;

	find(key: string): Promise<T | null>;

	refreshBuilder();

	checkBuilder();

	select(...fields: string[]): this;

	count(): Promise<number>;

	get();

	active() : this;

	limit(limit: number) : this;

	deleted() : this;

	delete(): any;

	first();

	orWhereAny(field: string, value: any, comparison: string, nestedProperty: string, table: string);

	whereAny(field: string, value: any, comparison: string, nestedProperty: string, table: string)

	where(field: string, value: any, comparison: string): this;

	orWhere(field: string, value: any, comparison: string): this;

	whereGroup(callback: (builder: this) => any): this;

	orWhereGroup(callback: (builder: this) => any): this;

	leftJoin(fromTable: string, toTable: string, foreignKey: string): this;

	execute(map: boolean, queryString: string): Promise<T[]>;

	executeQuery(query: string): Promise<T[]>;
}
