import { IModel } from '../BaseModel';
import { BaseSet } from '../ListTypes';
import { DatabaseBuilder } from '../DatabaseBuilder';

export interface IDatabaseManager<T extends IModel> {
	newQuery(filterDeleted : boolean): DatabaseBuilder<T>;

	all(): Promise<BaseSet<T>>;

	find(id: string): Promise<IModel | null>;

	save(model: IModel): Promise<string>;

	delete(model: IModel): Promise<string>;
}
