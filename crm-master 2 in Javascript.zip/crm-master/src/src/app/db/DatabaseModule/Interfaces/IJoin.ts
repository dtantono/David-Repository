export interface IJoin {
	fromTable: string;
	toTable: string;
	foreignKey: string;

	getQuery(database: string): string;
}
