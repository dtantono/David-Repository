export interface IWhere {
	field: string;
	and: boolean;
	value: any;
	comparison: string;
	embedded: any[];
	table: string;
	any: boolean;

	addToIndex(index: number[], where: any);

	highestIndex();

	setIndex(index: number[], where: any);

	getQuery(first: boolean): string;
}
