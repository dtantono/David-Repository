import { IModel } from './BaseModel';
import { whereLogic } from './DatabaseBuilder';

export class PaginatedList<T extends IModel> {
	data: ResultSet<T>;
	currentPage: number;
	perPage: number;
	total: number;
	hasNextPage: boolean;

	constructor(data: ResultSet<T>,
	            currentPage: number,
	            perPage: number,
	            total: number,
	            hasNextPage: boolean) {
		this.data = data;
		this.currentPage = currentPage;
		this.perPage = perPage;
		this.total = total;
		this.hasNextPage = hasNextPage;
	}

	public() {
		const ret = Object.assign({}, this) as any;
		ret.data = ret.data.public();
		return ret;
	}
}

export class BaseSet<T> extends Array<T> {
	constructor(data: any = []) {
		super();
		Object.assign(this, data);
	}
	first() {
		return this.length > 0 ? this[0] : null;
	}

	where(field: string, value: string, comparison: string = '=') {
		value = whereLogic(field, value);
		switch (comparison) {
			case '=':
				return this.filter((x) => x[field] === value) as BaseSet<T>;
			default:
				throw new Error('Comparison method not supported');
		}
	}
}

export class ResultSet<T extends IModel> extends BaseSet<T> {
	public(...excludeProperties: string[]) {
		return this.map((x) => x.public(...excludeProperties));
	}
}
