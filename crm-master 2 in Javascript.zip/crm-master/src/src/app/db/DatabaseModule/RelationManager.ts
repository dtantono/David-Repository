import { BaseSet } from './ListTypes';

export class RelationManager extends BaseSet<Relation> {
	hasRelation(from: string, to: string) {
		return this.where('from', from).where('to', to).length > 0;
	}

	getRelation(from: string, to: string) {
		const relation = this.where('from', from).where('to', to).first();
		if (relation) {
			return relation.fromKey === '' ? `${to}Id` : relation.fromKey;
		}
	}
}

export class Relation {
	from: string;
	to: string;
	fromKey: string;

	constructor(from: string, to: string, fromKey: string = '') {
		this.from = from;
		this.to = to;
		this.fromKey = fromKey;
	}
}
