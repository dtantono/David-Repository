export default {
	1: { name: 'Applied' , ja: '適用されました' },
	2: { name: 'In progress' , ja: '進行中' },
	3: { name: 'Dropped' , ja: 'ドロップされました' },
	4: { name: 'Declined' , ja: '辞退' },
	5: { name: 'Offered' , ja: '提供' },
	6: { name: 'Accepted', ja: '容認されました'  }
};
