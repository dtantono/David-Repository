export default {
	1: { name: 'Available', ja: '暇' },
	2: { name: 'Busy', ja: '忙しい' },
	3: { name: 'Meeting', ja: '会議' }
};
