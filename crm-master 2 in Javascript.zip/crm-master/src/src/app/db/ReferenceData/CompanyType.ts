export default {
	1: { name: 'Shareholder Company', ja: '株主会社' },
	2: { name: 'Partnership', ja: 'パートナーシップ' },
	3: { name: 'Startup', ja: '新興企業' }
};
