export default {
	1: { name: 'Male' },
	2: { name: 'Female' }
};
