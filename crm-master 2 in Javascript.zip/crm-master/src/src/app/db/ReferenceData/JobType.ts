export default {
	0: { name: 'Permanent' },
	1: { name: 'Contract' },
	2: { name: 'Part time' }
};
