export default {
	ab: {
		name: 'Abkhaz',
		ja: 'アブハジア',
		nativeName: 'аҧсуа'
	},
	aa: {
		name: 'Afar',
		ja: '遠くに',
		nativeName: 'Afaraf'
	},
	af: {
		name: 'Afrikaans',
		ja: 'アフリカーンス',
		nativeName: 'Afrikaans'
	},
	ak: {
		name: 'Akan',
		ja: '阿寒',
		nativeName: 'Akan'
	},
	sq: {
		name: 'Albanian',
		ja: 'アルバニア語',
		nativeName: 'Shqip'
	},
	am: {
		name: 'Amharic',
		ja: 'アムハラ語',
		nativeName: 'አማርኛ'
	},
	ar: {
		name: 'Arabic',
		ja: 'アラビア語',
		nativeName: 'العربية'
	},
	an: {
		name: 'Aragonese',
		ja: 'アラゴン',
		nativeName: 'Aragonés'
	},
	hy: {
		name: 'Armenian',
		ja: 'アルメニア',
		nativeName: 'Հայերեն'
	},
	as: {
		name: 'Assamese',
		ja: 'アッサム',
		nativeName: 'অসমীয়া'
	},
	av: {
		name: 'Avaric',
		ja: 'アヴァル',
		nativeName: 'авар мацӀ, магӀарул мацӀ'
	},
	ae: {
		name: 'Avestan',
		ja: 'アヴェスタ',
		nativeName: 'avesta'
	},
	ay: {
		name: 'Aymara',
		ja: 'アイマラ語',
		nativeName: 'aymar aru'
	},
	az: {
		name: 'Azerbaijani',
		ja: 'アゼルバイジャン',
		nativeName: 'azərbaycan dili'
	},
	bm: {
		name: 'Bambara',
		ja: 'バンバラ語',
		nativeName: 'bamanankan'
	},
	ba: {
		name: 'Bashkir',
		ja: 'バシキール',
		nativeName: 'башҡорт теле'
	},
	eu: {
		name: 'Basque',
		ja: 'バスク',
		nativeName: 'euskara, euskera'
	},
	be: {
		name: 'Belarusian',
		ja: 'ベラルーシ',
		nativeName: 'Беларуская'
	},
	bn: {
		name: 'Bengali',
		ja: 'ベンガル語',
		nativeName: 'বাংলা'
	},
	bh: {
		name: 'Bihari',
		ja: 'ビハール語',
		nativeName: 'भोजपुरी'
	},
	bi: {
		name: 'Bislama',
		ja: 'ビスラマ',
		nativeName: 'Bislama'
	},
	bs: {
		name: 'Bosnian',
		ja: 'ボスニア語',
		nativeName: 'bosanski jezik'
	},
	br: {
		name: 'Breton',
		ja: 'ブルトン',
		nativeName: 'brezhoneg'
	},
	bg: {
		name: 'Bulgarian',
		ja: 'ブルガリア',
		nativeName: 'български език'
	},
	my: {
		name: 'Burmese',
		ja: 'ビルマ',
		nativeName: 'ဗမာစာ'
	},
	ca: {
		name: 'Catalan; Valencian',
		ja: 'カタロニア語;バレンシア',
		nativeName: 'Català'
	},
	ch: {
		name: 'Chamorro',
		ja: 'チャモロ語',
		nativeName: 'Chamoru'
	},
	ce: {
		name: 'Chechen',
		ja: 'チェチェン',
		nativeName: 'нохчийн мотт'
	},
	ny: {
		name: 'Chichewa; Chewa; Nyanja',
		ja: 'チェワ; Chewa;ニャンジャ語',
		nativeName: 'chiCheŵa, chinyanja'
	},
	zh: {
		name: 'Chinese',
		ja: '中国の',
		nativeName: '中文 (Zhōngwén), 汉语, 漢語'
	},
	cv: {
		name: 'Chuvash',
		ja: 'チュヴァシュ',
		nativeName: 'чӑваш чӗлхи'
	},
	kw: {
		name: 'Cornish',
		ja: 'コーニッシュ',
		nativeName: 'Kernewek'
	},
	co: {
		name: 'Corsican',
		ja: 'コルシカ',
		nativeName: 'corsu, lingua corsa'
	},
	cr: {
		name: 'Cree',
		ja: 'クリー',
		nativeName: 'ᓀᐦᐃᔭᐍᐏᐣ'
	},
	hr: {
		name: 'Croatian',
		ja: 'クロアチア',
		nativeName: 'hrvatski'
	},
	cs: {
		name: 'Czech',
		ja: 'チェコ',
		nativeName: 'česky, čeština'
	},
	da: {
		name: 'Danish',
		ja: 'デンマーク',
		nativeName: 'dansk'
	},
	dv: {
		name: 'Divehi; Dhivehi; Maldivian;',
		ja: 'ディベヒ語;ディベヒ語;モルディブ;',
		nativeName: 'ދިވެހި'
	},
	nl: {
		name: 'Dutch',
		ja: 'オランダの',
		nativeName: 'Nederlands, Vlaams'
	},
	en: {
		name: 'English',
		ja: '英語',
		nativeName: 'English'
	},
	eo: {
		name: 'Esperanto',
		ja: 'エスペラント',
		nativeName: 'Esperanto'
	},
	et: {
		name: 'Estonian',
		ja: 'エストニア',
		nativeName: 'eesti, eesti keel'
	},
	ee: {
		name: 'Ewe',
		ja: 'エウェ語',
		nativeName: 'Eʋegbe'
	},
	fo: {
		name: 'Faroese',
		ja: 'フェロー語',
		nativeName: 'føroyskt'
	},
	fj: {
		name: 'Fijian',
		ja: 'フィジー',
		nativeName: 'vosa Vakaviti'
	},
	fi: {
		name: 'Finnish',
		ja: 'フィンランド',
		nativeName: 'suomi, suomen kieli'
	},
	fr: {
		name: 'French',
		ja: 'フランス語',
		nativeName: 'français, langue française'
	},
	ff: {
		name: 'Fula; Fulah; Pulaar; Pular',
		ja: 'フラニ語;フラニ語; Pulaar; Pular',
		nativeName: 'Fulfulde, Pulaar, Pular'
	},
	gl: {
		name: 'Galician',
		ja: 'ガリシア',
		nativeName: 'Galego'
	},
	ka: {
		name: 'Georgian',
		ja: 'グルジア',
		nativeName: 'ქართული'
	},
	de: {
		name: 'German',
		ja: 'ドイツ人',
		nativeName: 'Deutsch'
	},
	el: {
		name: 'Greek, Modern',
		ja: 'ギリシャ、現代',
		nativeName: 'Ελληνικά'
	},
	gn: {
		name: 'Guaraní',
		ja: 'グアラニ',
		nativeName: 'Avañeẽ'
	},
	gu: {
		name: 'Gujarati',
		ja: 'グジャラート語',
		nativeName: 'ગુજરાતી'
	},
	ht: {
		name: 'Haitian; Haitian Creole',
		ja: 'ハイチ;ハイチクレオール',
		nativeName: 'Kreyòl ayisyen'
	},
	ha: {
		name: 'Hausa',
		ja: 'ハウサ語',
		nativeName: 'Hausa, هَوُسَ'
	},
	he: {
		name: 'Hebrew (modern)',
		ja: 'ヘブライ語（現代）',
		nativeName: 'עברית'
	},
	hz: {
		name: 'Herero',
		ja: 'ヘレロ語',
		nativeName: 'Otjiherero'
	},
	hi: {
		name: 'Hindi',
		ja: 'ヒンディー語',
		nativeName: 'हिन्दी, हिंदी'
	},
	ho: {
		name: 'Hiri Motu',
		ja: 'ヒリモツ語',
		nativeName: 'Hiri Motu'
	},
	hu: {
		name: 'Hungarian',
		ja: 'ハンガリー',
		nativeName: 'Magyar'
	},
	ia: {
		name: 'Interlingua',
		ja: 'インターリングア',
		nativeName: 'Interlingua'
	},
	id: {
		name: 'Indonesian',
		ja: 'インドネシア',
		nativeName: 'Bahasa Indonesia'
	},
	ie: {
		name: 'Interlingue',
		ja: 'インター',
		nativeName: 'Originally called Occidental; then Interlingue after WWII'
	},
	ga: {
		name: 'Irish',
		ja: 'アイルランド人',
		nativeName: 'Gaeilge'
	},
	ig: {
		name: 'Igbo',
		ja: 'イボ',
		nativeName: 'Asụsụ Igbo'
	},
	ik: {
		name: 'Inupiaq',
		ja: 'イヌピアック語',
		nativeName: 'Iñupiaq, Iñupiatun'
	},
	io: {
		name: 'Ido',
		ja: '私がやります',
		nativeName: 'Ido'
	},
	is: {
		name: 'Icelandic',
		ja: 'アイスランド',
		nativeName: 'Íslenska'
	},
	it: {
		name: 'Italian',
		ja: 'イタリアの',
		nativeName: 'Italiano'
	},
	iu: {
		name: 'Inuktitut',
		ja: 'イヌクティトゥト語',
		nativeName: 'ᐃᓄᒃᑎᑐᑦ'
	},
	ja: {
		name: 'Japanese',
		ja: '日本人',
		nativeName: '日本語 (にほんご／にっぽんご)'
	},
	jv: {
		name: 'Javanese',
		ja: 'ジャワ',
		nativeName: 'basa Jawa'
	},
	kl: {
		name: 'Kalaallisut, Greenlandic',
		ja: 'グリーンランド語、グリーンランド',
		nativeName: 'kalaallisut, kalaallit oqaasii'
	},
	kn: {
		name: 'Kannada',
		ja: 'カンナダ語',
		nativeName: 'ಕನ್ನಡ'
	},
	kr: {
		name: 'Kanuri',
		ja: 'カヌリ語',
		nativeName: 'Kanuri'
	},
	ks: {
		name: 'Kashmiri',
		ja: 'カシミール語',
		nativeName: 'कश्मीरी, كشميري‎'
	},
	kk: {
		name: 'Kazakh',
		ja: 'カザフ',
		nativeName: 'Қазақ тілі'
	},
	km: {
		name: 'Khmer',
		ja: 'クメール語',
		nativeName: 'ភាសាខ្មែរ'
	},
	ki: {
		name: 'Kikuyu, Gikuyu',
		ja: 'キクユ、Gikuyu',
		nativeName: 'Gĩkũyũ'
	},
	rw: {
		name: 'Kinyarwanda',
		ja: 'ルワンダ語',
		nativeName: 'Ikinyarwanda'
	},
	ky: {
		name: 'Kirghiz, Kyrgyz',
		ja: 'キルギス語、キルギス',
		nativeName: 'кыргыз тили'
	},
	kv: {
		name: 'Komi',
		ja: 'コミ',
		nativeName: 'коми кыв'
	},
	kg: {
		name: 'Kongo',
		ja: '金剛',
		nativeName: 'KiKongo'
	},
	ko: {
		name: 'Korean',
		ja: '韓国語',
		nativeName: '한국어 (韓國語), 조선말 (朝鮮語)'
	},
	ku: {
		name: 'Kurdish',
		ja: 'クルド',
		nativeName: 'Kurdî, كوردی‎'
	},
	kj: {
		name: 'Kwanyama, Kuanyama',
		ja: 'Kwanyama、Kuanyama',
		nativeName: 'Kuanyama'
	},
	la: {
		name: 'Latin',
		ja: 'ラテン',
		nativeName: 'latine, lingua latina'
	},
	lb: {
		name: 'Luxembourgish, Letzeburgesch',
		ja: 'ルクセンブルク、Letzeburgesch',
		nativeName: 'Lëtzebuergesch'
	},
	lg: {
		name: 'Luganda',
		ja: 'ガンダ語',
		nativeName: 'Luganda'
	},
	li: {
		name: 'Limburgish, Limburgan, Limburger',
		ja: 'リンブルフ、Limburgan、リンバーガー',
		nativeName: 'Limburgs'
	},
	ln: {
		name: 'Lingala',
		ja: 'リンガラ語',
		nativeName: 'Lingála'
	},
	lo: {
		name: 'Lao',
		ja: 'ラオス',
		nativeName: 'ພາສາລາວ'
	},
	lt: {
		name: 'Lithuanian',
		ja: 'リトアニア',
		nativeName: 'lietuvių kalba'
	},
	lu: {
		name: 'Luba-Katanga',
		ja: 'ルバ・カタンガ',
		nativeName: ''
	},
	lv: {
		name: 'Latvian',
		ja: 'ラトビア',
		nativeName: 'latviešu valoda'
	},
	gv: {
		name: 'Manx',
		ja: 'マンクス',
		nativeName: 'Gaelg, Gailck'
	},
	mk: {
		name: 'Macedonian',
		ja: 'マケドニアの',
		nativeName: 'македонски јазик'
	},
	mg: {
		name: 'Malagasy',
		ja: 'マダガスカル',
		nativeName: 'Malagasy fiteny'
	},
	ms: {
		name: 'Malay',
		ja: 'マレー語',
		nativeName: 'bahasa Melayu, بهاس ملايو‎'
	},
	ml: {
		name: 'Malayalam',
		ja: 'マラヤーラム語',
		nativeName: 'മലയാളം'
	},
	mt: {
		name: 'Maltese',
		ja: 'マルタ',
		nativeName: 'Malti'
	},
	mi: {
		name: 'Māori',
		ja: 'マオリ',
		nativeName: 'te reo Māori'
	},
	mr: {
		name: 'Marathi (Marāṭhī)',
		ja: 'マラーティー語（マラーティー語）',
		nativeName: 'मराठी'
	},
	mh: {
		name: 'Marshallese',
		ja: 'マーシャル',
		nativeName: 'Kajin M̧ajeļ'
	},
	mn: {
		name: 'Mongolian',
		ja: 'モンゴル',
		nativeName: 'монгол'
	},
	na: {
		name: 'Nauru',
		ja: 'ナウル',
		nativeName: 'Ekakairũ Naoero'
	},
	nv: {
		name: 'Navajo, Navaho',
		ja: 'ナバホ、ナバホ',
		nativeName: 'Diné bizaad, Dinékʼehǰí'
	},
	nb: {
		name: 'Norwegian Bokmål',
		ja: 'ノルウェー語',
		nativeName: 'Norsk bokmål'
	},
	nd: {
		name: 'North Ndebele',
		ja: '北ンデベレ語',
		nativeName: 'isiNdebele'
	},
	ne: {
		name: 'Nepali',
		ja: 'ネパール',
		nativeName: 'नेपाली'
	},
	ng: {
		name: 'Ndonga',
		ja: 'Ndonga',
		nativeName: 'Owambo'
	},
	nn: {
		name: 'Norwegian Nynorsk',
		ja: 'ノルウェー語[ニーノシュク]',
		nativeName: 'Norsk nynorsk'
	},
	no: {
		name: 'Norwegian',
		ja: 'ノルウェーの',
		nativeName: 'Norsk'
	},
	ii: {
		name: 'Nuosu',
		ja: 'Nuosu',
		nativeName: 'ꆈꌠ꒿ Nuosuhxop'
	},
	nr: {
		name: 'South Ndebele',
		ja: '南ンデベレ語',
		nativeName: 'isiNdebele'
	},
	oc: {
		name: 'Occitan',
		ja: 'オック語',
		nativeName: 'Occitan'
	},
	oj: {
		name: 'Ojibwe, Ojibwa',
		ja: 'オジブワ、オジブワ',
		nativeName: 'ᐊᓂᔑᓈᐯᒧᐎᓐ'
	},
	cu: {
		name: 'Old Church Slavonic, Church Slavic, Church Slavonic, Old Bulgarian, Old Slavonic',
		ja: '古代教会スラヴ語、教会スラブ語、教会スラヴ、旧ブルガリア、旧スラヴ',
		nativeName: 'ѩзыкъ словѣньскъ'
	},
	om: {
		name: 'Oromo',
		ja: 'オロモ',
		nativeName: 'Afaan Oromoo'
	},
	or: {
		name: 'Oriya',
		ja: 'オリヤー語',
		nativeName: 'ଓଡ଼ିଆ'
	},
	os: {
		name: 'Ossetian, Ossetic',
		ja: 'オセチア、オセト',
		nativeName: 'ирон æвзаг'
	},
	pa: {
		name: 'Panjabi, Punjabi',
		ja: 'パンジャブ語、パンジャブ語',
		nativeName: 'ਪੰਜਾਬੀ, پنجابی‎'
	},
	pi: {
		name: 'Pāli',
		ja: 'パーリ語',
		nativeName: 'पाऴि'
	},
	fa: {
		name: 'Persian',
		ja: 'ペルシアの',
		nativeName: 'فارسی'
	},
	pl: {
		name: 'Polish',
		ja: '研磨',
		nativeName: 'polski'
	},
	ps: {
		name: 'Pashto, Pushto',
		ja: 'パシュトゥー語、パシュトゥ語',
		nativeName: 'پښتو'
	},
	pt: {
		name: 'Portuguese',
		ja: 'ポルトガル語',
		nativeName: 'Português'
	},
	qu: {
		name: 'Quechua',
		ja: 'ケチュア語',
		nativeName: 'Runa Simi, Kichwa'
	},
	rm: {
		name: 'Romansh',
		ja: 'ロマンシュ',
		nativeName: 'rumantsch grischun'
	},
	rn: {
		name: 'Kirundi',
		ja: 'キルンディ語',
		nativeName: 'kiRundi'
	},
	ro: {
		name: 'Romanian, Moldavian, Moldovan',
		ja: 'ルーマニア、モルドバ、モルドバ',
		nativeName: 'română'
	},
	ru: {
		name: 'Russian',
		ja: 'ロシア',
		nativeName: 'русский язык'
	},
	sa: {
		name: 'Sanskrit (Saṁskṛta)',
		ja: 'サンスクリット語（Saṁskṛta）',
		nativeName: 'संस्कृतम्'
	},
	sc: {
		name: 'Sardinian',
		ja: 'サルデーニャ',
		nativeName: 'sardu'
	},
	sd: {
		name: 'Sindhi',
		ja: 'シンド語',
		nativeName: 'सिन्धी, سنڌي، سندھی‎'
	},
	se: {
		name: 'Northern Sami',
		ja: '北サーミ',
		nativeName: 'Davvisámegiella'
	},
	sm: {
		name: 'Samoan',
		ja: 'サモア',
		nativeName: 'gagana faa Samoa'
	},
	sg: {
		name: 'Sango',
		ja: 'サンゴ',
		nativeName: 'yângâ tî sängö'
	},
	sr: {
		name: 'Serbian',
		ja: 'セルビア',
		nativeName: 'српски језик'
	},
	gd: {
		name: 'Scottish Gaelic; Gaelic',
		ja: 'スコットランド・ゲール語;ゲール語',
		nativeName: 'Gàidhlig'
	},
	sn: {
		name: 'Shona',
		ja: 'ショナ語',
		nativeName: 'chiShona'
	},
	si: {
		name: 'Sinhala, Sinhalese',
		ja: 'シンハラ語、シンハラ語',
		nativeName: 'සිංහල'
	},
	sk: {
		name: 'Slovak',
		ja: 'スロバキア',
		nativeName: 'slovenčina'
	},
	sl: {
		name: 'Slovene',
		ja: 'スロベニア',
		nativeName: 'slovenščina'
	},
	so: {
		name: 'Somali',
		ja: 'ソマリア',
		nativeName: 'Soomaaliga, af Soomaali'
	},
	st: {
		name: 'Southern Sotho',
		ja: '南ソト語',
		nativeName: 'Sesotho'
	},
	es: {
		name: 'Spanish; Castilian',
		ja: 'スペイン語;キャステリャ',
		nativeName: 'español, castellano'
	},
	su: {
		name: 'Sundanese',
		ja: 'スンダ',
		nativeName: 'Basa Sunda'
	},
	sw: {
		name: 'Swahili',
		ja: 'スワヒリ語',
		nativeName: 'Kiswahili'
	},
	ss: {
		name: 'Swati',
		ja: 'スワティ',
		nativeName: 'SiSwati'
	},
	sv: {
		name: 'Swedish',
		ja: 'スウェーデンの',
		nativeName: 'svenska'
	},
	ta: {
		name: 'Tamil',
		ja: 'タミル語',
		nativeName: 'தமிழ்'
	},
	te: {
		name: 'Telugu',
		ja: 'テルグ語',
		nativeName: 'తెలుగు'
	},
	tg: {
		name: 'Tajik',
		ja: 'タジク',
		nativeName: 'тоҷикӣ, toğikī, تاجیکی‎'
	},
	th: {
		name: 'Thai',
		ja: 'タイ',
		nativeName: 'ไทย'
	},
	ti: {
		name: 'Tigrinya',
		ja: 'ティグリニア語',
		nativeName: 'ትግርኛ'
	},
	bo: {
		name: 'Tibetan Standard, Tibetan, Central',
		ja: 'チベット標準、チベット、中央',
		nativeName: 'བོད་ཡིག'
	},
	tk: {
		name: 'Turkmen',
		ja: 'トルクメン',
		nativeName: 'Türkmen, Түркмен'
	},
	tl: {
		name: 'Tagalog',
		ja: 'タガログ語',
		nativeName: 'Wikang Tagalog, ᜏᜒᜃᜅ᜔ ᜆᜄᜎᜓᜄ᜔'
	},
	tn: {
		name: 'Tswana',
		ja: 'ツワナ語',
		nativeName: 'Setswana'
	},
	to: {
		name: 'Tonga (Tonga Islands)',
		ja: 'トンガ（トンガ諸島）',
		nativeName: 'faka Tonga'
	},
	tr: {
		name: 'Turkish',
		ja: 'トルコ語',
		nativeName: 'Türkçe'
	},
	ts: {
		name: 'Tsonga',
		ja: 'ツォンガ',
		nativeName: 'Xitsonga'
	},
	tt: {
		name: 'Tatar',
		ja: 'タタール',
		nativeName: 'татарча, tatarça, تاتارچا‎'
	},
	tw: {
		name: 'Twi',
		ja: 'TWI',
		nativeName: 'Twi'
	},
	ty: {
		name: 'Tahitian',
		ja: 'タヒチ',
		nativeName: 'Reo Tahiti'
	},
	ug: {
		name: 'Uighur, Uyghur',
		ja: 'ウイグル語、ウイグル',
		nativeName: 'Uyƣurqə, ئۇيغۇرچە‎'
	},
	uk: {
		name: 'Ukrainian',
		ja: 'ウクライナ',
		nativeName: 'українська'
	},
	ur: {
		name: 'Urdu',
		ja: 'ウルドゥー語',
		nativeName: 'اردو'
	},
	uz: {
		name: 'Uzbek',
		ja: 'ウズベク',
		nativeName: 'zbek, Ўзбек, أۇزبېك‎'
	},
	ve: {
		name: 'Venda',
		ja: 'ヴェンダ',
		nativeName: 'Tshivenḓa'
	},
	vi: {
		name: 'Vietnamese',
		ja: 'ベトナム語',
		nativeName: 'Tiếng Việt'
	},
	vo: {
		name: 'Volapük',
		ja: 'ボラピュク',
		nativeName: 'Volapük'
	},
	wa: {
		name: 'Walloon',
		ja: 'ワロン',
		nativeName: 'Walon'
	},
	cy: {
		name: 'Welsh',
		ja: 'ウェールズ',
		nativeName: 'Cymraeg'
	},
	wo: {
		name: 'Wolof',
		ja: 'ウォロフ',
		nativeName: 'Wollof'
	},
	fy: {
		name: 'Western Frisian',
		ja: 'フリジア',
		nativeName: 'Frysk'
	},
	xh: {
		name: 'Xhosa',
		ja: 'コーサ語',
		nativeName: 'isiXhosa'
	},
	yi: {
		name: 'Yiddish',
		ja: 'イディッシュ語',
		nativeName: 'ייִדיש'
	},
	yo: {
		name: 'Yoruba',
		ja: 'ヨルバ語',
		nativeName: 'Yorùbá'
	},
	za: {
		name: 'Zhuang, Chuang',
		ja: '荘、荘',
		nativeName: 'Saɯ cueŋƅ, Saw cuengh'
	}
}
;
