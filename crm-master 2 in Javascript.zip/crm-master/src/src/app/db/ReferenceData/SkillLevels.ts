export default {
	1: { name: 'Beginner' },
	2: { name: 'Intermediate' },
	3: { name: 'Professional Proficiency' },
	4: { name: 'Native or Bilingual Proficiency' }
};
