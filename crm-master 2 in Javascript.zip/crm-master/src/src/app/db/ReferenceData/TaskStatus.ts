export default {
	1: { name: 'Not started' },
	2: { name: 'In progress' },
	3: { name: 'Waiting' },
	4: { name: 'Completed' },
	5: { name: 'Deferred' }
};
