export default {
	0: { name: 'Administrator' },
	1: { name: 'User' }
};
