import Gender from './ReferenceData/Gender';
import Countries from './ReferenceData/Countries';
import Level from './ReferenceData/SkillLevels';
import Languages from './ReferenceData/Languages';
import JobType from './ReferenceData/JobType';
import UserRoles from './ReferenceData/UserRoles';
import ApplicationStatus from './ReferenceData/ApplicationStatus';
import TaskStatus from './ReferenceData/TaskStatus';
import AvailabilityType from './ReferenceData/AvailabilityType';
import FeatureSkills from './ReferenceData/Skills';
import CompanyType from './ReferenceData/CompanyType';
import Cities from './ReferenceData/Cities';

export const ReferenceData = {
	Gender,
	Level,
	Countries,
	Cities,
	Languages,
	JobType,
	UserRoles,
	ApplicationStatus,
	TaskStatus,
	AvailabilityType,
	FeatureSkills,
	CompanyType,
	JobTitles: {},
	TaskType: {1: {name: 'Interview'}, 2: {name: 'Todo'}, 3: {name: 'Document'}, 4: {name: 'Default'}, 5: {name: 'Folder'}}
} as MasterData;

export interface MasterData {
	Gender: object,
	Level: object,
	Countries: object,
	Cities: object,
	Languages: object,
	JobType: object,
	UserRoles: object,
	ApplicationStatus: object,
	TaskStatus: object,
	AvailabilityType: object,
	FeatureSkills: object,
	JobTitles: object,
	CompanyType: object,
	TaskType: object
}

