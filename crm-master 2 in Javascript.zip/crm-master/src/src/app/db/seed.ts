import { Candidate } from '../models/Candidate';
import { RecruiterUser } from '../models/RecruiterUser';
import { Recruiter } from '../models/Recruiter';
import {IInterviewTask, Pipeline, Task, TodoTask} from '../models/Pipeline';
import { Company } from '../models/Company';
import { CompanyUser } from '../models/CompanyUser';
import { Opening } from '../models/Opening';
import { Resume } from '../models/Resume';
import { Event } from '../models/Event';
import * as db from './database';
import { Application } from '../models/Application';
import {asyncForEach} from "../helpers/arrayHelpers";
import {Account} from "../models/Account";

const bcrypt = require('bcrypt');

const openingService = require('../services/openings');
const applicationService = require('../services/applications');
const pipelineService = require('../services/pipelines');
const recruiterService = require('../services/recruiters');
const candidateService = require('../services/candidates');
const resumeService = require('../services/resumes');

const faker = require('faker');
faker.seed(123);
const info = require('../services/info');

// function getFormattedTime(hourSkew = 0) {
// 	const hours = ((new Date()).getHours() + hourSkew) % 24;
// 	const minutes = (new Date()).getMinutes();
// 	return ` ${hours}:${minutes}`;
// }

// default models are used for seeding and for testing
function getRandomDate(bNew) {
	const date = bNew ? faker.date.future() : faker.date.past();
	const month = parseInt(date.getMonth(), 0) + 1;
	const day = parseInt(date.getDate(), 0);
	return `${date.getFullYear()}-${month < 10 ? `0${month}` : month}-${day < 10 ? `0${day}` : day}`;
}

// functions to clear from the database
async function clearUsers() {
	await db.candidates.newQuery().delete();
}

async function clearResumes() {
	await db.resumes.newQuery().delete();
}

async function clearEvents() {
	await db.events.newQuery().delete();
}

async function clearRecruiters() {
	await db.recruiters.newQuery().delete();
	await db.accounts.newQuery().delete();
}

async function clearOpenings() {
	await db.openings.newQuery().delete();
	await db.applications.newQuery().delete();
}

async function clearCompanyUsers() {
	await db.companies.newQuery().delete();
	await db.companyUsers.newQuery().delete();
}

async function getRandomRefData(type) {
	const data = await info.jsonToNameValue((await info.getReferenceData())[type]);
	const index = Math.floor(Math.random() * data.length);
	return data[index].name;
}

async function generateRandomRecruiter() {
	const newRecruiter = new Recruiter();
	newRecruiter.RecruiterName = faker.company.companyName();
	newRecruiter.RecruiterId = faker.company.companyName();
	newRecruiter.Picture = faker.image.business();
	newRecruiter.IsSuperAdmin = false;
	newRecruiter.AddressOne = faker.address.streetAddress();
	newRecruiter.AddressTwo = faker.address.secondaryAddress();
	newRecruiter.EmployeeCount = 50;
	newRecruiter.Teams = [{Name: 'Sales', Members: []}];
	newRecruiter.CompanyUrl = 'www.google.co.jp';
	newRecruiter.PhoneNumber = '08051231131';
	newRecruiter.State = await getRandomRefData('Cities');
	newRecruiter.Country = await getRandomRefData('Countries');
	newRecruiter.Postcode = 'NR43 3ED';
	return newRecruiter;
}

async function generateRandomRecruiterUser(admin) {
	const newRecruiter = new RecruiterUser();
	newRecruiter.Active = Math.random() > 0.7;
	newRecruiter.FirstName = faker.name.firstName();
	newRecruiter.LastName = faker.name.lastName();
	newRecruiter.EmailAddress = faker.internet.email();
	newRecruiter.CurrentLocation = faker.address.country();
	newRecruiter.DateOfBirth = getRandomDate(false);
	newRecruiter.ProfilePicture = '';
	newRecruiter.Gender = Math.random() > 0.5 ? 'Male' : 'Female';
	newRecruiter.Nationality = faker.address.country();
	newRecruiter.PhoneNumber = faker.phone.phoneNumber();
	newRecruiter.HashPassword = bcrypt.hashSync('password', 10);
	newRecruiter.Role = admin ? 1 : 0;
	return newRecruiter;
}

async function generateRandomUser() {
	const newCandidate = new Candidate();
	newCandidate.Active = Math.random() > 0.7;
	newCandidate.FirstName = faker.name.firstName();
	newCandidate.LastName = faker.name.lastName();
	newCandidate.EmailAddress = faker.internet.email();
	newCandidate.CurrentLocation = faker.address.country();
	newCandidate.DateOfBirth = getRandomDate(false);
	newCandidate.Title = faker.company.catchPhrase();
	newCandidate.ProfilePicture = '';
	newCandidate.Gender = await getRandomRefData('Gender');
	newCandidate.JapaneseVisa = Math.random() > 0.5 ? 'Yes' : 'No';
	newCandidate.Nationality = faker.address.country();
	newCandidate.PhoneNumber = faker.phone.phoneNumber();
	newCandidate.HashPassword = bcrypt.hashSync('password', 10);
	return newCandidate;
}

async function generateRandomEvent() {
	const newEvent = new Event();
	newEvent.Title = faker.company.catchPhrase();
	newEvent.Body = faker.lorem.paragraph();
	newEvent.Users = [];
	newEvent.Availability = 'Busy';
	newEvent.Repeat = 'Daily';
	newEvent.Location = faker.address.streetAddress();
	newEvent.StartTime = Date.now(); // getFormattedTime(1);
	newEvent.EndTime = Date.now() + 2000;
	return newEvent;
}

export async function generateRandomCompany() {
	const newCompany = new Company();
	newCompany.CompanyName = faker.company.companyName();
	newCompany.Mission = faker.lorem.paragraph();
	newCompany.WhoCanApply = `Those who are skilled at ${faker.hacker.verb()} ${faker.hacker.noun()}`;
	newCompany.VisaSponsorship = `We can sponser those living in ${faker.address.country()} if you have a ${faker.hacker.noun()}`;
	newCompany.Headquarters = faker.address.streetAddress();
	newCompany.CompanySize = Math.round(200 * Math.random());
	newCompany.AddressOne = faker.address.secondaryAddress();
	newCompany.About = faker.lorem.paragraph();
	newCompany.MainBusiness = [faker.company.catchPhrase(), faker.company.catchPhrase(), faker.company.catchPhrase(), faker.company.catchPhrase()];
	newCompany.AddressTwo = faker.address.streetAddress();
	newCompany.Country = faker.address.country();
	newCompany.Industry = faker.hacker.noun();
	newCompany.PhoneNumber = faker.phone.phoneNumber();
	newCompany.Founded = Date.now();
	newCompany.CompanyType = await getRandomRefData('CompanyType');
	newCompany.Website = faker.internet.url();
	return newCompany;
}

async function generateRandomCompanyUser(admin) {
	const newCompanyUser = new CompanyUser();
	newCompanyUser.Active = Math.random() > 0.7;
	newCompanyUser.FirstName = faker.name.firstName();
	newCompanyUser.LastName = faker.name.lastName();
	newCompanyUser.EmailAddress = faker.internet.email();
	newCompanyUser.CurrentLocation = faker.address.country();
	newCompanyUser.DateOfBirth = getRandomDate(false);
	newCompanyUser.Gender = Math.random() > 0.5 ? 'Male' : 'Female';
	newCompanyUser.Role = admin ? 1 : 0;
	newCompanyUser.Nationality = faker.address.country();
	newCompanyUser.PhoneNumber = faker.phone.phoneNumber();
	newCompanyUser.ProfilePicture = '';
	newCompanyUser.Position = faker.hacker.noun();
	newCompanyUser.HashPassword = bcrypt.hashSync('password', 10);
	return newCompanyUser;
}

async function generateRandomPipeline() {
	const newPipeline = new Pipeline();
	newPipeline.Title = faker.company.catchPhrase();
	newPipeline.Tasks = [];
	let task = new Task();
	let array = [1, 2, 3];
	await asyncForEach(array, async (i) => {
		task.fill({
			Name: faker.hacker.noun(),
			TaskType: 'Todo',
			TodoList: [faker.hacker.noun(), faker.hacker.noun(), faker.hacker.noun()],
			Deadline: i * 2,
			Description: faker.lorem.paragraph()
		});
		await db.tasks.save(task);
		newPipeline.Tasks.push(task);
	});

	task = new Task();
	task.fill({
		Name: faker.hacker.noun(),
		TaskType: 'Interview',
		InterviewDetails: {
			Location: faker.address.streetAddress(),
			From: Date.now(),
			To: Date.now() + 3600
		},
		Deadline: 14,
		Description: faker.lorem.paragraph(),
		Status: 1,
		id: '',
		OwnerId: ''
	} as IInterviewTask);

	await db.tasks.save(task);
	newPipeline.Tasks.push(task);

	task = new Task();
	task.fill({
		Name: faker.hacker.noun(),
		TaskType: 'Todo',
		TodoList: [faker.hacker.noun(), faker.hacker.noun(), faker.hacker.noun()],
		Deadline: 20,
		Description: faker.lorem.paragraph()
	} as TodoTask);

	await db.tasks.save(task);
	newPipeline.Tasks.push(task);
	return newPipeline;
}

export async function generateRandomOpening() {
	const newOpening = new Opening();
	newOpening.Active = Math.random() > 0.7;
	newOpening.Position = faker.company.bs();
	newOpening.Description = faker.company.bs();
	newOpening.Location = await getRandomRefData('Cities');
	newOpening.OtherRequirements = [faker.company.catchPhrase(), faker.company.catchPhrase()];
	newOpening.RequiredExperience = [faker.company.catchPhrase(), faker.company.catchPhrase()];
	newOpening.RequiredEducation = [faker.company.catchPhrase(), faker.company.catchPhrase()];
	newOpening.AdditionalSkills = [faker.company.catchPhrase(), faker.company.catchPhrase()];
	newOpening.DesiredLanguages = ['Japanese'];
	newOpening.ExternalUrl = 'www.google.com';
	newOpening.Compensation = faker.random.number(80);
	newOpening.RequiredCandidates = faker.random.number(20);
	newOpening.JobType = await getRandomRefData('JobType');
	newOpening.Tags = await openingService.generateOpeningTags(newOpening);
	return newOpening;
}

async function generateRandomEducation() {
	return {
		School: `University of ${faker.hacker.noun()}`,
		Degree: `${faker.hacker.noun()} ${faker.hacker.noun()}`,
		Grade: ['A', 'B', 'C'][Math.floor(Math.random() * 3)],
		From: Date.now(),
		To: Date.now(),
		Location: await getRandomRefData('Countries'),
		IsCurrent: Math.random() > 0.7,
		Description: faker.lorem.paragraph(),
		FieldOfStudy: faker.hacker.noun()
	};
}

async function generateRandomExperience() {
	return {
		JobTitle: `${faker.hacker.noun()} Engineer`,
		Company: faker.company.companyName(),
		Location: faker.address.country(),
		From: Date.now(), // getRandomDate(false),
		To: Date.now(),
		IsCurrent: Math.random() > 0.7,
		Description: faker.lorem.paragraph(),
		Link: faker.internet.domainName()
	};
}

async function generateRandomSkill() {
	return {
		SkillName: faker.company.bsNoun(),
		Level: Math.floor(Math.random() * 10) + 1
	};
}

async function generateRandomLanguage() {
	return {
		Name: await getRandomRefData('Languages'),
		Level: await getRandomRefData('Level')
	};
}

async function generateRandomAward() {
	return {
		Title: `Master of ${faker.company.bsNoun()}`,
		Association: faker.company.companyName(),
		Issuer: faker.company.companyName(),
		From: Date.now(),
		Description: faker.lorem.paragraph()
	};
}

async function generateRandomResume(defaultBool) {
	const newResume = new Resume();
	newResume.CareerSummary = {
		Description: faker.lorem.paragraph()
	};
	newResume.Experience = [await generateRandomExperience(), await generateRandomExperience()];
	newResume.Education = [await generateRandomEducation(), await generateRandomEducation()];
	newResume.FeatureSkills = [await generateRandomSkill(), await generateRandomSkill()];
	newResume.Languages = [await generateRandomLanguage(), await generateRandomLanguage()];
	newResume.Awards = [await generateRandomAward(), await generateRandomAward()];
	newResume.Default = defaultBool;
	newResume.Name = faker.hacker.noun();
	newResume.JobTitle = `${faker.hacker.noun()} Engineer`;
	newResume.Tags = await resumeService.generateResumeTags(newResume);
	return newResume;
}

async function generateApplicationForCandidate(RecruiterId, Candidate : Account, ResumeId) {
	const jobs = await openingService.getOpeningsByRecruiterId(RecruiterId);
	const id = Math.floor(Math.random() * jobs.length);
	const selJob = jobs[id];
	return await applicationService.create({
		ResumeId: ResumeId
	}, { ...Candidate, id: Candidate.getFullKey() }, selJob.id);
}

async function seedRecruiter() {
	// create Motivo's recruiter account
	const newRecruiter = new Recruiter();
	await newRecruiter.fill({
		RecruiterName: 'Motivo'
	});

	await db.recruiters.save(newRecruiter);
	const newRecruiterCompany = new Company();
	await newRecruiterCompany.fill({
		CompanyName: 'Motivo'
	});
	newRecruiterCompany.RecruiterId = newRecruiter.getFullKey();

	await db.companies.save(newRecruiterCompany);
	return newRecruiter;
}

// function to seed to the database
export const seedTestSystem = async (numberOfRecruiters = 5, numberOfRecruiterUsers = 2, numberOfCompanies = 3,
	numberOfCompanyUsers = 2, numberOfOpeningsPerUser = 5, numberOfCandidates = 5,
	numberOfPipelines = 1, numberOfResumePerCandidate = 10) => {
	// const numberOfRecruiters = 5;
	// const numberOfRecruiterUsers = 2;
	// const numberOfCompanies = 3;
	// const numberOfCompanyUsers = 2;
	// const numberOfOpeningsPerUser = 3;
	// const numberOfCandidates = 5;
	// const numberOfPipelines = 1;
	// const numberOfResumePerCandidate = 10;
	// await db.flush();
	// await db.createPrimaryIndex();
	const mainRecruiter = await seedRecruiter();
	console.log('Seeded recruiter');
	for (let a = 0; a < numberOfRecruiters; a++) {
		const leadUser = a === 0 ? mainRecruiter : await generateRandomRecruiter();
		await db.companyUsers.save(leadUser);
		for (let b = 0; b < numberOfRecruiterUsers; b++) {
			const recruiterUser = await generateRandomRecruiterUser(true);
			recruiterUser.RecruiterId = leadUser.getFullKey();
			await db.recruiterUsers.save(recruiterUser);
		}
		for (let c = 0; c < numberOfCompanies; c++) {
			const company = await generateRandomCompany();
			company.RecruiterId = leadUser.getFullKey();
			const companyLeadUser = await generateRandomCompanyUser(true);
			companyLeadUser.CompanyId = company.getFullKey();
			await db.companies.save(company);
			await db.companyUsers.save(companyLeadUser);
			for (let d = 0; d < numberOfCompanyUsers; d++) {
				const companyUser = await generateRandomCompanyUser(false);
				companyUser.CompanyId = company.getFullKey();
				await db.companyUsers.save(companyUser);
				for (let e = 0; e < numberOfOpeningsPerUser; e++) {
					const opening = await generateRandomOpening();
					opening.CompanyId = company.getFullKey();
					opening.UserId = companyUser.getFullKey();
					await db.openings.save(opening);
				}
				for (let h = 0; h < numberOfPipelines; h++) {
					const pipeline = await generateRandomPipeline();
					await pipelineService.create(pipeline, company.getFullKey(), companyUser.getFullKey());
				}
			}
		}
		console.log('Seeded candidate info for recruiter', a);
		for (let f = 0; f < numberOfCandidates; f++) {
			const candidateUser = await generateRandomUser();
			const relationModel = new Account();
			relationModel.fill({
				RecruiterId: leadUser.getFullKey(),
				AccountEntityId: candidateUser.getFullKey(),
				CandidateCode: 'TEST1',
				Active: true
			});
			await db.accounts.save(relationModel);
			await db.candidates.save(candidateUser);
			const relationModel2 = new Account();
			relationModel2.fill({
				RecruiterId: mainRecruiter.getFullKey(),
				AccountEntityId: candidateUser.getFullKey(),
				CandidateCode: 'TEST2',
				Active: false
			});
			await db.accounts.save(relationModel);

			const numberOfEventsPerCandidate = 10;

			for (let n = 0; n < numberOfEventsPerCandidate; n++) {
				const event = await generateRandomEvent();
				event.UserId = (Math.random() > 0.5 ? relationModel.getFullKey() : relationModel2.getFullKey());
				await db.events.save(event);
			}

			const resumes = [];
			for (let m = 0; m < numberOfResumePerCandidate; m++) {
				const resume = await generateRandomResume(m % 5 === 0);
				resume.UserId = (m < 5 ? relationModel.getFullKey() : relationModel2.getFullKey());
				await db.resumes.save(resume);
				resumes.push(resume.getFullKey());
			}
			const numberOfApplicationPerCandidate = Math.ceil(numberOfCompanies * numberOfCompanyUsers * numberOfOpeningsPerUser / 4);
			console.log('Candidate ', f, ' has ', numberOfApplicationPerCandidate, ' applications');
			for (let g = 0; g < numberOfApplicationPerCandidate; g++) {
				await generateApplicationForCandidate(leadUser.getFullKey(), (Math.random() > 0.5 ? relationModel : relationModel2), resumes[Math.floor(Math.random() * resumes.length)]);
			}
		}
		console.log('Candidate info finished');
		const allApplications = (await applicationService.getApplicationsByRecruiterId(leadUser.getFullKey(), false)) as Application[];
		for (let j = 0; j < allApplications.length; j++) {
			if (Math.random() > 0.2) {
				const pipelines = await pipelineService.getPipelinesByCompanyId(allApplications[j].Relations.Opening.CompanyId);
				const pipeline = pipelines[Math.floor(Math.random() * pipelines.length)];
				await applicationService.acceptApplication(allApplications[j].getFullKey(), allApplications[j].Relations.Opening.CompanyId, allApplications[j].CandidateId, pipeline.getKey());
				if (Math.random() > 0.5) {
					// await applicationService.updateTodoTasks(allApplications[j].getFullKey(), 0, allApplications[j].CandidateId, [{ Id: '0', Done: true }, { Id: '1', Done: true }, { Id: '2', Done: true }]);
					// if (Math.random() > 0.5) {
					// 	await applicationService.giveOfferForApplication(allApplications[j].getFullKey(), allApplications[j].Relations.Opening.CompanyId, allApplications[j].CandidateId);
					// }
				}
			} else if (Math.random() > 0.4) {
				await applicationService.rejectApplication(allApplications[j].getFullKey(), allApplications[j].Relations.Opening.CompanyId, allApplications[j].CandidateId, `We need someone with ${faker.hacker.noun()} skills.`);
			}
		}
		const allJobs = await openingService.getOpeningsByRecruiterId(leadUser.getFullKey());
		const allCandidates = await candidateService.searchCandidatesByRecruiterId(leadUser.getFullKey());
		for (let l = 0; l < allJobs.length; l++) {
			const selCand = allCandidates[Math.floor(Math.random() * allCandidates.length)];
			await recruiterService.addRecommendationByCandidateId(selCand.CandidateId, leadUser.getFullKey(), allJobs[l].id);
		}
	}
	console.log('COMPLETED');
};

// clear the database, used by the tests to ensure the same result every time
export const clearAll = async () => {
	await clearUsers();
	await clearResumes();
	await clearEvents();
	await clearRecruiters();
	await clearOpenings();
	await clearCompanyUsers();
};

// the seed all function used upon a new dev environment
export const seedAll = async () => {
	await clearAll();
	await seedRecruiter();
};
export const seedAllForTests = async () => {
	await clearAll();
	await seedRecruiter();
};

const TestData = {};

async function toCall(type, refData) {
	let data = {} as any;
	if (TestData.hasOwnProperty(type)) {
		return Object.assign({}, TestData[type]);
	}
	switch (type) {
		case 'resume':
			data = await generateRandomResume(false);
			data = {
				Name: data.Name,
				CareerSummary: data.CareerSummary,
				Experience: data.Experience,
				Education: data.Education,
				FeatureSkills: data.FeatureSkills,
				Languages: data.Languages,
				Awards: data.Awards
			};
			data.FeatureSkills = data.FeatureSkills.reduce((total, object) => {
				total[object.SkillName] = object.Level;
				return total;
			}, {});
			data.Languages = data.Languages.reduce((total, object) => {
				total[object.Name] = object.Level;
				return total;
			}, {});
			break;
		case 'invite':
			data = {
				FirstName: 'John Done',
				EmailAddress: (await toCall('PersonalInformation', refData)).EmailAddress
			};
			break;
		case 'event':
			data = await generateRandomEvent();
			data = {
				Title: data.Title,
				Body: data.Body,
				Users: data.Users,
				Availability: data.Availability,
				Location: data.Location,
				StartTime: data.StartTime,
				EndTime: data.EndTime,
				Repeat: data.Repeat
			};
			break;
		case 'Register':
			data = {
				PersonalInformation: await toCall('PersonalInformation', refData),
				Account: await toCall('Account', refData)
			};
			break;
		case 'Account':
			data = {
				FirstName: 'John',
				LastName: 'Doe',
				EmailAddress: 'kieran@rooking.co.jp',
				DateOfBirth: '1978-05-04',
				Gender: 'Male',
				Nationality: 'United States',
				PhoneNumber: ['81 90 6178 2405'],
				ProfilePicture: '',
				CurrentLocation: 'Turks and Caicos Islands',
				JapaneseVisa: 'Yes'
			};
			break;
		case 'Profile':
			data = await toCall('Account', refData);
			data.EmailAddress = 'kieran@rooking.co.jp';
			break;
		case 'PersonalInformation':
			data = {
				EmailAddress: 'kieran@rooking.co.jp',
				Password: 'Ah$u43fGs6NY',
				ConfirmPassword: 'Ah$u43fGs6NY'
			};
			break;
		case 'Login':
			data = await toCall('PersonalInformation', refData);
			// delete data.ConfirmPassword;
			break;
		case 'reference':
			data = refData;
			break;
		case 'Openings':
			data = {
				common: {
					Position: 'Senior UI/UX Position',
					Description: 'This is a description about ...',
					Location: 'Shibuya, Tokyo',
					JobType: 'Permanant',
					RequiredExperience: ['PHP', 'MySQL'],
					AdditionalSkills: ['Basic linux server', 'AWS knowledge'],
					RequiredEducation: ['Bachelor"s'],
					OtherRequirements: ['JLPT N5', 'Fluent English'],
					Compensation: 30,
					Active: true,
					RequiredCandidates: 5
				},
				recommend: {
					CandidateId: 'Candidate/0552c202-76ce-4fb3-85f0-1bc6d5334d5e'
				}
			};
			break;
		default:
			data = {};
			break;
	}
	TestData[type] = data;
	return Object.assign({}, data);
}

// default user
var refData = null;
export const getData = async (typeVal) => {
	if (refData === null) {
		refData = await info.getNameValue(await info.getReferenceData());
	}
	return await toCall(typeVal, refData);
};
