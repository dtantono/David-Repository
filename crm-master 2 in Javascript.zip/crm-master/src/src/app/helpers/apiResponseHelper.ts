import {IPaginatedResponse} from "./paginate";

function response(payload, status, result, pagination : IPaginatedResponse) {
	if (result === 1) {
		return { result: result, status: status, error: [], data: payload, pagination: pagination };
	}
	return { result: result, status: status, error: payload, data: null, pagination: null };
}

export const apiError = (payload, status) =>
	// return { result: 2, status: status, error: message };
	 response(payload, status, 2, null);
;
export const apiResponse = (payload, status, pagination : IPaginatedResponse = null) =>
	// return { result: 1, status: status, payload: payload };
	 response(payload, status, 1, pagination)
;
