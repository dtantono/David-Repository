export const asyncForEach = async (array, func) => {
	for (let index = 0; index < array.length; index++) {
		await func(array[index], index, array);
	}
};

export const asyncReduce = async (object, func, total) => {
	await asyncForEach(Object.values(object), async (element) => {
		total = await func(total, element);
	});
	return total;
};

export const isEmpty = (obj) => {
	for(let key in obj) {
		if(obj.hasOwnProperty(key))
			return false;
	}
	return true;
};