import * as mcache from 'memory-cache';
import * as recruiterService from '../services/recruiters';
import * as companyService from '../services/companies';
const getCacheKey = (key : string) => key.includes('/') ? key.split('/')[1] : key;

export async function put(key: string, type: string, data: any) {
	const id = getCacheKey(key);
	let nowCache = mcache.get(id);
	if (nowCache) {
		nowCache[type] = data;
	} else {
		nowCache = {};
		nowCache[type] = data;
	}
	mcache.put(id, nowCache, 5 * 60 * 1000);
}

export async function get(key: string, type: string) {
	const id = getCacheKey(key);
	const nowCache = mcache.get(id);
	return nowCache ? nowCache[type] : null;
}


export async function remove(key: string, type: string) {
	const id = getCacheKey(key);
	const nowCache = mcache.get(id);
	if (nowCache) {
		if(Object.keys(nowCache).length > 0) {
			delete nowCache[type];
			mcache.put(id, nowCache, 5 * 60 * 1000);
		} else {
			mcache.del(id);
		}
	}
}
export async function removeAllRecruiterUsers(RecruiterId: string, type: string) {
	const users = await recruiterService.getRecruiterUsersByRecruiter(RecruiterId);
	users.forEach(user => remove(user.id, type))
}

export async function removeAllCompanyUsers(CompanyId: string, type: string) {
	const users = await companyService.getCompanyUsersByCompanyId(CompanyId);
	users.forEach(user => remove(user.id, type));
}

export const unCache = (...ids : string[]) => {
	if (ids && Array.isArray(ids)) {
		ids.forEach(id => remove(id, 'dashboard'));
	}
};

