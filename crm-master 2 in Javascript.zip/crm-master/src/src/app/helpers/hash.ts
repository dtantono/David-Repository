import * as crypto from 'crypto';

import config from '../../../config';

const hashExpiry = 30;

function hash(data) {
	const generator = crypto.createHash('sha256');
	generator.update(data);
	// @ts-ignore
	return generator.digest(<crypto.HexBase64Latin1Encoding>config.shaKey).toString('hex');
}

export const createRegistrationKey = (candidateId, email, registrationDate) => hash(candidateId + email + registrationDate + hashExpiry);

export const randomKey = (length: number) => crypto.randomBytes(length).toString('hex');

export const isRegistrationKeyValid = (key, userId, email, registrationDate) => {
	console.log('HASH', hash(userId + email + registrationDate + hashExpiry) === key);
	if (hash(userId + email + registrationDate + hashExpiry) === key) {
		const expiryDate = new Date(registrationDate);
		expiryDate.setTime(expiryDate.getTime() + (30 * 60 * 60 * 24 * 1000));
		console.log('EXPIRY', registrationDate);
		return (new Date()) < expiryDate;
	}
	return null;
}
;
