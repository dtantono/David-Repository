import * as awsService from "../services/aws";
import {BaseModel} from "../models/ModelRegister";

const sharp = require('sharp');
const width = 180;
const height = 180;

export const cropAndResizeImage = async (base64, cb) => {
	const imgBuffer = Buffer.from(base64, 'base64');
	return new Promise((resolve) => {
		sharp(imgBuffer).
			resize(null, height).
			resize(width, height).
			toBuffer().
			then(async (data) => resolve(await cb(data))). // data.toString('base64')
			catch((err) => console.log(`downsize issue ${err}`));
	});
};

export const uploadProfilePicture = async (Picture: string, model: BaseModel, key: string) => {
	if (Picture && Picture !== '') {
		try {
			await cropAndResizeImage(Picture, async (resizedData) => {
				const result = await awsService.upload(model.getFullKey(), resizedData);
				console.log(result);
				if (result) {
					model[key] = model.getFullKey();
				}
				console.log(model)
			});
		} catch (err) {
			console.log(err);
		}
	}
	return model;
};
