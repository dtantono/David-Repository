import nodemailer = require('nodemailer');
import config from '../../../config';
import * as localisation from '../services/localisation';

const transporter = nodemailer.createTransport({
	host: config.mail.host,
	port: config.mail.port,
	auth: {
		user: config.mail.user,
		pass: config.mail.password
	}
});

interface IMail {
	name: string,
	email: string
}

interface IRegistrationMail extends IMail {
	url: string,
	confirmLink: string
}

interface IInviteMail extends IMail {
	url: string
}

export const sendMail = (receivee, subject, body) => {
	if (process.env.NODE_ENV !== 'test') {
		const mailOptions = {
			from: config.mail.fromEmail,
			to: receivee,
			subject: subject,
			html: body
		};
		transporter.sendMail(mailOptions, (error) => {
			if (error) {
				console.log(error);
			}
		});
	}
};

export const sendTemplateMail = async (templateName: string, data: IMail, locale: string = 'en') => {
	const subject = await localisation.getMessage(locale, `${templateName}Subject`);
	const body = await localisation.getMessage(locale, `${templateName}Body`, data, false);
	sendMail(data.email, subject, body);
};

export const sendRegistrationMail = (locale, receiveeEmail, receiveeName, confirmationLink) => sendTemplateMail('RegistrationConfirmationEmail', { email: receiveeEmail, name: receiveeName, url: config.url, confirmLink: confirmationLink } as IRegistrationMail, locale);
export const sendResetPasswordMail = (locale, receiveeEmail, receiveeName, confirmationLink) => sendTemplateMail('ResetPasswordEmail', { email: receiveeEmail, name: receiveeName, url: config.candidateUrl, confirmLink: confirmationLink } as IRegistrationMail, locale);
export const sendRecruiterResetPasswordMail = (locale, receiveeEmail, receiveeName, confirmationLink) => sendTemplateMail('ResetPasswordEmail', { email: receiveeEmail, name: receiveeName, url: config.recruiterUrl, confirmLink: confirmationLink } as IRegistrationMail, locale);
export const sendCompanyResetPasswordMail = (locale, receiveeEmail, receiveeName, confirmationLink) => sendTemplateMail('ResetPasswordEmail', { email: receiveeEmail, name: receiveeName, url: config.companyUrl, confirmLink: confirmationLink } as IRegistrationMail, locale);
export const sendResetPasswordConfirmationMail = (locale, receiveeEmail, receiveeName) => sendTemplateMail('ConfirmResetPasswordEmail', { email: receiveeEmail, name: receiveeName } as IMail, locale);
export const sendInvitationMail = (locale, receiveeEmail, receiveeName, customMessage, url) => {
	if (customMessage === '') {
		sendTemplateMail('Invitation', {
			email: receiveeEmail,
			name: receiveeName,
			url: url
		}as IInviteMail, locale);
	} else {
		sendTemplateMail('InvitationWithCustom', {
			email: receiveeEmail,
			name: receiveeName,
			message: customMessage,
			url: url
		}as IInviteMail, locale);
	}
};
