
interface IPaginatableData {
	count: number
}

export const paginateResponse = (data : IPaginatableData, limit : number, pageNumber : number) : IPaginatedResponse => {
	const pageCount = Math.ceil(data.count / limit);
	return {
		pageCount: pageCount,
		currentPage: pageNumber,
		total: data.count,
		perPage: limit
	};
};
export const paginateInput = (pageNumber, resultLimit) : IPagination => ({ offset: (pageNumber - 1) * resultLimit, limit: resultLimit });

export interface IPagination {
	offset: number;
	limit: number;
}

export interface IPaginatedResponse {
	pageCount: number,
	currentPage: number,
	total: number,
	perPage: number
}