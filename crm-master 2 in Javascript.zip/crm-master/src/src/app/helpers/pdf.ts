const fs = require('fs');
const ejs = require('ejs');
const pdf = require('html-pdf');
const path = require('path');
const hummus = require('hummus');

const config = {
	header: {
		height: '20mm'
	},
	footer: {
		height: '20mm'
	}
};

export const createDocumentTaskPDF = async (task, file) => {
	const filename = 'test.pdf';
	return new Promise((resolve) => {
		const bitmap = new Buffer(file.replace('data:application/pdf;base64,', ''), 'base64');
		fs.writeFile(`${__dirname}/${filename}`, bitmap, () => {
			let pdfReader;
			let pdfWriter;
			try {
				pdfReader = hummus.createReader(`${__dirname}/${filename}`);
				pdfWriter = hummus.createWriterToModify(`${__dirname}/${filename}`, {
					modifiedFilePath: `${__dirname}/output.pdf`
				});
			} catch (e) {
				console.log(e);
				resolve(null);
				return;
			}
			const pages = task.Components.reduce((a, b) => (b.page > a.page ? b : a)).page;
			for (let page = 1; page <= pages; page++) {
				const size = pdfReader.parsePage(page - 1).getMediaBox();
				const pageModifier = new hummus.PDFPageModifier(pdfWriter, page - 1, true);
				const context = pageModifier.startContext().getContext();
				// eslint-disable-next-line no-loop-func
				const Components = task.Components.filter((comp) => comp.page === page);
				for (let comp = 0; comp < Components.length; comp++) {
					context.writeText(
						Components[comp].Value,
						Components[comp].pos.x, size[3] - Components[comp].pos.y - 10,
						{
							font: pdfWriter.getFontForFile(`${__dirname}/../assets/fonts/arial.ttf`),
							size: 12,
							colorspace: 'black',
							color: 0x00
						}
					);
				}

				pageModifier.endContext().writePage();
			}

			pdfWriter.end();
			resolve(fs.createReadStream(`${__dirname}/output.pdf`));
		});
	});
};
export const createResumeFromTemplate = (data) => new Promise((resolve) => {
	const fullPath = path.join(__dirname, `/pdf_templates/template.html`);
	const compiled = ejs.compile(fs.readFileSync(fullPath, 'utf8'));
	const html = compiled(data);
	pdf.create(html, config).toStream((err, pdfStream) => {
		if (err) {
			console.log(err);
			return resolve(null);
		}

		return resolve(pdfStream);
	});
});
export const createMessagePreviewFromTemplate = (data) => new Promise((resolve) => {
	const fullPath = path.join(__dirname, `/pdf_templates/messages.html`);
	const compiled = ejs.compile(fs.readFileSync(fullPath, 'utf8'));
	const html = compiled(data);
	return resolve(html);
});
export const createMessagesExportFromTemplate = async (data) => new Promise(async (resolve) => {
	const html = await createMessagePreviewFromTemplate(data);
	pdf.create(html, config).toStream((err, pdfStream) => {
		if (err) {
			console.log(err);
			return resolve(null);
		}

		return resolve(pdfStream);
	});
});
export const createResumePreviewFromTemplate = (data) => new Promise((resolve) => {
	const fullPath = path.join(__dirname, `/pdf_templates/template.html`);
	const compiled = ejs.compile(fs.readFileSync(fullPath, 'utf8'));
	const html = compiled(data);
	return resolve(html);
});
