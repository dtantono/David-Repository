import * as applicationValidator from './applicationValidatorHelper';
import * as candidateValidation from './candidateValidationHelper';
import * as sharedValidation from './sharedValidationHelper';
import * as companyValidator from './companyValidationHelper';
import * as eventValidator from './eventValidationHelper';
import * as openingValidator from './openingValidationHelper';
import * as pipelineValidator from './pipelineValidationHelper';
import * as recruiterValidator from './recruiterValidationHelper';
import * as resumeValidator from './resumeValidationHelper';
import * as chatRoomValidator from './chatroomValidationHelper';
import { getMessage } from '../../services/localisation';
import {ValidationError, Validator} from 'jsonschema';
import * as info from '../../services/info';
import {IContext} from "../../models/GlobalClasses";
import {asyncReduce} from "../arrayHelpers";
let refData : any = {};
info.getArray().then((data) => {
	refData = data;
});

const jv = new Validator();

let allSchemas : any = {};
allSchemas = { ...allSchemas, ...applicationValidator };
allSchemas = { ...allSchemas, ...candidateValidation };
allSchemas = { ...allSchemas, ...sharedValidation };
allSchemas = { ...allSchemas, ...eventValidator };
allSchemas = { ...allSchemas, ...companyValidator };
allSchemas = { ...allSchemas, ...openingValidator };
allSchemas = { ...allSchemas, ...pipelineValidator };
allSchemas = { ...allSchemas, ...recruiterValidator };
allSchemas = { ...allSchemas, ...resumeValidator };
allSchemas = { ...allSchemas, ...chatRoomValidator };

const customValidation = async (json, locale) => {
	const customErrors : ValidationError[] = [];
	const  addError = async (field: string, messageId: string, replaceVal: string) => customErrors.push({
			property: field,
			message: await getMessage(locale, messageId, replaceVal),
			instance: '',
			name: field,
			argument: '',
			schema: {}
	});
	if ('ConfirmPassword' in json && 'Password' in json && json.ConfirmPassword !== json.Password) {
		await addError('ConfirmPassword', 'match', 'ConfirmPassword');
	}
	if ('From' in json && 'To' in json && json.From > json.To) {
		await addError('To', 'greater', 'From');
	}
	if('DateOfBirth' in json && (new Date(json.DateOfBirth)).getTime() > Date.now()) {
		await addError('DateOfBirth', 'greater', 'now');
	}
	if ('StartTime' in json && 'EndTime' in json && json.StartTime > json.EndTime) {
		await addError('StartTime', 'greater', 'EndTime');
	}
	return customErrors as ValidationError[];
};

export interface IRequest {
	request: {
		body: any;
		user: {
			Locale: string;
		};
	}
}

export const validate = async (ctx : IContext | IRequest, schema) => {
	const json = ctx.request.body;
	const locale = ctx.request.user.Locale || 'en';
	const validateStatus = jv.validate(json, allSchemas[schema](refData));
	const customErrors = await customValidation(json, locale);
	const results = await asyncReduce([...customErrors, ...validateStatus.errors], async (total, error) => {
		if (error.property === 'instance') {
			error.property += `.${error.argument}`;
			error.name = 'required';
		}
		if (error.name === 'minLength' && error.argument === 1) {
			error.name = 'required';
		}
		if(error.property) {
			const property = error.property.split('.').pop();
			const propertyName = await getMessage(locale, property);
			total[property] = await getMessage(locale, error.name, {name: propertyName, arg: error.argument});
		}
		return total;
	}, {});
	return Object.keys(results).length ? results : null;
};

