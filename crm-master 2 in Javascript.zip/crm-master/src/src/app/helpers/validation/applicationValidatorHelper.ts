// -------------------
// Application VALIDATION
// -------------------

// CREATE SCHEMA
export const createApplicationSchema = () => ({
	id: '/ApplicationRegistration',
	required: ['ResumeId'],
	type: 'object',
	properties: {
		ResumeId: { type: 'string', minLength: 1 }
	}
});

// export const createApplicationTaskSchema = () => ({
// 	id: '/ApplicationTaskRegistration',
// 	required: ['Name', 'Type'],
// 	type: 'object',
// 	properties: {
// 		Name: { type: 'string', minLength: 1, maxLength: 50 },
// 		Type: { type: 'string', minLength: 1, maxLength: 50 }
// 	}
// });

export const acceptApplicationSchema = () => ({
	id: '/acceptApplicationRegistration',
	required: ['PipelineId'],
	type: 'object',
	properties: {
		PipelineId: { type: 'string', minLength: 1 }
	}
});

export const rejectApplicationSchema = () => ({
	id: '/rejectApplicationRegistration',
	required: ['RejectionReason'],
	type: 'object',
	properties: {
		RejectionReason: { type: 'string' }
	}
});
const fileSchema = {
	type: 'array',
	items: {
		type: 'object',
		required: ['Name', 'Contents'],
		properties: {
			Name: { type: 'string' },
			Contents: { type: 'string' }
		}
	}
};
export const updateTaskSchema = () => ({
	type: 'object',
	properties: {
		required: ['TodoList'],
		Files: fileSchema,
		TodoList: {
			type: 'array',
			items: {
				type: 'object',
				required: ['Done', 'Id'],
				properties: {
					Id: { type: 'number' },
					Done: { type: 'boolean' }
				}
			}
		}
	}
});
export const addTaskCommentSchema = () => ({
	type: 'object',
	properties: {
		Message: {type: 'string'}
	}
});

export const updateDocumentSchema = () => ({
	type: 'object',
	properties: {
		Files: fileSchema,
		Components: {
			type: 'array',
			items: {
				type: 'object',
				required: ['Value', 'Id'],
				properties: {
					Id: { type: 'string' },
					Value: {
						type: ['string', 'boolean']
					}
				}
			}
		}
	}
});
export const reorderTasksSchema = () => ({
	type: 'object',
	properties: {
		CandidatePipeline: {
			type: 'array',
			items: {
				type: 'object',
				required: ['Id', 'Status'],
				properties: {
					Id: { type: 'string' },
					Status: { type: 'string' }
				}
			}
		}
	}
});

