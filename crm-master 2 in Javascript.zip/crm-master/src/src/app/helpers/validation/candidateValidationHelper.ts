// -------------------
// CANDIDATE VALIDATION
// -------------------

export const candidateUpdateProfileSchema = (data) => ({
	id: '/CandidateUpdateProfile',
	type: 'object',
	required: ['FirstName', 'LastName', 'EmailAddress', 'DateOfBirth', 'Gender', 'Nationality', 'PhoneNumber', 'CurrentLocation', 'JapaneseVisa'],
	properties: {
		FirstName: { type: 'string', minLength: 1, maxLength: 50 },
		LastName: { type: 'string', minLength: 1, maxLength: 50 },
		EmailAddress: { type: 'string', format: 'email' },
		DateOfBirth: { type: 'string', minLength: 1, format: 'date' },
		Gender: { type: 'string', enum: data.Gender },
		Nationality: { type: 'string', enum: data.Countries },
		PhoneNumber: { type: 'string', minLength: 1, maxLength: 20 },
		ProfilePicture: { type: 'string' },
		CurrentLocation: { type: 'string', enum: data.Countries },
		JapaneseVisa: { type: 'string', enum: ['Yes', 'No'] }
	}
});

export const candidatePersonalInformationSchema = () => ({
	id: '/PersonalInformation',
	type: 'object',
	required: ['EmailAddress', 'Password', 'ConfirmPassword'],
	properties: {
		EmailAddress: { type: 'string', format: 'email' },
		Password: { type: 'string', minLength: 8, maxLength: 50 },
		ConfirmPassword: {
			type: 'string'
		}
	}
});

export const candidateCreateAccountSchema = (data) => ({
	id: '/CreateAccount',
	type: 'object',
	required: ['FirstName', 'LastName', 'EmailAddress', 'DateOfBirth', 'Gender', 'Nationality', 'PhoneNumber', 'CurrentLocation', 'JapaneseVisa'],
	properties: {
		FirstName: { type: 'string', minLength: 1, maxLength: 50 },
		LastName: { type: 'string', minLength: 1, maxLength: 50 },
		EmailAddress: { type: 'string', format: 'email' },
		DateOfBirth: { type: 'string', minLength: 1, format: 'date' },
		Gender: { type: 'string', enum: data.Gender },
		Nationality: { type: 'string', enum: data.Countries },
		PhoneNumber: { type: 'string', minLength: 1, maxLength: 20 },
		ProfilePicture: { type: 'string' },
		CurrentLocation: { type: 'string', enum: data.Countries },
		JapaneseVisa: { type: 'string', enum: ['Yes', 'No'] }
	}
});

export const candidateRegistrationSchema = (data) => ({
	id: '/CandidateRegistration',
	type: 'object',
	required: ['PersonalInformation', 'Account'],
	properties: {
		UserId: { type: 'string' },
		PersonalInformation: candidatePersonalInformationSchema(),
		Account: candidateCreateAccountSchema(data)
	}
});
export const candidateRegistrationThirdPartySchema = (data) => ({
	id: '/CandidateRegistration',
	type: 'object',
	required: ['Account'],
	properties: {
		UserId: { type: 'string' },
		Account: candidateCreateAccountSchema(data)
	}
});