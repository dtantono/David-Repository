// -------------------
// PIPELINE VALIDATION
// -------------------

// CREATE SCHEMA
export const createChatRoomSchema = () => ({
	required: ['Message', 'Subject', 'Users'],
	type: 'object',
	properties: {
		Message: { type: 'string' },
		Subject: { type: 'string', minLength: 1, maxLength: 150 },
		Users: {
			type: 'array',
			items: {
				type: 'string'
			}
		},
		GroupName: { type: 'string' },
		Color: { type: 'string' },
		Template: { type: 'boolean' }
	}
});
