// -------------------
// COMPANY VALIDATION
// -------------------

import {
	recruiterRegisterCompanyAdditionalSchema,
	recruiterRegisterCompanySchema, recruiterRegisterPersonalSchema,
	recruiterRegisterSignupSchema
} from "./recruiterValidationHelper";
import {MasterData} from "../../db/referencedata";

export const personalInfoSchema = (data) => ({
	id: '/PersonalInfo',
	type: 'object',
	required: ['FirstName', 'LastName', 'EmailAddress', 'DateOfBirth', 'Gender', 'Nationality', 'PhoneNumber', 'CurrentLocation'],
	properties: {
		FirstName: { type: 'string', minLength: 1, maxLength: 50 },
		LastName: { type: 'string', minLength: 1, maxLength: 50 },
		EmailAddress: { type: 'string', format: 'email' },
		DateOfBirth: { type: 'string', minLength: 1, format: 'date' },
		Gender: { type: 'string', enum: data.Gender },
		Nationality: { type: 'string', enum: data.Countries },
		PhoneNumber: {
			type: 'array',
			items: {
				type: 'string', maxLength: 20
			}
		},
		ProfilePicture: { type: 'string' },
		CurrentLocation: { type: 'string', enum: data.Countries }
	}
});

export const companyInfoSchema = () => ({
	id: '/CompanyInfo',
	type: 'object',
	required: ['CompanyName'],
	properties: {
		CompanyName: { type: 'string', minLength: 1, maxLength: 50 }
	}
});

export const companyRegisterCompanySchema = () => ({
	type: 'object',
	required: ['CompanyName', 'EmployeeCount', 'Website'],
	properties: {
		CompanyName: {type: 'string', minLength: 1, maxLength: 50},
		EmployeeCount: {type: 'number'},
		Website: {type: 'string', minLength: 1, maxLength: 100}
	}
});

export const companyRegisterCompanyAdditionalSchema = (data : MasterData) => ({
	type: 'object',
	required: ['AddressOne', 'AddressTwo', 'Country', 'PhoneNumber', 'State', 'Postcode'],
	properties: {
		AddressOne: {type: 'string', maxLength: 100},
		AddressTwo: {type: 'string', maxLength: 100},
		Country: {type: 'string', enum: data.Countries},
		State: {type: 'string', enum: data.Cities},
		PhoneNumber: {
			type: 'string', maxLength: 20
		},
		Picture: {type: 'string'},
		Postcode: {type: 'string', maxLength: 10},
	}
});

export const companyRegistrationSchema = (data) => ({
	id: '/CompanyRegister',
	type: 'object',
	required: ['Signup', 'Company', 'CompanyAdditional', 'Personal'],
	properties: {
		Signup: recruiterRegisterSignupSchema(),
		Company: companyRegisterCompanySchema(),
		CompanyAdditional: companyRegisterCompanyAdditionalSchema(data),
		Personal: recruiterRegisterPersonalSchema(data)
	}
});

export const companyUserRegistrationSchema = (data) => ({
	id: '/CompanyUserRegister',
	type: 'object',
	required: ['Signup', 'Personal'],
	properties: {
		Signup: recruiterRegisterSignupSchema(),
		Personal: recruiterRegisterPersonalSchema(data)
	}
});

export const companyUpdateProfileSchema = (data: MasterData) => ({
	type: 'object',
	required: ['AddressOne', 'AddressTwo', 'Country', 'PhoneNumber', 'State', 'Postcode', 'CompanyName'],
	properties: {
		AddressOne: {type: 'string'},
		AddressTwo: {type: 'string'},
		Country: {type: 'string', enum: data.Countries},
		State: {type: 'string', enum: data.Cities},
		PhoneNumber: {
			type: 'string'
		},
		Picture: {type: 'string'},
		Postcode: {type: 'string'},
		CompanyName: {type: 'string', minLength: 1},
	}
});
