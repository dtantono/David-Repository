// -------------------
// EVENT VALIDATION
// -------------------

// REGISTRATION SCHEMA
export const eventRegistrationSchema = (data) => ({
	id: '/EventRegistration',
	required: ['Title', 'Body', 'Users', 'Repeat', 'Availability', 'Location', 'StartTime', 'EndTime'],
	type: 'object',
	properties: {
		Title: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Body: {
			type: 'string'
		},
		Users: {
			type: 'array',
			items: {
				type: 'string'
			}
		},
		Availability: {
			type: 'string',
			enum: data.AvailabilityType
		},
		Repeat: {
			type: 'string'
		},
		Location: {
			type: 'string', minLength: 1, maxLength: 100
		},
		StartTime: {
			type: 'number', minimum: 10000
		},
		EndTime: {
			type: 'number', minimum: 10000
		}
	}
});
