// -------------------
// RESUME VALIDATION
// -------------------

// CREATE SCHEMA
import { MasterData } from '../../db/referencedata';

export const createOpeningSchema = (data : MasterData) => ({
	id: '/OpeningRegistration',
	required: ['Position', 'Description', 'Location', 'JobType', 'RequiredExperience', 'RequiredEducation',
		'AdditionalSkills', 'RequiredEducation', 'OtherRequirements', 'Compensation', 'RequiredCandidates',
		'Active'],
	type: 'object',
	properties: {
		Position: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Description: {
			type: 'string', maxLength: 2000
		},
		Location: {
			type: 'string', enum: data.Cities
		},
		JobType: {
			type: 'string', enum: data.JobType
		},
		RequiredExperience: {
			type: 'array',
			items: {
				type: 'string', maxLength: 50
			}
		},
		AdditionalSkills: {
			type: 'array',
			items: {
				type: 'string'
			}
		},
		RequiredEducation: {
			type: 'array',
			items: {
				type: 'string', maxLength: 50
			}
		},
		OtherRequirements: {
			type: 'array',
			items: {
				type: 'string', maxLength: 1000
			}
		},
		Compensation: {
			type: 'number'
		},
		RequiredCandidates: {
			type: 'number', minimum: 0
		},
		Active: {
			type: 'boolean'
		}
	}
});

export const recommendToCandidateSchema = () => ({
	type: 'object',
	required: ['CandidateId'],
	properties: {
		CandidateId: { type: 'string', minLength: 1}
	}
});