// -------------------
// PIPELINE VALIDATION
// -------------------

// CREATE SCHEMA
import { MasterData } from '../../db/referencedata';

export const createPipelineSchema = (data: MasterData) => ({
	id: '/PipelineRegistration',
	required: ['Title', 'Tasks'],
	type: 'object',
	properties: {
		Title: {
			type: 'string', minLength: 1, maxLength: 100
		},
		Tasks: {
			type: 'array',
			items: {
				type: 'object',
				required: ['id', 'TaskType'],
				properties: {
					id: {
						type: 'string', minLength: 1
					},
					TaskType: { type: 'string', minLength: 1 }
				}
			}
		}
	}
});

export const createTodoTask = () => ({
	type: 'object',
	required: ['Name', 'Description', 'TodoList'],
	properties: {
		Name: {type: 'string', minLength: 1, maxLength: 100 },
		Description: {type: 'string' },
		TodoList: {
			type: 'array',
			item: {
				type: 'string'
			}
		},
	}
});

export const createInterviewTask = () => ({
	type: 'object',
	required: ['Name', 'Description', 'Date', 'Duration', 'Location'],
	properties: {
		Name: {type: 'string', minLength: 1 },
		Description: {type: 'string' },
		Location: { type: 'string', minLength: 1 },
		Date: { type: 'number', minimum: 10000 },
		Duration: { type: 'number', minimum: 0, maximum: 10 },
	}
});

export const createDocumentTask = () => ({
	type: 'object',
	required: ['Name', 'Description', 'Components', 'File'],
	properties: {
		Name: { type: 'string', minLength: 1 },
		Description: {type: 'string' },
		Components: {
			type: 'array',
			item: {
				type: 'object',
				required: ['page', 'pos', 'type'],
				properties: {
					page: { type: 'number' },
					pos: {
						type: 'object',
						required: ['x', 'y'],
						properties: {
							x: { type: 'number' },
							y: { type: 'number' },
						}
					},
					type: {
						type: 'object',
						required: ['FieldType', 'Label'],
						properties: {
							FieldType: { type: 'string' },
							Label: { type: 'string' },
						}
					},
				}
			}
		},
	}
});