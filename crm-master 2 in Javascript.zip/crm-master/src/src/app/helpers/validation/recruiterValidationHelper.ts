import { MasterData } from '../../db/referencedata';

// -------------------
// RECRUITER VALIDATION
// -------------------

export const recruiterRegisterSignupSchema = () => ({
	type: 'object',
	required: ['FirstName', 'LastName', 'EmailAddress', 'Password', 'ConfirmPassword'],
	properties: {
		FirstName: { type: 'string', minLength: 1, maxLength: 50 },
		LastName: { type: 'string', minLength: 1, maxLength: 50 },
		EmailAddress: { type: 'string', format: 'email' },
		Password: { type: 'string', minLength: 8, maxLength: 15 },
		ConfirmPassword: {
			type: 'string', minLength: 8, maxLength: 15
		}
	}
});
export const recruiterRegisterCompanySchema = () => ({
	type: 'object',
	required: ['RecruiterName', 'EmployeeCount', 'Website'],
	properties: {
		RecruiterName: { type: 'string', minLength: 1, maxLength: 50 },
		EmployeeCount: { type: 'number' },
		Website: { type: 'string', minLength: 1, maxLength: 100 }
	}
});
export const recruiterRegisterPersonalSchema = (data : MasterData) => ({
	type: 'object',
	required: ['Gender', 'DateOfBirth', 'PhoneNumber'],
	properties: {
		Gender: { type: 'string', enum: data.Gender },
		DateOfBirth:{ type: 'string', minLength: 1, format: 'date' },
		PhoneNumber: { type: 'string', minLength: 1, maxLength: 20 },
		ProfilePicture: { type: 'string' }
	}
});

export const recruiterRegisterCompanyAdditionalSchema = (data : MasterData) => ({
	type: 'object',
	required: ['AddressOne', 'AddressTwo', 'Country', 'RecruiterId', 'PhoneNumber', 'State', 'Postcode'],
	properties: {
		AddressOne: { type: 'string', maxLength: 100 },
		AddressTwo: { type: 'string', maxLength: 100 },
		Country: { type: 'string', enum: data.Countries },
		State: { type: 'string', enum: data.Cities },
		RecruiterId: { type: 'string' },
		PhoneNumber: {
			type: 'string', maxLength: 20
		},
		Picture: { type: 'string' },
		Postcode: { type: 'string', maxLength: 10 }
	}
});

export const recruiterRegistrationSchema = (data : MasterData) => ({
	Signup: recruiterRegisterSignupSchema(),
	Company: recruiterRegisterCompanySchema(),
	CompanyAdditional: recruiterRegisterCompanyAdditionalSchema(data),
	Personal: recruiterRegisterPersonalSchema(data)
});

export const recruiterUserRegistrationSchema = (data : MasterData) => ({
	Signup: recruiterRegisterSignupSchema(),
	Personal: recruiterRegisterPersonalSchema(data)
});

export const recruiterCreateTeamSchema = () => ({
	type: 'object',
	required: ['Name', 'Members'],
	properties: {
		Name: { type: 'string', minLength: 1, maxLength: 50 },
		Members: { type: 'array', items: {
			type: 'string'
		}}
	}
});

export const recruiterUserUpdateTeamSchema = () => ({
	type: 'object',
	required: ['Teams'],
	properties: {
		Teams: {
			type: 'array',
			items: {
				type: 'string'
			}
		}
	}
});

export const recruiterUpdateProfileSchema = (data: MasterData) => ({
	type: 'object',
	required: ['AddressOne', 'AddressTwo', 'Country', 'RecruiterId', 'PhoneNumber', 'State', 'Postcode', 'RecruiterName'],
	properties: {
		AddressOne: { type: 'string', maxLength: 100 },
		AddressTwo: { type: 'string', maxLength: 100 },
		Country: { type: 'string', enum: data.Countries },
		State: { type: 'string', enum: data.Cities },
		RecruiterId: { type: 'string', minLength: 1 },
		PhoneNumber: {
			type: 'string', maxLength: 20
		},
		Picture: { type: 'string' },
		Postcode: { type: 'string' },
		RecruiterName: { type: 'string', minLength: 1, maxLength: 50 }
	}
});

export const recruiterUserUpdateProfileSchema = (data: MasterData) => ({
	type: 'object',
	required: ['EmailAddress', 'FirstName', 'LastName', 'DateOfBirth', 'EmailAddress', 'Nationality', 'PhoneNumber', 'CurrentLocation'],
	properties: {
		FirstName: {
			type: 'string', minLength: 1, maxLength: 50
		},
		LastName: {
			type: 'string', minLength: 1, maxLength: 50
		},
		DateOfBirth: {
			type: 'string', minLength: 1, format: 'date'
		},
		EmailAddress: {
			type: 'string', format: 'email'
		},
		Gender: {
			type: 'string', enum: data.Gender
		},
		Nationality: {
			type: 'string', enum: data.Countries
		},
		PhoneNumber: {
			type: 'string', maxLength: 20
		},
		ProfilePicture: {
			type: 'string'
		},
		CurrentLocation: {
			type: 'string', enum: data.Countries
		},
	}
});

// INVITE SCHEMA
export const recruiterInviteSchema = () => ({
	id: '/recruiter/invite',
	type: 'object',
	required: ['EmailAddress', 'FirstName'],
	properties: {
		EmailAddress: { type: 'string', format: 'email' },
		FirstName: { type: 'string', minLength: 1, maxLength: 50 }
	}
});
