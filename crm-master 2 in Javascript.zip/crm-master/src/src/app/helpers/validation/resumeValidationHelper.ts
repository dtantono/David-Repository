// -------------------
// RESUME VALIDATION
// -------------------

import { MasterData } from '../../db/referencedata';

export const validateCareerSummarySchema = () => ({
	id: '/ValidateCareerSummary',
	type: 'object',
	properties: {
		Description: {
			type: 'string', maxLength: 2000
		}
	}
});
export const validateExperienceSchema = () => ({
	id: '/ValidateExperience',
	type: 'object',
	required: ['JobTitle', 'Company', 'Location', 'From', 'To', 'IsCurrent', 'Description'],
	properties: {
		JobTitle: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Company: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Location: {
			type: 'string', minLength: 1, maxLength: 100
		},
		From: {
			type: 'number', minimum: 10000
		},
		To: {
			type: 'number', minimum: 10000
		},
		IsCurrent: {
			type: 'boolean'
		},
		Description: {
			type: 'string', maxLength: 2000
		},
		Link: {
			type: 'string'
		}
	}
});
export const validateEducationSchema = () => ({
	id: '/ValidateEducation',
	type: 'object',
	required: ['School', 'Degree', 'Grade', 'From', 'To', 'IsCurrent', 'Description', 'Location', 'FieldOfStudy'],
	properties: {
		School: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Degree: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Grade: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Location: {
			type: 'string', minLength: 1, maxLength: 100
		},
		From: {
			type: 'number', minimum: 10000
		},
		To: {
			type: 'number', minimum: 10000
		},
		IsCurrent: {
			type: 'boolean'
		},
		Description: {
			type: 'string', maxLength: 2000
		},
		FieldOfStudy: {
			type: 'string', minLength: 1
		}
	}
});
export const validateSkillsSchema = () => ({
	id: '/ValidateSkills',
	type: 'object'
});
export const validateLanguagesSchema = () => ({
	id: '/ValidateLanguages',
	type: 'object'
});
export const validateAwardSchema = () => ({
	id: '/ValidateAwards',
	type: 'object',
	required: ['Title', 'Association', 'Issuer', 'From', 'Description'],
	properties: {
		Title: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Association: {
			type: 'string', minLength: 1, maxLength: 50
		},
		Issuer: {
			type: 'string', minLength: 1, maxLength: 50
		},
		From: {
			type: 'number', minimum: 10000
		},
		Description: {
			type: 'string', maxLength: 2000
		}
	}
});

// CREATE SCHEMA
export const createResumeSchema = (data: MasterData) => ({
	id: '/CreateResume',
	required: ['CareerSummary', 'Experience', 'Education', 'FeatureSkills', 'Languages', 'Awards', 'Name'],
	type: 'object',
	properties: {
		CareerSummary: validateCareerSummarySchema(),
		Education: {
			type: 'array',
			items: validateEducationSchema()
		},
		Experience: {
			type: 'array',
			items: validateExperienceSchema()
		},
		FeatureSkills: validateSkillsSchema(),
		Languages: validateLanguagesSchema(),
		Awards: {
			type: 'array',
			items: validateAwardSchema()
		},
		Name: { type: 'string', minLength: 1, maxLength: 50 }
	}
});
