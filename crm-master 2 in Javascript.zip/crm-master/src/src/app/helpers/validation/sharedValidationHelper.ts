export const requestResetPasswordSchema = () => ({
	id: '/RequestResetPassword',
	type: 'object',
	required: ['EmailAddress'],
	properties: {
		EmailAddress: { type: 'string', format: 'email' }
	}
});
export const resetPasswordSchema = () => ({
	id: '/ResetPasswordSchema',
	type: 'object',
	required: ['Password', 'ConfirmPassword'],
	properties: {
		Password: { type: 'string', minLength: 8, maxLength: 15 },
		ConfirmPassword: {
			type: 'string'
		}
	}
});
export const changePasswordSchema = () => ({
	id: '/ChangePasswordSchema',
	type: 'object',
	required: ['Password', 'ConfirmPassword', 'CurrentPassword'],
	properties: {
		Password: { type: 'string', minLength: 8, maxLength: 50 },
		ConfirmPassword: {
			type: 'string'
		},
		CurrentPassword: { type: 'string', minLength: 1, maxLength: 15 }
	}
});
export const checkPasswordSchema = () => ({
	id: '/CheckPasswordSchema',
	type: 'object',
	required: ['CurrentPassword'],
	properties: {
		CurrentPassword: { type: 'string', minLength: 1, maxLength: 15 }
	}
});

export const loginSchema = () => ({
	type: 'object',
	required: ['EmailAddress', 'Password'],
	properties: {
		EmailAddress: { type: 'string', format: 'email' },
		Password: { type: 'string', minLength: 1, maxLength: 15 }
	}
});

export const updateProfilePicture = () => ({
	type: 'object',
	required: ['ProfilePicture'],
	properties: {
		ProfilePicture: { type: 'string', minLength: 1 }
	}
});
