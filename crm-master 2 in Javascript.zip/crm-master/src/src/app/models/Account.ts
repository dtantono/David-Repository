import { BaseModel } from './ModelRegister';

export interface AccountType {
	id: string;
	RecruiterId: string;
	AccountEntityId: string;
	Recommendations: Recommendation[];
	Notifications: any[];
	Active: boolean;
}

export class Account extends BaseModel implements AccountType {
	protected static table: string = 'Account';

	// Attributes
	public RecruiterId: string;
	public AccountEntityId: string;
	public Recommendations: Recommendation[];
	public Notifications: any[];
	public Active: boolean;
	public Locale: string;
	public CandidateCode: string;
	public InvitationKey: string;

	constructor() {
		super();
		this.type = 'Account';
		this.schema = {
			RecruiterId: {
				defaultValue: ''
			},
			AccountEntityId: {
				defaultValue: ''
			},
			CandidateCode: {
				defaultValue: ''
			},
			Recommendations: {
				defaultValue: []
			},
			Notifications: {
				defaultValue: []
			},
			Active: {
				defaultValue: false
			},
			Locale: {
				defaultValue: 'en'
			},
			InvitationKey: {
				defaultValue: null
			}
		};
	}
}

interface Recommendation {
	OpeningId: string,
	Active: boolean,
	CreatedAt: number
}
