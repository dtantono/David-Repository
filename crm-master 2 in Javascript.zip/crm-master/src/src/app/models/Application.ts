import { BaseModel } from './ModelRegister';
import {IApplicationTask, IApplicationTodoTask, PublicApplicationTask} from './Pipeline';
import applicationStatuses from '../db/ReferenceData/ApplicationStatus';
import taskStatuses from '../db/ReferenceData/TaskStatus';
import config from '../../../config';
import * as _ from 'lodash';
import * as cache from '../helpers/cache';
import * as db from '../db/database';
import * as notifications from "../services/notifications";

export interface IApplication {
	id: string;
	OpeningId: string;
	CandidateId: string;
	ResumeId: string;
	PipelineId: string;
	Status: number;
	CandidatePipeline: IApplicationTask[];
	RejectionReason: string;
	ActionDate: number;
	TaskOrder: object;
}

export class Application extends BaseModel implements IApplication {
	protected static table: string = 'Application';

	// Attributes
	public OpeningId: string;
	public CandidateId: string;
	public ResumeId: string;
	public PipelineId: string;
	public LastActionBy: string;
	public Status: number;
	public CandidatePipeline: IApplicationTask[];
	public RejectionReason: string;
	public ActionDate: number;
	public TaskOrder: object;
	public Offer: { Salary: any, RecruiterId: string };

	constructor() {
		super();
		this.type = 'Application';
		this.schema = {
			OpeningId: { defaultValue: '' },
			CandidateId: { defaultValue: '' },
			ResumeId: { defaultValue: '' },
			PipelineId: { defaultValue: '' },
			LastActionBy: { defaultValue: '' },
			Offer: { defaultValue: {} },
			Status: { defaultValue: 1 },
			CandidatePipeline: { defaultValue: [] },
			RejectionReason: { defaultValue: '' },
			ActionDate: { defaultValue: Date.now() },
			TaskOrder: { defaultValue: {} }
		};
	}

	all() {
		const data = super.all();
		return data;
	}

	async getOpening() {
		this.Relations = this.Relations ? this.Relations : {} as any;
		if(!('Opening' in this.Relations && 'Company' in this.Relations)) {
			this.Relations.Opening = await db.openings.with('Company').where('id', this.OpeningId).first();
			this.Relations.Company = this.Relations.Opening.Relations.Company;
		}
	}

	async update() {
		super.update();
		await this.getOpening();
		cache.remove(this.CandidateId, 'dashboard');
		cache.removeAllCompanyUsers(this.Relations.Opening.CompanyId, 'dashboard');
		cache.removeAllRecruiterUsers(this.Relations.Company.RecruiterId, 'dashboard');
		const addCandidateNotification = (title, message, fromUser = this.LastActionBy) => notifications.addNotification('Candidate', this.CandidateId, title, message, fromUser, `/kanban/${this.id}`);
		// const addCompanyNotifications = (title, message) => notifications.addNotificationsForCompanyUsers(this.Relations.Opening.CompanyId, title, message, this.CandidateId, `/kanban/${this.id}`);
		const addRecruiterNotifications = (title, message) => notifications.addNotificationsForRecruiterUsers(this.Relations.Company.RecruiterId, title, message, this.CandidateId, `/kanban/${this.id}`);
		if(this.Previous === null || this.Previous.Status !== this.Status) {
			switch(this.Status) {
				case 1:
					addCandidateNotification('Application received', 'has received your application', this.Relations.Opening.UserId);
					addRecruiterNotifications('New application',`has applied for ${this.Relations.Opening.Position}`);
					break;
				case 2:
					addCandidateNotification('Application accepted', 'has accepted your application');
					break;
				case 3:
					addCandidateNotification('Application declined', 'has declined your application');
					break;
				case 4:
					addCandidateNotification('Offer declined', 'has received your wish to decline');
					addRecruiterNotifications('Offer declined',`has declined your offer for ${this.Relations.Opening.Position}`);
					break;
				case 5:
					addCandidateNotification('Offer received', 'has sent you an offer');
					break;
				case 6:
					addCandidateNotification('Offer accepted', 'has received your wish to accept');
					addRecruiterNotifications('Offer accepted',`has accepted your offer for ${this.Relations.Opening.Position}`);
					break;
				default:
					break;
			}
		}
	}

	public(...excludeProperties: string[]) {
		const data = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		const mapTasks = (array, idArray = []) => {
			let currentId = 0;
			return array.map((x: PublicApplicationTask) => {
				x.Id = [...idArray, currentId].join('.');
				const status = taskStatuses[x.Status];
				x.Status = status ? status.name : x.Status;
				if (x.TaskType === 'Folder') {
					x.Tasks = mapTasks(x.Tasks, [...idArray, currentId]);
				}
				if (x.TaskType === 'Document') {
					x.File = config.s3.url + `Task/${x.id}`;
				}
				if (x.TaskType === 'Todo') {
					((x as any) as IApplicationTodoTask).Attachments.forEach(a => a.Path = config.s3.url + this.getFullKey() + '/' + x.Id + '/' + a.Name)
				}
				currentId++;
				return x;
			});
		};
		const status = applicationStatuses[this.Status.toString()];
		data.Status = status ? status.name : data.Status;
		data.CandidatePipeline = mapTasks(_.cloneDeep(this.CandidatePipeline));
		return data;
	}
}
