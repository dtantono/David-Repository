import { BaseModel } from './ModelRegister';
import config from "../../../config";
import {uploadProfilePicture} from "../helpers/imageTools";
import * as bcrypt from 'bcrypt';
import countries from '../db/ReferenceData/Countries';


export class User extends BaseModel implements IUser {
	public EmailAddress: string;
	public FirstName: string;
	public LastName: string;
	public Active: boolean;
	public HashPassword: string;
	public Nationality: string;
	public CurrentLocation: string;
	public ThirdPartyId: string;
	public ThirdPartyType: string;
	public ResetPasswordToken: string;
	public ProfilePicture: string;

	updatePassword(password: string) {
		this.HashPassword = password.length ? bcrypt.hashSync(password, 10) : this.HashPassword;
	}

	update() {
		super.update();
	}

	async updatePicture (input: string) {
		if(input && input !== '' && input !== this.getFullKey()) {
			this.ProfilePicture = this.getFullKey();
			return uploadProfilePicture(input, this, 'ProfilePicture');
		}
	}

	public(...excludeProperties: string[]) {
		const data : any = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		data.ProfilePicture = data.ProfilePicture === '' ? '' : config.s3.url + data.ProfilePicture;
		data.NationalityRaw = data.Nationality;
		data.Nationality = data.Nationality in countries ? countries[data.Nationality].name : '';
		data.CurrentLocationRaw = data.CurrentLocation;
		data.CurrentLocation = data.CurrentLocation in countries ? countries[data.CurrentLocation].name : '';
		return data;
	}
}

export interface IUser {
	updatePassword(password: string) :void;
	updatePicture(input: string) : Promise<BaseModel>;
}

interface Personality {
	CareerCategories: string[],
	Languages: object,
	PlayerType: string,
	Skills: object
}
export class Candidate extends User {
	protected static table: string = 'Candidate';

	// Attributes
	public FirstName: string;
	public LastName: string;
	public MatchScore: number;
	public DateOfBirth: string;
	public Gender: string;
	public Nationality: string;
	public PhoneNumber: string;
	public ProfilePicture: string;
	public CurrentLocation: string;
	public Title: string;
	public ResetPasswordToken: string;
	public JapaneseVisa: string;
	public Personality: Personality;
	public GithubHandle: string;
	public TwitterHandle: string;
	public FormData: object;

	constructor() {
		super();
		this.type = 'Candidate';
		this.schema = {
			FirstName: { defaultValue: '' },
			LastName: { defaultValue: '' },
			DateOfBirth: { defaultValue: '' },
			Gender: { defaultValue: '' },
			Nationality: { defaultValue: 'JP' },
			PhoneNumber: { defaultValue: '' },
			ProfilePicture: { defaultValue: '' },
			CurrentLocation: { defaultValue: 'JP' },
			EmailAddress: { defaultValue: '' },
			Title: { defaultValue: '' },
			HashPassword: { defaultValue: '' },
			ResetPasswordToken: { defaultValue: '' },
			JapaneseVisa: { defaultValue: '' },
			GithubHandle: { defaultValue: '' },
			TwitterHandle: { defaultValue: '' },
			Personality: { defaultValue: {} },
			Active: { defaultValue: false },
			ThirdPartyId: { defaultValue: null },
			ThirdPartyType: { defaultValue: null },
			FormData: { defaultValue: {} }
		};
	}
}
