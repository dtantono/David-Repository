import { BaseModel } from './ModelRegister';
import {IAttachment} from "./Pipeline";
import config from "../../../config";

export const mapMessagePaths = (Messages: Message[], ChatRoomId: string) => {
	return Messages.map((message : any) => {
		if('Attachment' in message) {
			message.Attachment.Path = config.s3.url + ChatRoomId + '/' + message.Attachment.Name
		}
		return message;
	});
};

export class ChatRoom extends BaseModel {
	protected static table: string = 'ChatRoom';

	// Attributes
	public Messages: Message[];
	public RoomName: string;
	public GroupName: string;
	public Starter: string;
	public Users: string[];
	public Contacts: string[];
	public Archived: boolean;
	public Color: string;

	constructor() {
		super();
		this.type = 'ChatRoom';
		this.schema = {
			Messages: {
				defaultValue: []
			},
			RoomName: {
				defaultValue: 'New chat room'
			},
			Starter: {
				defaultValue: ''
			},
			Users: {
				defaultValue: []
			},
			GroupName: {
				defaultValue: ''
			},
			Archived: {
				defaultValue: false
			},
			Color: {
				defaultValue: 'Red'
			}
		};
	}

	public(...excludeProperties: string[]) {
		const data = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		data.Messages = mapMessagePaths(data.Messages, this.getFullKey());
		return data;
	}
}

export interface Message {
	Description: string,
	FromUserId: string,
	CreatedAt: number,
	Attachment: IAttachment
}

export class Template extends BaseModel {
	protected static table: string = 'Template';

	// Attributes
	public Message: string;
	public UserId: string;

	constructor() {
		super();
		this.type = 'Template';
		this.schema = {
			Message: {
				defaultValue: ''
			},
			UserId: {
				defaultValue: ''
			}
		};
	}
}
