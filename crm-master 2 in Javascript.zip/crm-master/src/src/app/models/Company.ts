import { BaseModel } from './ModelRegister';
import {uploadProfilePicture} from "../helpers/imageTools";
import config from "../../../config";
import {ITeam} from "./GlobalClasses";
import countries from "../db/ReferenceData/Countries";

interface ICompanyReadOnly {
	JobPosts: number;
	Hires: number;
	Dropped: number;
}

export class Company extends BaseModel {
	protected static table: string = 'Company';

	// Attributes
	public RecruiterId: string;
	public CompanyName: string;
	public Picture: string;
	public Mission: string;
	public WhoCanApply: string;
	public VisaSponsorship: string;
	public Headquarters: string;
	public CompanySize : number;
	public About : string;
	public MainBusiness : string[];
	public AddressOne: string;
	public AddressTwo: string;
	public ReadOnly: ICompanyReadOnly;
	public Teams: ITeam[];
	public Country: string;
	public PhoneNumber: string;
	public Postcode: string;
	public State: string;
	public Industry: string;
	public Founded: number;
	public CompanyType: string;
	public Website: string;

	constructor() {
		super();
		this.type = 'Company';
		this.schema = {
			CompanyName: { defaultValue: '' },
			ReadOnly: { defaultValue: {
					JobPosts: 0,
					Hires   : 0,
					Dropped : 0,
				}
			},
			About: { defaultValue: '' },
			MainBusiness: { defaultValue: [] },
			Picture: { defaultValue: '' },
			Mission: { defaultValue: '' },
			WhoCanApply: { defaultValue: '' },
			VisaSponsorship: { defaultValue: '' },
			Teams: { defaultValue: [] },
			Headquarters: { defaultValue: '' },
			CompanySize: { defaultValue: 0 },
			AddressOne: { defaultValue: '' },
			AddressTwo: { defaultValue: '' },
			Postcode: { defaultValue: '' },
			State: { defaultValue: '' },
			Country: { defaultValue: '' },
			Industry: { defaultValue: '' },
			Founded: { defaultValue: '' },
			CompanyType: { defaultValue: '' },
			Website: { defaultValue: '' },
			PhoneNumber: { defaultValue: '' },
			RecruiterId: { defaultValue: '' },
		};
	}
	update() {
		super.update();
		if(this.Picture !== '') {
			this.Picture = this.getFullKey();
		}
	}

	async updatePicture (input: string) {
		if (input && input !== '' && input !== this.getFullKey()) {
			this.Picture = this.getFullKey();
			return uploadProfilePicture(input, this, 'Picture');
		}
	}

	public(...excludeProperties: string[]) {
		const data : any = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		data.Picture = data.Picture === '' ? '' : config.s3.url + data.Picture;
		data.CountryRaw = data.Country;
		data.Country = data.Country in countries ? countries[data.Country].name : '';
		return data;
	}
}
