import {IUser, User} from './Candidate';

export class CompanyUser extends User implements IUser {
	protected static table: string = 'CompanyUser';

		// Attributes
	public FirstName: string;
	public LastName: string;
	public DateOfBirth: string;
	public Gender: string;
	public Nationality: string;
	public PhoneNumber: string;
	public ProfilePicture: string;
	public CurrentLocation: string;
	public Notifications: any[];
	public Locale: string;
	public CompanyId: string;
	public InvitationKey: string;
	public BookmarkedCandidates: string[];
	public ResetPasswordToken: string;
	public InvitationType: string;
	public Role: number;

	constructor() {
		super();
		this.type = 'CompanyUser';
		this.schema = {
			FirstName: { defaultValue: '' },
			LastName: { defaultValue: '' },
			DateOfBirth: { defaultValue: '' },
			Gender: { defaultValue: '' },
			InvitationKey: { defaultValue: '' },
			InvitationType: { defaultValue: '' },
			Nationality: { defaultValue: 'JP' },
			PhoneNumber: { defaultValue: '' },
			ProfilePicture: { defaultValue: '' },
			CurrentLocation: { defaultValue: 'JP' },
			BookmarkedCandidates: { defaultValue: [] },
			ResetPasswordToken: { defaultValue: '' },
			EmailAddress: { defaultValue: '' },
			HashPassword: { defaultValue: '' },
			Locale: { defaultValue: 'en' },
			Notifications: { defaultValue: [] },
			CompanyId: { defaultValue: '' },
			Active: { defaultValue: false },
			Role: { defaultValue: 0 }
		};
	}
}

export class CompanyUserWithRecruiterId extends CompanyUser {
	RecruiterId: string;
}