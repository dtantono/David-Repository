import { BaseModel } from './ModelRegister';

export class Event extends BaseModel {
	protected static table: string = 'Event';

	// Attributes
	public Title: string;
	public Availability: string;
	public Body: string;
	public Users: any[];
	public Repeat: string;
	public Location: string;
	public StartTime: number;
	public EndTime: number;
	public UserId: string;

	constructor() {
		super();
		this.type = 'Event';
		this.schema = {
			Title: {
				defaultValue: ''
			},
			Availability: {
				defaultValue: ''
			},
			Body: {
				defaultValue: ''
			},
			Users: {
				defaultValue: []
			},
			Repeat: {
				defaultValue: ''
			},
			Location: {
				defaultValue: ''
			},
			StartTime: {
				defaultValue: Date.now()
			},
			EndTime: {
				defaultValue: Date.now()
			},
			UserId: {
				defaultValue: ''
			}
		};
	}
}
