import {CompanyUserWithRecruiterId} from "./CompanyUser";

export interface Tag {
	name: string,
	value: number
}

export interface ITeam {
	Name: string;
	Members: string[];
}

import {Context, Middleware, ParameterizedContext, Request} from 'koa';
import {RecruiterUser} from "./RecruiterUser";
import {Account} from "./Account";
import {IRouterParamContext} from "koa-router";

interface ICandidateRequest extends Request {
	user: Account
}
interface ICompanyRequest extends Request {
	user: CompanyUserWithRecruiterId
}
interface IRecruiterRequest extends Request {
	user: RecruiterUser
}

export interface IContext extends ParameterizedContext<any, IRouterParamContext<any, {}>> {
	request: ICandidateRequest | ICompanyRequest | IRecruiterRequest
}

export interface ICandidateContext extends IContext {
	request: ICandidateRequest
}

export interface ICompanyContext extends IContext {
	request: ICompanyRequest
}

export interface IRecruiterContext extends IContext {
	request: IRecruiterRequest
}