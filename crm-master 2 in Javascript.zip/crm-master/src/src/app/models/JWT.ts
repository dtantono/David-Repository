import { BaseModel } from './ModelRegister';

export class JWT extends BaseModel {
	protected static table: string = 'JWT';

	// Attributes
	public UserId: string;

	constructor() {
		super();
		this.type = 'JWT';
		this.schema = {
			UserId: {
				defaultValue: ''
			}
		};
	}
}
