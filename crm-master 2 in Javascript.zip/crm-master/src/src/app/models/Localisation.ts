import { BaseModel } from './ModelRegister';

export class Localisation extends BaseModel {
	protected static table: string = 'Localisation';
	public Words: object;

	constructor() {
		super();
		this.type = 'Localisation';
		this.schema = {
			Words: {
				defaultValue: {}
			}
		};
	}
}
