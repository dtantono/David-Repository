import { Candidate } from './Candidate';
import { Application } from './Application';
import { Account } from './Account';
import { Company } from './Company';
import { CompanyUser } from './CompanyUser';
import { Opening } from './Opening';
import { Pipeline } from './Pipeline';
import { Recruiter } from './Recruiter';
import { RecruiterUser } from './RecruiterUser';
import { Resume } from './Resume';
import { Event } from './Event';
import { BaseModelRegister, Model } from '../db/DatabaseModule/BaseModel';
import { Relation, RelationManager } from '../db/DatabaseModule/RelationManager';
import { ChatRoom, Template } from './ChatRoom';
import { JWT } from './JWT';
import {Localisation} from "./Localisation";

export const relations = new RelationManager();
relations.push(new Relation('Application', 'Opening'));
relations.push(new Relation('Application', 'Account', 'CandidateId'));
relations.push(new Relation('Application', 'Resume'));
relations.push(new Relation('Opening', 'Company'));
relations.push(new Relation('Opening', 'RecruiterUser', 'UserId'));
relations.push(new Relation('CompanyUser', 'Company'));
relations.push(new Relation('RecruiterUser', 'Recruiter'));
relations.push(new Relation('Account', 'Candidate', 'AccountEntityId'));
relations.push(new Relation('Account', 'Company', 'AccountEntityId'));
relations.push(new Relation('Account', 'Recruiter'));
relations.push(new Relation('Resume', 'Account', 'UserId'));

interface ModelRegister extends BaseModelRegister {
	Candidate: Candidate,
	Application: Application,
	Account: Account,
	Company: Company,
	CompanyUser: CompanyUser,
	Event: Event,
	Opening: Opening,
	Pipeline: Pipeline,
	Recruiter: Recruiter,
	RecruiterUser: RecruiterUser,
	Resume: Resume,
	ChatRoom: ChatRoom,
	JWT: JWT,
	Template: Template,
	Localisation: Localisation,
}

export class BaseModel extends Model<ModelRegister> {
	all() {
		return super.all();
	}
}
