import { BaseModel } from './ModelRegister';
import { Tag } from './GlobalClasses';

export class Opening extends BaseModel {
	protected static table: string = 'Opening';

	// Attributes
	public Position: string;
	public Description: string;
	public Location: string;
	public JobType: string;
	public RequiredExperience: any[];
	public RequiredEducation: any[];
	public AdditionalSkills: any[];
	public OtherRequirements: string[];
	public Compensation: number;
	public ActionDate: string;
	public RequiredCandidates: number;
	public VisaSponsorship: boolean;
	public DesiredLanguages: string[];
	public ExternalUrl: string;
	public EducationLevel: string;
	public UserId: string;
	public CompanyId: string;
	public Active: boolean;
	public ReadOnly: ReadOnly;
	public Tags: Tag[];

	constructor() {
		super();
		this.type = 'Opening';
		this.schema = {
			Position: {
				defaultValue: ''
			},
			Description: {
				defaultValue: ''
			},
			ExternalUrl: {
				defaultValue: ''
			},
			Location: {
				defaultValue: ''
			},
			JobType: {
				defaultValue: ''
			},
			DesiredLanguages: {
				defaultValue: []
			},
			EducationLevel: {
				defaultValue: ''
			},
			VisaSponsorship: {
				defaultValue: false
			},
			RequiredExperience: {
				defaultValue: []
			},
			RequiredEducation: {
				defaultValue: []
			},
			AdditionalSkills: {
				defaultValue: []
			},
			OtherRequirements: {
				defaultValue: []
			},
			Compensation: {
				defaultValue: 0
			},
			ActionDate: {
				defaultValue: ''
			},
			RequiredCandidates: {
				defaultValue: 0
			},
			UserId: {
				defaultValue: ''
			},
			CompanyId: {
				defaultValue: ''
			},
			Active: {
				defaultValue: false
			},
			Tags: {
				defaultValue: []
			},
			ReadOnly: {
				defaultValue: {
					ApplicationCount: 0,
					VacanciesUnfilled: 0
				}
			}
		};
	}
}

interface ReadOnly {
	ApplicationCount: number,
	VacanciesUnfilled: number
}
