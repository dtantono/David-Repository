import { BaseModel } from './ModelRegister';
import taskStatuses from "../db/ReferenceData/TaskStatus";
import config from "../../../config";
import applicationStatuses from "../db/ReferenceData/ApplicationStatus";

export class Pipeline extends BaseModel {
	protected static table: string = 'Pipeline';

	// Attributes
	public Title: string;
	public Tasks: ITask[];
	public UserId: string;
	public CompanyId: string;
	public Description: string;

	constructor() {
		super();
		this.type = 'Pipeline';
		this.schema = {
			Title: { defaultValue: '' },
			Tasks: { defaultValue: [] },
			UserId: { defaultValue: '' },
			CompanyId: { defaultValue: '' },
			Description: { defaultValue: '' }
		};
	}
}

export interface InterviewDetails {
	From: number,
	To: number
	Location: string,
}

// A task that is found within the candidates pipeline (not an actual task type)
export interface IApplicationTask {
	id: string;
	Name: string;
	TaskType: string;
	Tasks: IApplicationTask[];
	Status: number;
	Source: number;
	DueDate: number;
    Days: number;
	Description: string;
	Comments: IComment[]
}

export interface IComment {
	Description: string,
	FromUserId: string,
	CreatedAt: number
}

export interface PublicApplicationTask extends IApplicationTask {
	Id: string
}

export interface ITask {
	id: string,
	Name: string;
	TaskType: string;
	Status: number;
	OwnerId: string;
	Days: number;
	Deadline: number;
	Description: string;
}

export class Task extends BaseModel implements ITask {
	protected static table: string = 'Task';

	// Attributes
	public Name: string;
	public TaskType: string;
	public Status: number;
	public OwnerId: string;
	public Deadline: number;
	public Description: string;

	constructor() {
		super();
		this.type = 'Task';
		this.schema = {
			Name: { defaultValue: '' },
			TaskType: { defaultValue: 'Todo' },
			Tasks: { defaultValue: [] },
			Status: { defaultValue: 1 },
			OwnerId: { defaultValue: '' },
			Duration: { defaultValue: 0 },
			Date: { defaultValue: Date.now() },
			Location: { defaultValue: '' },
			Components: { defaultValue: [] },
			File: { defaultValue: '' },
			TodoList: { defaultValue: [] },
			Description: { defaultValue: '' }
		};
	}

	public(...excludeProperties: string[]) {
		const data = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		const status = applicationStatuses[this.Status.toString()];
		data.Status = status ? status.name : data.Status;
		return data;
	}
}

export interface Todo {
	Id: number,
	Name: string,
	Done: boolean
}

// The todo-type of the Task model
export class TodoTask extends Task {
	TodoList: Todo[]
}

export interface IAttachment {
	Name: string
}

// The todo-type of the candidate pipeline
export interface IApplicationTodoTask extends IApplicationTask {
	TodoList: Todo[],
	Attachments: IAttachment[]
}

export interface IFolderTask extends ITask {
	Tasks: Task[];
}

export class FolderTask extends Task {
	public Tasks: Task[];
}

export class DocumentTask extends Task {
	File: string;
	Components: Component[];
}

export interface IUpdateTodoTask {
	Id: number;
	Done: boolean;
}
export interface IFile {
	Name: string,
	Contents: string
}
export interface IUpdateTodoList {
	TodoList: IUpdateTodoTask[],
	Files: IFile[],
	Comments: IComment[],
}

export interface IApplicationDocumentTask extends IApplicationTask {
	id: string; // original Task id
	type: string;
	File: string;
	Components: Component[];
	Files: IFile[];
}

export interface IApplicationInterviewTask extends IApplicationTask {
	InterviewDetails: InterviewDetails;
}

export interface IInterviewTask extends ITask {
	InterviewDetails: InterviewDetails;
}

export class InterviewTask extends Task implements IInterviewTask {
	public InterviewDetails: InterviewDetails;
}

export interface Component {
	Id: number,
	Value: string,
	pos: Position,
	type: {
		FieldType: string,
		Label: string
	},
	page: number
}

export interface Position {
	x: number;
	y: number;
}
