import { BaseModel } from './ModelRegister';
import config from "../../../config";
import {uploadProfilePicture} from "../helpers/imageTools";
import {ITeam} from "./GlobalClasses";

export class Recruiter extends BaseModel {
	protected static table: string = 'Recruiter';

	// Attributes
	public RecruiterId: string;
	public RecruiterName: string;
	public Picture: string;
	public EmployeeCount: number;
	public AddressOne: number;
	public AddressTwo: number;
	public Location: string;
	public Website: string;
	public Country: string;
	public State: string;
	public PhoneNumber: string;
	public IsSuperAdmin: boolean;
	public Postcode: string;
	public RecruiterCode: string;
	public Teams: ITeam[];

	constructor() {
		super();
		this.type = 'Recruiter';
		this.schema = {
			RecruiterId: { defaultValue: ''	},
			RecruiterName: { defaultValue: ''	},
			Teams: { defaultValue: []	},
			IsSuperAdmin: { defaultValue: false	},
			Picture: { defaultValue: ''	},
			Country: { defaultValue: ''	},
			AddressOne: { defaultValue: ''	},
			AddressTwo: { defaultValue: ''	},
			Website: { defaultValue: ''	},
			State: { defaultValue: ''	},
			PhoneNumber: { defaultValue: ''	},
			Postcode: { defaultValue: ''	},
			EmployeeCount: { defaultValue: 0	},
			RecruiterCode: { defaultValue: ''	}
		};
	}

	update() {
		super.update();
		if(this.Picture !== '') {
			this.Picture = this.getFullKey();
		}
	}

	async updatePicture (input: string) {
		if (input && input !== '' && input !== this.getFullKey()) {
			this.Picture = this.getFullKey();
			return uploadProfilePicture(input, this, 'Picture');
		}
	}

	public(...excludeProperties: string[]) {
		const data = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		data.Picture = data.Picture === '' ? '' : config.s3.url + data.Picture;
		return data;
	}
}
