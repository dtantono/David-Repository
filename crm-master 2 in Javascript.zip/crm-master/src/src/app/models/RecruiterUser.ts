import {IUser, User} from './Candidate';

export class RecruiterUser extends User implements IUser {
	protected static table: string = 'RecruiterUser';

	// Attributes
	public FirstName: string;
	public LastName: string;
	public DateOfBirth: string;
	public Gender: string;
	public Nationality: string;
	public PhoneNumber: string;
	public ProfilePicture: string;
	public CurrentLocation: string;
	public Locale: string;
	public RecruiterId: string;
	public InvitationKey: string;
	public ResetPasswordToken: string;
	public BookmarkedCandidates: string[];
	public Notifications: any[];
	public InvitationType: string;
	public Role: number;

	constructor() {
		super();
		this.type = 'RecruiterUser';
		this.schema = {
			FirstName: { defaultValue: '' },
			LastName: { defaultValue: '' },
			DateOfBirth: { defaultValue: '' },
			Gender: { defaultValue: '' },
			InvitationKey: { defaultValue: '' },
			InvitationType: { defaultValue: '' },
			Nationality: { defaultValue: 'JP' },
			PhoneNumber: { defaultValue: '' },
			ProfilePicture: { defaultValue: '' },
			CurrentLocation: { defaultValue: 'JP' },
			BookmarkedCandidates: { defaultValue: [] },
			ResetPasswordToken: { defaultValue: '' },
			EmailAddress: { defaultValue: '' },
			HashPassword: { defaultValue: '' },
			Locale: { defaultValue: 'en' },
			Notifications: { defaultValue: [] },
			RecruiterId: { defaultValue: '' },
			Active: { defaultValue: false },
			Role: { defaultValue: 0 }
		};
	}
}
