import { BaseModel } from './ModelRegister';
import languages from '../db/ReferenceData/Languages';

export interface CareerSummary {
	Description: string;
}

export interface Experience {
	Company: string;
	JobTitle: string;
	From: number;
	To: number;
	IsCurrent: boolean;
	Description: string;
	Link: string;
}

export interface Education {
	School: string;
	Degree: string;
	From: number;
	To: number;
	IsCurrent: boolean;
	Description: string;
	Grade: string;
	FieldOfStudy: string;
	Location: string;
}

export interface Award {
	Title: string;
	Association: string;
	From: number;
	Issuer: string;
	Description: string;
}

export interface FeatureSkill {
	SkillName: string,
	Level: number
}

export class Resume extends BaseModel {
	protected static table: string = 'Resume';

	// Attributes
	public CareerSummary: CareerSummary;
	public Experience: Experience[];
	public Education: Education[];
	public FeatureSkills: FeatureSkill[];
	public Languages: object[];
	public Awards: Award[];
	public UserId: string;
	public Name: string;
	public Default: boolean;
	public Language: string;
	public DesiredSalary: number;
	public JobTitle: string;
	public Tags: string[];

	constructor() {
		super();
		this.type = 'Resume';
		this.schema = {
			CareerSummary: {
				defaultValue: ''
			},
			Experience: {
				defaultValue: []
			},
			Education: {
				defaultValue: []
			},
			FeatureSkills: {
				defaultValue: []
			},
			Languages: {
				defaultValue: []
			},
			Awards: {
				defaultValue: []
			},
			UserId: {
				defaultValue: ''
			},
			Name: {
				defaultValue: ''
			},
			Default: {
				defaultValue: false
			},
			Language: {
				defaultValue: 'en'
			},
			JobTitle: {
				defaultValue: ''
			},
			DesiredSalary: {
				defaultValue: 0
			},
			Tags: {
				defaultValue: []
			}
		};
	}

	public(...excludeProperties: string[]) {
		const data : any = excludeProperties.length ? super.public(...excludeProperties) : super.public();
		data.LanguageRaw = data.Language;
		data.Language = data.Language in languages ? languages[data.Language].name : '';
		data.FeatureSkills = data.FeatureSkills.reduce((total, skill) => {
			total[skill.SkillName] = skill.Level;
			return total;
		}, {});
		data.Languages = data.Languages.reduce((total, language) => {
			total[language.Name] = language.Level;
			return total;
		}, {});
		return data;
	}
}
