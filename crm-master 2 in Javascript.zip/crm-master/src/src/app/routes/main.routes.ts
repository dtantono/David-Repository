import Router = require('koa-router');
import main = require('../controllers/main');
import recruiterController = require('../controllers/recruiters');
import companyController = require('../controllers/companies');
import candidateController = require('../controllers/candidates');
import passport = require('koa-passport');
import info = require('../controllers/info');
import pusher = require('../services/pusher');

export const publicRouter = new Router({ prefix: '/api' });
export const privateRouter = new Router({ prefix: '/api' });
import { authError } from '../controllers/auth';
import {ICompanyContext, IContext, IRecruiterContext} from "../models/GlobalClasses";

// MIDDLEWARE
privateRouter.use(passport.initialize());

const getLocale = (ctx : IContext) => {
	const defaultLocale = 'en';
	const localeArr = 'accept-language' in ctx.headers ? ctx.headers['accept-language'].split(/[,;]/).filter((locale) => ['en', 'ja'].includes(locale)) : [];
	ctx.request.user = ctx.request.user ? ctx.request.user : { Locale: defaultLocale } as any;
	if (localeArr.length > 0) {
		ctx.request.user.Locale = localeArr[0];
	} else if (!ctx.request.user.hasOwnProperty('Locale')) {
		ctx.request.user.Locale = defaultLocale;
	}
	return ctx;
};

privateRouter.use(async function requireLogin(ctx : IContext, next) {
	const user = await new Promise((resolve) => {
		passport.authenticate('jwt', { session: false }, (user) => {
			ctx.request.user = user;
			ctx = getLocale(ctx);
			resolve(user);
		})(ctx);
	});
	if (user) {
		return await next(ctx);
	}
	return authError(ctx);
});
publicRouter.use(async function publicLocale(ctx : IContext, next) {
	return await next(getLocale(ctx));
});

publicRouter.get('/', async (ctx : IContext) => {
	ctx.response.body = { message: 'Welcome to the shared api!' };
});

publicRouter.post('/pusher/auth', pusher.auth);

privateRouter.get('/profile', main.profile);
privateRouter.get('/timeline', main.timeline);
privateRouter.put('/profile', main.updateProfile);
privateRouter.put('/profile/picture', main.uploadPicture);

// localisation
privateRouter.get('/locale/:locale', main.updateLocale);
publicRouter.put('/localisation/:word', info.updateWord);
publicRouter.post('/localisation/:word', info.createWord);
publicRouter.delete('/localisation/:word', info.deleteWord);
publicRouter.get('/localisation', info.getAllWords);

// Events
privateRouter.get('/events', main.getEvents);
privateRouter.get('/events/:id', main.getEvent);
privateRouter.put('/events/:id', main.updateEvent);
privateRouter.delete('/events/:id', main.deleteEvent);
privateRouter.post('/events', main.createEvent);

// Resumes
privateRouter.get('/resumes', main.getResumes);
privateRouter.get('/resumes/default', main.getDefaultResume);
privateRouter.get('/resumes/:id', main.getResume);
privateRouter.get('/resumes/:id/download', main.downloadResume);
privateRouter.get('/resumes/:id/preview', main.previewResume);
privateRouter.post('/resumes', main.createResume);
privateRouter.put('/resumes/:id', main.updateResume);
privateRouter.delete('/resumes/:id', main.deleteResume);
privateRouter.get('/resumes/:id/default', main.makeResumeDefault);
privateRouter.post('/resumes/validateCareerSummary', (ctx : IContext) =>
	main.validateResumePart(ctx, 'validateCareerSummarySchema')
);
privateRouter.post('/resumes/validateExperience', (ctx : IContext) =>
	main.validateResumePart(ctx, 'validateExperienceSchema')
);
privateRouter.post('/resumes/validateEducation', (ctx : IContext) =>
	main.validateResumePart(ctx, 'validateEducationSchema')
);
privateRouter.post('/resumes/validateFeatureSkills', (ctx : IContext) =>
	main.validateResumePart(ctx, 'validateSkillsSchema')
);
privateRouter.post('/resumes/validateLanguages', (ctx : IContext) =>
	main.validateResumePart(ctx, 'validateLanguagesSchema')
);
privateRouter.post('/resumes/validateAwards', (ctx : IContext) =>
	main.validateResumePart(ctx, 'validateAwardSchema')
);

// Openings
privateRouter.get('/openings', main.getOpenings);
privateRouter.get('/openings/mine', main.getMyOpenings);
privateRouter.delete('/openings/:id', main.deleteOpening);
privateRouter.post('/openings/search', main.getOpenings);
privateRouter.post('/openings/advanced', main.advancedSearchOpenings);
privateRouter.get('/openings/:id', main.getOpening);
privateRouter.post('/openings', main.createOpening);
privateRouter.put('/openings/:id', main.updateOpening);
privateRouter.post('/openings/:id/recommend', main.makeRecommendation);
publicRouter.get('/openings/:id/public', main.getOpeningPublic);

// Applications
privateRouter.get('/applications', main.getApplications);
privateRouter.post('/applications/search', main.getApplications);
privateRouter.get('/applications/:id', (ctx: IContext) => main.getApplication(ctx));
privateRouter.get('/applications/:id/cancel', main.cancelApplication);
// privateRouter.post('/applications/:id/tasks', main.createApplicationTask);
privateRouter.put('/applications/:id/reorder', main.reorderTasks);
privateRouter.get('/openings/:id/applications', main.getApplicationsForOpening);
privateRouter.post('/openings/:id/applications', main.createApplication);
privateRouter.post('/applications/:id/accept', main.acceptApplication);
privateRouter.post('/applications/:id/offer', main.makeOffer);
privateRouter.put('/applications/:id/offer', (ctx) => main.makeOffer(ctx, true));
privateRouter.get('/applications/:id/offer/accept', main.acceptApplicationOffer);
privateRouter.get('/applications/:id/offer/decline', main.declineApplicationOffer);
privateRouter.post('/applications/:id/offer/negotiate', main.negotiateApplicationOffer);
privateRouter.post('/applications/:id/reject', main.rejectApplication);
privateRouter.put('/applications/:applicationId/todo/:taskId', main.updateTodoTask);
privateRouter.put('/applications/:applicationId/document/:taskId', main.updateDocumentTask);
privateRouter.get('/applications/:applicationId/document/:taskId', main.downloadDocumentTask);
privateRouter.get('/applications/:applicationId/task/:taskId', main.getApplicationTask);
privateRouter.put('/applications/:applicationId/task/:taskId/complete', main.completeApplicationTask);
privateRouter.get('/applications/:id/complete', main.checkApplicationComplete);
privateRouter.post('/applications/:applicationId/task/:taskId/comment', main.addTaskComment);
// privateRouter.get(
// 	'/applications/:applicationId/task/:taskId/status',
// 	main.updateTaskStatus
// );

// Dashboard
privateRouter.get('/dashboard', main.dashboard);

// Pipelines
privateRouter.get('/tasks', main.getTasks);
privateRouter.get('/tasks/:id', main.getTask);
privateRouter.delete('/tasks/:id', main.deleteTask);
privateRouter.post('/tasks/:type', (ctx) => main.createTask(ctx, ctx.params.type));
privateRouter.put('/tasks/:id', main.updateTask);
privateRouter.get('/pipelines', main.getPipelines);
privateRouter.get('/pipelines/:id', main.getPipeline);
privateRouter.post('/pipelines', main.createPipeline);
privateRouter.put('/pipelines/:id', main.updatePipeline);
privateRouter.delete('/pipelines/:id', main.deletePipeline);
// privateRouter.post('/pipelines/:id/document', main.addPipelineDocument);

// Notifications
privateRouter.get('/notifications', main.getNotifications);

// Messages
privateRouter.get('/chat', main.getChatRoom);
privateRouter.get('/chat/archived', main.getArchivedChatRoom);
privateRouter.get('/chat/deleted', main.getDeletedChatRooms);
privateRouter.get('/chat/:id', main.getChatRoomMessages);
privateRouter.get('/chat/:id/archive', main.archiveChatRoom);
privateRouter.get('/chat/:id/print', main.printChatRoom);
privateRouter.delete('/chat/:id', main.deleteChatRoom);
privateRouter.post('/chat/:id', main.sendChatRoomMessage);
privateRouter.post('/chat', main.createChatRoom);
privateRouter.get('/messages', main.latestMessages);
privateRouter.get('/messages/sent', main.sentMessages);
privateRouter.get('/messages/received', main.receivedMessages);
privateRouter.get('/messages/search', main.searchMessages);
privateRouter.get('/contacts', main.getContacts);
privateRouter.get('/templates', main.getTemplates);

// Google authentication
publicRouter.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
publicRouter.get('/auth/google/callback', (ctx : IContext) =>
	candidateController.loginThirdParty(ctx, 'google')
);

// Github authentication
publicRouter.get('/auth/github', passport.authenticate('github', { scope: ['user:email'] }));
publicRouter.get('/auth/github/callback', (ctx : IContext) => candidateController.loginThirdParty(ctx, 'github'));

// LinkedIn authentication
publicRouter.get('/auth/linkedin', passport.authenticate('linkedin', {
		scope: ['r_emailaddress', 'r_basicprofile']
	})
);
publicRouter.get('/auth/linkedin/callback', (ctx : IContext) => candidateController.loginThirdParty(ctx, 'linkedin'));

// Local Authentication
publicRouter.post('/candidates/login', candidateController.login);
privateRouter.post('/candidates/logout', candidateController.logout);
publicRouter.post('/candidates/requestResetPassword', (ctx : IContext) => main.requestResetPassword(ctx, 'Candidate'));

publicRouter.post('/recruiters/requestResetPassword', (ctx : IContext) => main.requestResetPassword(ctx, 'Recruiter'));
publicRouter.post('/companys/requestResetPassword', (ctx : IContext) => main.requestResetPassword(ctx, 'Company'));
publicRouter.post('/candidates/resetPassword', (ctx : IContext) => main.resetPassword(ctx, 'Candidate'));
publicRouter.post('/recruiters/resetPassword', (ctx : IContext) => main.resetPassword(ctx, 'Recruiter'));
publicRouter.post('/companys/resetPassword', (ctx : IContext) => main.resetPassword(ctx, 'Company'));

privateRouter.post('/changePassword', main.changePassword);
privateRouter.post('/candidates/checkPassword', candidateController.checkPassword);
publicRouter.get('/candidates/register/confirm', candidateController.confirmRegistration);
privateRouter.get('/recruiters/:id/switch', recruiterController.switchAccount);

// Registration
publicRouter.post('/candidates/register', candidateController.register);
publicRouter.post('/candidates/register/validatePersonalInformation', candidateController.validatePersonalInformation);
publicRouter.post('/candidates/register/validateCreateAccount', (ctx : IContext) =>
	main.validateResumePart(ctx, 'candidateCreateAccountSchema')
);
privateRouter.post('/candidates/register/personality', candidateController.registerPersonality);
privateRouter.get('/candidates/personality', candidateController.getPersonality);
privateRouter.get('/candidates/skills', candidateController.getPersonalitySkills);

// Recruiters
privateRouter.get('/recruiters', main.getRecruitersList); // get recruiters connected to my account
privateRouter.get('/users', main.getUserList); // get recruiters connected to my account
privateRouter.put('/recruiters/profile', main.updateRecruiterProfile);
privateRouter.get('/recruiters/profile', main.getRecruiterProfile);
privateRouter.put('/companies/profile', main.updateCompanyProfile);
privateRouter.get('/companies/profile', main.getCompanyProfile);
privateRouter.put('/recruiters/:id', main.updateRecruiterUserById);
privateRouter.put('/companies/:id', main.updateCompanyUserById);

// Candidates
privateRouter.get('/candidates', (ctx : ICompanyContext | IRecruiterContext) => main.getCandidatesList(ctx, false)); // get candidates connected to my account
privateRouter.post('/candidates/search', (ctx : ICompanyContext | IRecruiterContext) => main.getCandidatesList(ctx, false)); // get candidates connected to my account
privateRouter.post('/candidates/advanced', main.advancedSearchCandidates); // get candidates connected to my account
privateRouter.get('/candidates/bookmarked', (ctx : ICompanyContext | IRecruiterContext) => main.getCandidatesList(ctx, true));
privateRouter.get('/candidates/:id', main.getCandidate);
privateRouter.get('/bookmark/:id', main.bookmarkCandidate);
privateRouter.post('/invite', main.invite);
privateRouter.post('/invite/bulk', main.bulkInvite);
publicRouter.get('/invite/:id', main.acceptInvite);

// Recruiter authentication
publicRouter.post('/recruiters/register/signup', recruiterController.validateSignup);
publicRouter.post('/recruiters/register/company',  (ctx : IContext) =>
	main.validateResumePart(ctx, 'recruiterRegisterCompanySchema')
);
publicRouter.post('/recruiters/register/companyadditional', (ctx : IContext) =>
	main.validateResumePart(ctx, 'recruiterRegisterCompanyAdditionalSchema')
);
publicRouter.post('/recruiters/register/personal', (ctx : IContext) =>
	main.validateResumePart(ctx, 'recruiterRegisterPersonalSchema')
);
publicRouter.post('/recruiters/register', recruiterController.register);
privateRouter.post('/teams', main.createTeam);
privateRouter.put('/users/:id/teams', main.updateUsersTeams);
privateRouter.get('/teams', main.getTeams);
privateRouter.post('/recruiters/register/user', recruiterController.registerCompleteInvitation);
privateRouter.post('/companies/register/user', companyController.registerCompleteInvitation);

publicRouter.post('/recruiters/login', recruiterController.login);
privateRouter.post('/recruiters/logout', candidateController.logout);

// Company authentication
publicRouter.post('/companies/register/signup', companyController.validateSignup);
publicRouter.post('/companies/register/company',  (ctx : IContext) =>
	main.validateResumePart(ctx, 'companyRegisterCompanySchema')
);
publicRouter.post('/companies/register/companyadditional', (ctx : IContext) =>
	main.validateResumePart(ctx, 'companyRegisterCompanyAdditionalSchema')
);
publicRouter.post('/companies/register/personal', (ctx : IContext) =>
	main.validateResumePart(ctx, 'recruiterRegisterPersonalSchema')
);
publicRouter.post('/companies/register', companyController.register);
privateRouter.get('/companies/information', companyController.getMyCompany);
privateRouter.post('/companies/invite', companyController.inviteMember);
publicRouter.post('/companies/login', companyController.login);
privateRouter.post('/companies/logout', companyController.logout);
privateRouter.get('/companies/members', companyController.getMembers);
privateRouter.get('/companies', main.getCompaniesList);
privateRouter.get('/companies/:id', main.getCompanyById);
privateRouter.post('/companies/members/:id/register', companyController.registerCompleteInvitation);

// Reference data
publicRouter.get('/info/referenceData', info.getReferenceData);
publicRouter.get('/info/tags', main.getTags);
privateRouter.get('/info/companies', main.getCompaniesInfoList);