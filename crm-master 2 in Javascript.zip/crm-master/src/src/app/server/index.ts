const Koa = require('koa');
const cors = require('@koa/cors');
const app = new Koa();
const os = require('os');
const path = require('path');

const logger = require('koa-logger');
// const seeder = require('../db/seed');
const https = require('https');
const fs = require('fs');
const router = require('../routes/main.routes');

const port = process.env.APPLICATION_PORT || 5000;
const koaBody = require('koa-body');

// logging
app.use(logger());
// body parsing

app.use(koaBody({ multipart: true }));
app.use(cors());

// ROUTES
app.use(router.publicRouter.routes()).use(router.publicRouter.allowedMethods()).use(router.privateRouter.routes()).use(router.privateRouter.allowedMethods());

const options = {
	key: fs.readFileSync(`${__dirname}/certs/key.pem`, 'utf8').toString(),
	cert: fs.readFileSync(`${__dirname}/certs/cert.pem`, 'utf8').toString()
};

if (process.env.NODE_ENV !== 'test') {
	https.createServer(options, app.callback()).listen(port, async () => {
		require('../commands/commands');
		console.log(`application is running on port ${port}`);
	});
}

export default app;
