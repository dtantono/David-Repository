import { Opening } from '../models/Opening';
import { Resume } from '../models/Resume';

const sw = require('stopword');

const STOPWORDS = [
	'about', 'after', 'all', 'also', 'am', 'an', 'and', 'another', 'any', 'are', 'as', 'at', 'be',
	'because', 'been', 'before', 'being', 'between', 'both', 'but', 'by', 'came', 'can',
	'come', 'could', 'did', 'do', 'each', 'for', 'from', 'get', 'got', 'has', 'had',
	'he', 'have', 'her', 'here', 'him', 'himself', 'his', 'how', 'if', 'in', 'into',
	'is', 'it', 'like', 'make', 'many', 'me', 'might', 'more', 'most', 'much', 'must',
	'my', 'never', 'now', 'of', 'on', 'only', 'or', 'other', 'our', 'out', 'over',
	'said', 'same', 'see', 'should', 'since', 'some', 'still', 'such', 'take', 'than',
	'that', 'the', 'their', 'them', 'then', 'there', 'these', 'they', 'this', 'those',
	'through', 'to', 'too', 'under', 'up', 'very', 'was', 'way', 'we', 'well', 'were',
	'what', 'where', 'which', 'while', 'who', 'with', 'would', 'you', 'your', 'a', 'i'];
const ADDITIONAL_STOPWORDS = ['new', 'able', 'use', 'good', 'know', 'when', 'dont', 'need', 'theyre', 'end', 'own', 'using', 'use', 'its', 'therefore', 'within'];
const TOTAL_STOPWORDS = [...STOPWORDS, ...ADDITIONAL_STOPWORDS];

const info = require('../services/info');

function sortObject(obj: object) {
	const arr = [];
	for (const prop in obj) {
		if (obj.hasOwnProperty(prop)) {
			arr.push({
				key: prop,
				value: obj[prop]
			});
		}
	}
	arr.sort((a, b) => a.value - b.value);
	return arr; // returns array
}

function getPercentile(object: object, percentage: number) {
	const array = sortObject(object);
	return array[Math.ceil(array.length / (1 / percentage)) - 1].value;
}

export function removePunctuation(inStr: string) {
	if (inStr && inStr.constructor === String) {
		const punctRE = /[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,-./:;<=>?@[\]^_`{|}~]/g;
		const spaceRE = /\s+/g;
		return inStr.replace(punctRE, '').replace(spaceRE, ' ');
	}
	return '';
}

export const generateResumeTags = async (data: Resume[]) => { // 'CareerSummary', 'Experience', 'Education', 'FeatureSkills', 'Languages', 'Awards', 'Name'
	const CareerSummaryTags = Object.create(null);
	const FeatureSkillsTags = Object.create(null);
	// const LanguagesTags = Object.create(null);
	// const AwardsTags = Object.create(null);
	const EducationTags = Object.create(null);
	const JobTitleTags = Object.create(null);
	const ExperienceTags = Object.create(null);

	const skills = Object.keys((await info.getKeyValue()).FeatureSkills).map((skill) => skill.toUpperCase());

	function insertOrIncrease(key, dictionary) {
		if (typeof key === 'string' && key !== '' && (key.length > 3 || skills.includes(key.toUpperCase()))) {
			const upperCaseNames = Object.keys(dictionary).map((value) => value.toUpperCase());
			const pos = upperCaseNames.indexOf(key.toUpperCase());
			if (pos === -1) {
				dictionary[key] = 1;
			} else {
				dictionary[Object.keys(dictionary)[pos]]++;
			}
		}
	}

	// Gathering the data
	data.forEach(async (resume) => {
		resume.FeatureSkills.forEach((skill) => {
			sw.removeStopwords(removePunctuation(skill.SkillName).split(' '), TOTAL_STOPWORDS).forEach((skillWord) => {
				insertOrIncrease(skillWord, FeatureSkillsTags);
			});
		});
		sw.removeStopwords(removePunctuation(resume.CareerSummary.Description).split(' '), TOTAL_STOPWORDS).forEach((descriptionWord) => {
			insertOrIncrease(descriptionWord, CareerSummaryTags);
		});
		sw.removeStopwords(removePunctuation(resume.JobTitle).split(' '), TOTAL_STOPWORDS).forEach((jobTitleWord) => {
			insertOrIncrease(jobTitleWord, JobTitleTags);
		});
		resume.Education.forEach((education) => {
			sw.removeStopwords(removePunctuation(education.Description).split(' '), TOTAL_STOPWORDS).forEach((educationWord) => {
				insertOrIncrease(educationWord, EducationTags);
			});
		});
		resume.Experience.forEach((experience) => {
			sw.removeStopwords(removePunctuation(experience.Description).split(' '), TOTAL_STOPWORDS).forEach((experienceWord) => {
				insertOrIncrease(experienceWord, ExperienceTags);
			});
		});
	});

	const skillsWeight = 0.25;
	const careerSummaryWeight = 0.1;
	// const descriptionWeight = 0.1;
	// const positionWeight = 0.6;
	const jobTitleWeight = 0.35;
	const educationWeight = 0.15;
	const experienceWeight = 0.15;

	const totalWeight = skillsWeight + careerSummaryWeight + jobTitleWeight /* + descriptionWeight + positionWeight*/ + educationWeight + experienceWeight;


	// Filtering the data
	const FeatureSkillsTwentiethPercentile = FeatureSkillsTags.length ? getPercentile(FeatureSkillsTags, skillsWeight) : 0;
	const CareerSummaryTagsTwentiethPercentile = CareerSummaryTags.length ? getPercentile(CareerSummaryTags, careerSummaryWeight) : 0;
	// const DescriptionTagsTwentiethPercentile = DescriptionTags.length ? getPercentile(DescriptionTags, descriptionWeight) : 0;
	// const PositionTagsTwentiethPercentile = PositionTags.length ? getPercentile(PositionTags, positionWeight) : 0;
	const JobTitleTagsTwentiethPercentile = JobTitleTags.length ? getPercentile(JobTitleTags, jobTitleWeight) : 0;
	const EducationTagsTwentiethPercentile = EducationTags.length ? getPercentile(EducationTags, educationWeight) : 0;
	const ExperienceTagsTwentiethPercentile = ExperienceTags.length ? getPercentile(ExperienceTags, experienceWeight) : 0;

	const filteredFeatureSkillsTags = Object.entries(FeatureSkillsTags).filter((item) => item[1] >= FeatureSkillsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * skillsWeight / totalWeight
	}));
	const filteredCareerSummaryTags = Object.entries(CareerSummaryTags).filter((item) => item[1] >= CareerSummaryTagsTwentiethPercentile).map(([k, v]: any) => ({
		name: k,
		value: v * careerSummaryWeight / totalWeight
	}));
	// const filteredDescriptionTags = Object.entries(DescriptionTags).filter((item) => item[1] >= DescriptionTagsTwentiethPercentile).map(([k, v] : any) => ({ name: k, value: v * descriptionWeight / totalWeight }));
	// const filteredPositionTags = Object.entries(PositionTags).filter((item) => item[1] >= PositionTagsTwentiethPercentile).map(([k, v] : any) => ({ name: k, value: v * positionWeight / totalWeight }));
	const filteredJobTitleTags = Object.entries(JobTitleTags).filter((item) => item[1] >= JobTitleTagsTwentiethPercentile).map(([k, v] : any) => ({ name: k, value: v * jobTitleWeight / totalWeight }));
	const filteredEducationTags = Object.entries(EducationTags).filter((item) => item[1] >= EducationTagsTwentiethPercentile).map(([k, v]: any) => ({
		name: k,
		value: v * educationWeight / totalWeight
	}));
	const filteredExperienceTags = Object.entries(ExperienceTags).filter((item) => item[1] >= ExperienceTagsTwentiethPercentile).map(([k, v]: any) => ({
		name: k,
		value: v * experienceWeight / totalWeight
	}));

	const objectToStore = [...filteredFeatureSkillsTags, ...filteredJobTitleTags, ...filteredCareerSummaryTags, /* ...filteredDescriptionTags, ...filteredPositionTags, */ ...filteredEducationTags, ...filteredExperienceTags];
	return objectToStore;
};

export const generateOpeningTags = async (data: Opening[]) => {
	const AdditionalSkillsTags = Object.create(null);
	const CompensationTags = Object.create(null);
	const DescriptionTags = Object.create(null);
	const PositionTags = Object.create(null);
	const RequiredEducationTags = Object.create(null);
	const RequiredExperienceTags = Object.create(null);

	const skills = Object.keys((await info.getKeyValue()).FeatureSkills).map((skill) => skill.toUpperCase());

	function insertOrIncrease(key, dictionary) {
		if (key !== '' && (key.length > 3 || skills.includes(key.toUpperCase()))) {
			const upperCaseNames = Object.keys(dictionary).map((value) => value.toUpperCase());
			const pos = upperCaseNames.indexOf(key.toUpperCase());
			if (pos === -1) {
				dictionary[key] = 1;
			} else {
				dictionary[Object.keys(dictionary)[pos]]++;
			}
		}
	}

	// Gathering the data
	data.forEach(async (openingData) => {
		openingData.AdditionalSkills.forEach((skill) => {
			sw.removeStopwords(removePunctuation(skill).split(' '), TOTAL_STOPWORDS).forEach((skillWord) => {
				insertOrIncrease(skillWord, AdditionalSkillsTags);
			});
		});
		insertOrIncrease(openingData.Compensation.toString(), CompensationTags);
		sw.removeStopwords(removePunctuation(openingData.Description).split(' '), TOTAL_STOPWORDS).forEach((descriptionWord) => {
			insertOrIncrease(descriptionWord, DescriptionTags);
		});
		sw.removeStopwords(removePunctuation(openingData.Position).split(' '), TOTAL_STOPWORDS).forEach((positionWord) => {
			insertOrIncrease(positionWord, PositionTags);
		});
		openingData.RequiredEducation.forEach((education) => {
			sw.removeStopwords(removePunctuation(education).split(' '), TOTAL_STOPWORDS).forEach((educationWord) => {
				insertOrIncrease(educationWord, RequiredEducationTags);
			});
		});
		openingData.RequiredExperience.forEach((experience) => {
			sw.removeStopwords(removePunctuation(experience).split(' '), TOTAL_STOPWORDS).forEach((experienceWord) => {
				insertOrIncrease(experienceWord, RequiredExperienceTags);
			});
		});
	});

	const skillsWeight = 0.2 / (AdditionalSkillsTags.length < 1000 ? 1 : 5000);
	const compensationWeight = 0.05;
	const descriptionWeight = 0.1;
	const positionWeight = 0.6;
	const educationWeight = 0.1;
	const experienceWeight = 0.2;

	const totalWeight = skillsWeight + compensationWeight + descriptionWeight + positionWeight + educationWeight + experienceWeight;


	// Filtering the data
	const AdditionalSkillsTwentiethPercentile = AdditionalSkillsTags.length ? getPercentile(AdditionalSkillsTags, skillsWeight) : 0;
	const CompensationTagsTwentiethPercentile = CompensationTags.length ? getPercentile(CompensationTags, compensationWeight) : 0;
	const DescriptionTagsTwentiethPercentile = DescriptionTags.length ? getPercentile(DescriptionTags, descriptionWeight) : 0;
	const PositionTagsTwentiethPercentile = PositionTags.length ? getPercentile(PositionTags, positionWeight) : 0;
	const RequiredEducationTagsTwentiethPercentile = RequiredEducationTags.length ? getPercentile(RequiredEducationTags, educationWeight) : 0;
	const RequiredExperienceTagsTwentiethPercentile = RequiredExperienceTags.length ? getPercentile(RequiredExperienceTags, experienceWeight) : 0;

	const filteredAdditionalSkillsTags = Object.entries(AdditionalSkillsTags).filter((item) => item[1] >= AdditionalSkillsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * skillsWeight / totalWeight
	}));
	const filteredCompensationTags = Object.entries(CompensationTags).filter((item) => item[1] >= CompensationTagsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * compensationWeight / totalWeight
	}));
	const filteredDescriptionTags = Object.entries(DescriptionTags).filter((item) => item[1] >= DescriptionTagsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * descriptionWeight / totalWeight
	}));
	const filteredPositionTags = Object.entries(PositionTags).filter((item) => item[1] >= PositionTagsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * positionWeight / totalWeight
	}));
	const filteredRequiredEducationTags = Object.entries(RequiredEducationTags).filter((item) => item[1] >= RequiredEducationTagsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * educationWeight / totalWeight
	}));
	const filteredRequiredExperienceTags = Object.entries(RequiredExperienceTags).filter((item) => item[1] >= RequiredExperienceTagsTwentiethPercentile).map(([k, v] : any) => ({
		name: k,
		value: v * experienceWeight / totalWeight
	}));

	return [...filteredAdditionalSkillsTags, ...filteredCompensationTags, ...filteredDescriptionTags, ...filteredPositionTags, ...filteredRequiredEducationTags, ...filteredRequiredExperienceTags];
};

