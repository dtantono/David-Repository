import pdfHelper = require('../helpers/pdf');
import awshelper = require('./aws');
import {Application, IApplication} from '../models/Application';
import {
	Component,
	DocumentTask,
	FolderTask,
	IApplicationDocumentTask,
	IApplicationTask,
	IApplicationTodoTask,
	IAttachment,
	IComment,
	InterviewTask,
	IUpdateTodoList,
	Pipeline,
	Todo,
	TodoTask
} from '../models/Pipeline';
import {ResultSet} from '../db/DatabaseModule/ListTypes';
import * as db from '../db/database';
import {asyncForEach} from '../helpers/arrayHelpers';

import * as info from '../services/info';
import * as notificationsService from '../services/notifications';
import {getOpeningByIdAndRecruiterId} from './openings';
import {Account} from '../models/Account';
import * as candidateService from './candidates';
import * as messagesService from './messages';
import * as _ from 'lodash';
import {getMessage} from "./localisation";

// SOURCE 1 - COMPANY, 2 - SELF
function checkStatusChange(from: number, to: number) {
	return [[0, 0, 0, 0, 0, 0],
		[1, 0, 0, 0, 0, 0],
		[1, 1, 0, 0, 0, 0],
		[1, 1, 0, 0, 0, 0],
		[0, 1, 0, 0, 0, 0],
		[0, 0, 0, 0, 1, 0]][to - 1][from - 1] === 1;
}

const searchApplications = (searchTerm: string, query) => query.whereGroup((builder) => {
	builder.where('FirstName', searchTerm, 'LIKE', 'Candidate')
		.orWhere('LastName', searchTerm, 'LIKE', 'Candidate')
		.orWhere('Position', searchTerm, 'LIKE', 'Opening');
});

export const getApplicationsByCompanyId = async (companyId: string, format: boolean = true, searchTerm = null) => {
	let query : any = await db.applications.with('Opening', 'Account')
		.leftJoin('Account', 'Candidate', 'AccountEntityId')
		.leftJoin('Opening', 'Company')
		.where('CompanyId', companyId, undefined, 'Opening');
	if(searchTerm && searchTerm.length) {
		query = searchApplications(searchTerm, query);
	}
	query = await query.get();

	return format ? query.public() : query;
};

async function mapStatus(status: string) {
	return (await info.getKeyValue()).TaskStatus[status].name;
}

export const getApplicationsByCandidateId = async (candidateId: string) => {
	const data = await db.applications.with('Opening').leftJoin('Opening', 'Company').where('CandidateId', candidateId, undefined, 'Application').get();
	return data.public('Opening.Tags').map((app) => ({
		...app,
		CandidatePipeline: app.CandidatePipeline.sort((a, b) => app.TaskOrder[a.Id] - app.TaskOrder[b.Id])
	}));
};

export const getApplicationsByCandidateIdAndStatusId = async (accountId: string, status: number, comparison: string, RecruiterId: string, sourceFilter: number = null) => {
	let data = await db.applications.with('Opening').leftJoin('Opening', 'Company').where('CandidateId', accountId, undefined, 'Application').// .where('RecruiterId', RecruiterId, undefined, 'Company')
		where('Status', status, comparison, 'Application').get();
	if (sourceFilter) {
		data = new ResultSet<Application>(data.map((app) => {
			const ret = app;
			ret.CandidatePipeline = ret.CandidatePipeline.filter((task) => task.Source === sourceFilter);
			ret.CandidatePipeline.sort((a, b) => a.Id - b.Id);
			return ret;
		}));
	}
	return data.public('Opening.Tags');
};

const filterApplications = (data : ResultSet<Application> | null, sourceFilter: number = null) => {
	if(data) {
		if (sourceFilter) {
			data = new ResultSet<Application>(data.map((app) => {
				const ret = app;
				ret.CandidatePipeline = ret.CandidatePipeline.filter((task) => task.Source === sourceFilter);
				ret.CandidatePipeline.sort((a, b) => a.Id - b.Id);
				return ret;
			}));
		}
		return data.public('Opening.Tags');
	}
	return null;
};

export const getApplicationsByRecruiterIdAndStatusId = async (status: number, comparison: string, RecruiterId: string, sourceFilter: number = null) => {
	let data = await db.applications.with('Opening').leftJoin('Opening', 'Company').where('RecruiterId', RecruiterId, undefined, 'Company')
		.where('Status', status, comparison, 'Application').get();
	return filterApplications(data, sourceFilter);
};

export const getApplicationReport = async (StartDate : Date, EndDate : Date, RecruiterId: string) => {
	const data = await db.applications.with('Opening').leftJoin('Opening', 'Company')
		.where('RecruiterId', RecruiterId, undefined, 'Company')
		.where('Status', 2, '>=', 'Application')
		// .where('StartDate', StartDate, '>=', 'Application.Offer')
		// .where('StartDate', EndDate, '<=', 'Application.Offer')
		.get();
	const weekly = data.filter(x => x.Offer.StartDate <= Date.now() + (3600 * 24 * 7 * 1000));
	const weeklyAccepted = weekly.filter(x => x.Status === 6);
	const groupByMonth = _.groupBy(data.filter(x => x.Status === 6), (d : Application) => {
		let startDate = new Date(d.Offer.StartDate);
		return `${startDate.getFullYear()}-${startDate.getMonth()+1}`;
	});
	const month = StartDate.getMonth();
	const year = StartDate.getFullYear();
	const defaultDict = {};

	for(let i = 0; i < 6; i++) {
		const thisMonth = month+i;
		const thisYear = thisMonth < 0 ? year-1 : year;
		defaultDict[`${thisYear}-${((thisMonth+12)%12)+1}`] = 0;
	}

	return {
		weeklyOfferCount: weekly.filter(x => x.Status === 5).length,
		weeklyAcceptanceCount: weeklyAccepted.length,
		weeklySalary: weeklyAccepted.reduce((s, x) => s + Number(x.Offer.Salary), 0),
		monthlySalary: Object.keys(groupByMonth).reduce((s, x) => {
			s[x] = groupByMonth[x].reduce((sum, a) => sum + a.Offer.Salary, 0);
			return s;
		}, {...defaultDict}),
		monthlyRecruiterCut: Object.keys(groupByMonth).reduce((s, x) => {
			s[x] = groupByMonth[x].reduce((sum, a) => sum + (a.Offer.Salary * a.Offer.RecruiterCut), 0) / 100;
			return s;
		}, {...defaultDict}),
		monthlyRecruiterUserCut: Object.keys(groupByMonth).reduce((s, x) => {
			s[x] = groupByMonth[x].reduce((sum, a) => sum + (a.Offer.Salary * a.Offer.RecruiterUserCut), 0) / 100;
			return s;
		}, {...defaultDict}),
	};
};

export const getApplicationsByCompanyIdAndStatusId = async (status: number, comparison: string, CompanyId: string, sourceFilter: number = null) => {
	let data = await db.applications.with('Opening').leftJoin('Opening', 'Company')
		.where('CompanyId', CompanyId, undefined, 'Opening')
		.where('Status', status, comparison, 'Application').get();
	return filterApplications(data, sourceFilter);
};

export const getApplicationsByRecruiterId = async (RecruiterId: string, format: boolean = true, searchTerm = null) => {
	let query : any = db.applications.with('Opening', 'Account')
		.leftJoin('Account', 'Candidate', 'AccountEntityId')
		.leftJoin('Opening', 'Company')
		.where('RecruiterId', RecruiterId, undefined, 'Company');

	if(searchTerm && searchTerm.length) {
		query = searchApplications(searchTerm, query);
	}

	query = await query.get();

	return format ? query.public() : query;
};

export const getApplicationByIdAndRecruiterId = async (id: string, RecruiterId: string, format: boolean = true) => {
	const data = await db.applications.with('Opening', 'Candidate', 'Resume').leftJoin('Opening', 'Company')
		.where('id', id).where('RecruiterId', RecruiterId, undefined, 'Company').first();
	return data && format ? data.public() : data;
};
export const getApplicationByIdAndCompanyId = async (id: string, companyId: string, publicFormat: boolean = true) => {
	const data = await db.applications.with('Opening', 'Candidate', 'Resume').leftJoin('Opening', 'Company')
		.where('id', id).where('id', companyId, undefined, 'Company').first();
	return publicFormat && data ? data.public() : data;
};

// Must be a public application
export const flattenCandidatePipeline = (application: any) => {
	const tasks = [];
	const getTasks = (array) => array.forEach((task) => {
		if (task.TaskType === 'Folder') {
			getTasks(task.Tasks);
		} else {
			tasks[application.TaskOrder[task.Id]] = task;
		}
	});
	getTasks(application.CandidatePipeline);
	application.CandidatePipeline = tasks;
	return application;
};

export const getApplicationByIdAndCandidateId = async (id: string, candidateId: string, publicFormat: boolean = true, flatten: boolean = false) => {
	let data = await db.applications.with('Opening', 'Account', 'Resume').leftJoin('Opening', 'Company').where('id', id).where('id', candidateId, undefined, 'Account').first();
	if (publicFormat && data) {
		data = data.public('Opening.Tags');
		if (flatten) {
			data = flattenCandidatePipeline(data);
		}
		// const getFiles = async (tasks) => {
		//     for (var i = 0; i < tasks.length; i++) {
		//         if (tasks[i].TaskType === 'Document') {
		//             tasks[i].file = await awshelper.download('Task/' + tasks[i].id);
		//         } else if(tasks[i].TaskType === 'Folder') {
		//             await getFiles(tasks[i].Tasks);
		// 		}
		//     }
		// }
		// await getFiles(data.CandidatePipeline);
	}
	return data;
};

// export const getApplicationsByOpeningId = async (openingId: string) => {
// 	const data = await db.applications.with('Opening').where('id', openingId, undefined, 'Opening').get();
// 	return data.public();
// };
export const getApplicationsByOpeningIdAndRecruiterId = async (openingId: string, RecruiterId: string) => {
	const data = await db.applications.with('Opening', 'Account').leftJoin('Account', 'Candidate', 'AccountEntityId').leftJoin('Opening', 'Company').where('RecruiterId', RecruiterId, undefined, 'Company').where('id', openingId, undefined, 'Opening').get();
	return data.public();
};
export const getApplicationsByCandidateIdAndCompanyId = async (CandidateId: string, CompanyId: string) => {
	const data = await db.applications.with('Opening', 'Account').leftJoin('Opening', 'Company').where('id', CompanyId, undefined, 'Company').where('CandidateId', CandidateId, undefined, 'Application').get();
	return data.public();
};
export const getApplicationsByOpeningIdAndCompanyId = async (openingId: string, CompanyId: string) => {
	const data = await db.applications.with('Opening').where('CompanyId', CompanyId, undefined, 'Opening').where('id', openingId, undefined, 'Opening').get();
	return data.public();
};

export const create = async (details: IApplication, Candidate: Account, OpeningId: string) => {
	if ((await getOpeningByIdAndRecruiterId(OpeningId, Candidate.RecruiterId)) !== null) {
		const existingApplications = await db.applications.newQuery().where('CandidateId', Candidate.id).where('OpeningId', OpeningId).count();
		if (existingApplications > 0) {
			return null;
		}
		const newApplication = new Application();
		await newApplication.fill(details);
		newApplication.CandidateId = Candidate.id;
		newApplication.OpeningId = `Opening/${OpeningId}`;
		newApplication.Status = 1;
		newApplication.LastActionBy = Candidate.id;
		newApplication.CandidatePipeline = [{
			Name: 'Apply',
			TaskType: 'Default',
			Status: 3,
			Source: 1,
			Tasks: [],
			DueDate: 0,
			Description: 'Apply',
			Comments: []
		} as any];
		// enter into the database
		return await db.applications.save(newApplication);
	}
	return null;
};

async function update(id: string, details: IApplication, UserId: string) {
	const application = await db.applications.find(id);
	details.CandidateId = application.CandidateId;
	application.fill(details);
	application.LastActionBy = UserId;
	// enter into the database
	return await db.applications.save(application);
}

// export const updateTodo = async (applicationId, taskID, userId, done, todoId) => {
// 	const application = await db.applications.find(applicationId);
// 	if(application) {
//
// 	}
// 	return await db.updateByFields({ CandidateId: userId, 'META().id': applicationId }, type, { 'child0.Done': done }, { TodoList: todoId, CandidatePipeline: taskID });
// };
//
export const findTaskById = (array: IApplicationTask[], taskId: string) : IApplicationTask => taskId.split('.')
	.reduce((obj : IApplicationTask[] | IApplicationTask, key) => 'Tasks' in obj ? obj.Tasks[Number(key)] : obj[Number(key)], array) as IApplicationTask;

export const updateTodoTasks = async (applicationId: string, taskID: string, userId: string, details: IUpdateTodoList) => {
	const application = await db.applications.find(applicationId) as Application;
	if (application) {
		const task = (findTaskById(application.CandidatePipeline, taskID) as IApplicationTodoTask);
		task.TodoList.forEach((todo) => {
			details.TodoList.forEach((todoUpdate) => {
				if (todo.Id === todoUpdate.Id) {
					todo.Done = todoUpdate.Done;
				}
			});
		});
		task.Comments = details.Comments.map(comment => ({
			Description: comment.Description,
			FromUserId: userId,
			CreatedAt: Date.now()
		}) as IComment);
		if('Files' in details) {
			details.Files.forEach(file => {
				awshelper.upload(application.getFullKey() + '/' + taskID + '/' + file.Name, Buffer.from(awshelper.removeBase64Prefix(file.Contents), 'base64'));
				task.Attachments.push({Name: file.Name, OwnerId: userId} as IAttachment);
			});
		}
		return await db.applications.save(application);
	}
	return null;
};

export const getApplicationTask = async (applicationId: string, taskID: string, userId: string) => {
	const application = (await db.applications.find(applicationId)).public();
	if (application /*&& application.CandidateId === userId*/) {
		const task = findTaskById(application.CandidatePipeline, taskID) as IApplicationDocumentTask;
		if (task && task.TaskType === 'Document') {
			task.File = await awshelper.download(`Task/${task.id}`);
			const formData = await candidateService.getSharedFormData(application.CandidateId);
			task.Components.map(x => {
				let currentKey = x.type.Label.replace(' ', '').toLowerCase();
				switch(x.type.FieldType) {
					case 'Checkbox':
					case 'Radio button':
						if((!('Value' in x) || x.Value === '') && (currentKey in formData)) {
							x.Value = formData[currentKey] === x.OptionLabel;
						}
						break;
					default:
						if((!('Value' in x) || x.Value === '') && (currentKey in formData)) {
							x.Value = formData[currentKey];
						}
						break;
				}
				return x;
			})
		}
		return task;
	}
	return null;
};

export const addTaskComment = async (applicationId: string, taskID: string, userId: string, Message : string) => {
	const application = await db.applications.find(applicationId);
	if (application) {
		const task = findTaskById(application.CandidatePipeline, taskID);
		task.Comments.push({Description: Message, FromUserId: userId, CreatedAt: Date.now()} as IComment);
		return await db.applications.save(application);
	}
	return null;
};

export const completeTask = async (applicationId: string, taskID: string, userId: string) => {
	const application = await db.applications.find(applicationId);
	if (application) {
		const task = findTaskById(application.CandidatePipeline, taskID);
		task.Status = 4;
		const reduceTasks = (tasks : any[]) => tasks.reduce((total, t) => {
			if (t.TaskType === 'Group') {
				return reduceTasks(t.Tasks);
			}
			return [...total, t.Id];
		}, []);
		const sortedTasks = reduceTasks(application.public().CandidatePipeline).sort((a, b) => a.localeCompare(b));
		const sortedIndex = sortedTasks.indexOf(taskID);
		const nextId = sortedTasks.length - 1 > sortedIndex ? sortedTasks[sortedIndex + 1] : null;
		if (nextId) {
			const nextTask = findTaskById(application.CandidatePipeline, nextId);
			nextTask.DueDate = nextTask.Days ? Date.now() + (nextTask.Days * 60 * 60 * 24 * 1000) : Date.now();
		}
		return await db.applications.save(application);
	}
	return null;
};

export const downloadDocumentTask = async (applicationId: string, taskID: string, userId: string) => {
	const application : Application = await db.applications.find(applicationId);
	if (application && application.CandidateId === userId) {
		const documentTask = findTaskById(application.CandidatePipeline, taskID) as IApplicationDocumentTask;
		const filename = `${applicationId}-${taskID}.pdf`;
		const mimetype = 'application/pdf'; // octet-stream
		const file = await awshelper.download(`${documentTask.type}/${documentTask.id}`);
		const filestream = await pdfHelper.createDocumentTaskPDF(documentTask, file);
		return { filename: filename, mimetype: mimetype, filestream: filestream };
	}
	return null;
};

export const updateDocumentTasks = async (applicationId: string, taskID: string, userId: string, details: IApplicationDocumentTask, updateFormData: boolean = false) => {
	const application = await db.applications.find(applicationId) as Application;
	if (application && application.CandidateId === userId) {
		const task = (await findTaskById(application.CandidatePipeline, taskID) as IApplicationDocumentTask);
		task.Components.forEach((todo) => {
			details.Components.forEach((ComponentsUpdate) => {
				if (todo.Id.toString() === ComponentsUpdate.Id.toString()) {
					todo.Value = ComponentsUpdate.Value;
				}
			});
		});
		if(updateFormData) {
			await candidateService.updateSharedFormData(userId, task.Components.reduce((t, x) => {
				switch(x.type.FieldType) {
					case 'Checkbox':
					case 'Radio button':
						if(x.Value === true && 'OptionLabel' in x && x.OptionLabel !== '') {
							t[x.type.Label] = x.OptionLabel;
						}
						break;
					default:
						if(x.Value !== '') {
							t[x.type.Label] = x.Value;
						}
						break;
				}
				return t;
			}, {}));
		}
		if(details.Comments.length !== task.Comments.length) {
			task.Comments = [...task.Comments, ...details.Comments.slice(details.Components.length - task.Comments.length).map(comment => ({
				Description: comment.Description,
				FromUserId: userId,
				CreatedAt: Date.now()
			}) as IComment)];
			if(userId.includes('RecruiterUser') || userId.includes('CompanyUser')) {
				notificationsService.addNotification('Candidate', application.CandidateId, 'Task update', 'just added a comment', userId, `/kanban${application.id}`)
			} else {
				const recruiterId = (await db.accounts.find(userId)).RecruiterId;
				notificationsService.addNotificationsForRecruiterUsers(recruiterId, 'Task update', 'just added a comment', application.CandidateId, `/kanban${application.id}`)
			}
		}
		if ('Files' in details) {
			details.Files.forEach(file => {
				awshelper.upload(application.getFullKey() + '/' + taskID + '/' + file.Name, Buffer.from(awshelper.removeBase64Prefix(file.Contents), 'base64'));
				task.Attachments.push({Name: file.Name, OwnerId: userId} as IAttachment);
			});
		}
		return await db.applications.save(application);
	}
	return null;
};

interface ITaskOrderDetails {
	Id: string,
	Status: string
}

export const updateTaskOrderAndStatus = async (applicationId: string, userId: string, orderArray: ITaskOrderDetails[]) => {
	const application = await db.applications.find(applicationId);
	const findTask = (candidatePipeline: IApplicationTask[], taskId: string) => taskId.split('.').reduce((obj, key) => obj[key], candidatePipeline);
	if (application /*&& application.CandidateId === userId*/) {
		await asyncForEach(orderArray, async (task, i) => {
			const appTask = findTask(application.CandidatePipeline, task.Id);
			application.TaskOrder[task.Id] = i + 1;
			appTask.Status = await mapStatus(task.Status);
		});
		return await db.applications.save(application);
	}
	return null;
};

export const cancelApplication = async (ApplicationId: string, CandidateId: string) => {
	const app = await db.applications.find(ApplicationId);
	if (app && app.CandidateId === CandidateId && checkStatusChange(app.Status, 4)) {
		app.Status = 4;
		app.LastActionBy = CandidateId;
		return await db.applications.save(app);
	}
	return null;
};

export const createTaskOrder = (application: Application) => {
	const TaskOrder = {};
	const getTasks = (array, index) => {
		let i = 0;
		array.forEach((task) => {
			if (task.TaskType === 'Folder') {
				getTasks(task.Tasks, [...index, i]);
			} else {
				TaskOrder[[...index, i].join('.')] = Object.keys(TaskOrder).length;
			}
			i++;
		});
	};
	getTasks(application.CandidatePipeline, []);
	application.TaskOrder = TaskOrder;
	return application;
};

export const acceptApplication = async (applicationId: string, companyId: string, userId: string, pipelineId: string) => {
	const pipeline = await db.pipelines.find(pipelineId);
	let app = await db.applications.find(applicationId);
	if (app === null || pipeline === null) {
		return null;
	}

	async function pipelineToApplication(pipelineVar: Pipeline | IApplicationTask) {
		let TodoList: Todo[];
		let Components: Component[];
		const Tasks: IApplicationTask[] = [];
		let innerTaskId = 0;
		let newTask;
		await asyncForEach(pipelineVar.Tasks, async (pipTask) => {
			innerTaskId = 0;
			const task = ['Todo', 'Document', 'Interview'].includes(pipTask.TaskType)
				? (await db.tasks.find(pipTask.id)).public() : pipTask;
			switch (task.TaskType) {
				case 'Todo':
					newTask = task as TodoTask;
					TodoList = [];
					newTask.TodoList.forEach((todo) => {
						TodoList.push({ Id: innerTaskId, Name: todo, Done: false });
						innerTaskId++;
					});
					newTask.TodoList = TodoList;
					newTask.Attachments = [];
					break;
				case 'Document':
					newTask = task as DocumentTask;
					Components = [];
					newTask.Components.forEach((Component) => {
						Component.Id = innerTaskId;
						Component.Value = '';
						Components.push(Component);
						innerTaskId++;
					});
					newTask.Components = Components;
					break;
				case 'Folder':
					newTask = task as FolderTask;
					newTask.Tasks = pipelineToApplication(newTask);
					break;
				case 'Interview':
					newTask = task as InterviewTask;
					break;
				default:
					break;
			}
			newTask.Comments = [];
			newTask.Status = 1;
			newTask.Source = 1;
			newTask.Days = pipTask.Days;
			newTask.CreatedDate = Date.now();
			newTask.Description = task.Description;
			Tasks.push(newTask as IApplicationTask);
		});
		return Tasks;
	}

	if (checkStatusChange(app.Status, 2)) {
		app.Status = 2;
		app.PipelineId = pipeline.getFullKey();
		const PipTasks = [{
			Name: 'Apply',
			TaskType: 'Default',
			Status: 4,
			Source: 1,
			Tasks: []
		}] as IApplicationTask[];
		app.CandidatePipeline = [...PipTasks, ...(await pipelineToApplication(pipeline))];
		if (app.CandidatePipeline.length > 1) {
		    app.CandidatePipeline[1].DueDate = Date.now() + (app.CandidatePipeline[1].Days * 60 * 60 * 24 * 1000);
        }
		app = createTaskOrder(app);
		app.LastActionBy = userId;
		return await db.applications.save(app);
	}
	return null;
};

export const rejectApplication = async (applicationId: string, companyId: string, userId: string, rejectionReason: string, locale: string) => {
	const app = await getApplicationByIdAndRecruiterId(applicationId, companyId, false);
	if (app === null) {
		return null;
	}
	if (checkStatusChange(app.Status, 3)) {
		await notificationsService.addNotification('Candidate', app.CandidateId, 'Application rejected', `has decided not to progress your application.`, userId, `/kanban/${applicationId}`);
		app.Status = 3;
		app.ActionDate = Date.now();
		app.RejectionReason = rejectionReason;
		return await update(applicationId, app, userId);
	}
	return null;
};

export interface IOfferDetails {
	Salary: number;
	StartDate: string;
	RecruiterCut: string;
	RecruiterUserCut: string;
	RecruiterId: string;
	Negotiate: number;
}

export const giveOfferForApplication = async (applicationId: string, companyId: string, userId: string, offerDetails: IOfferDetails, locale: string, updateType:boolean) => {
	const app = await db.applications.find(applicationId);
	if (app && (checkStatusChange(app.Status, 5) || updateType)) {
		app.Status = 5;
		app.Offer = { ...offerDetails, RecruiterId: userId };
		if (updateType) {
			app.Offer.Negotiate = 2;
		}
		app.ActionDate = Date.now();
		return await update(applicationId, app, userId);
	}
	return null;
};

export const acceptApplicationOffer = async (applicationId: string, userId: string, locale: string) => {
	const app = await db.applications.find(applicationId);
	if (app && app.CandidateId === userId) {
		if (checkStatusChange(app.Status, 6)) {
			app.Status = 6;
			app.ActionDate = Date.now();
			const opening = await db.openings.find(app.OpeningId);
			opening.ReadOnly.VacanciesUnfilled = opening.RequiredCandidates - (await db.applications.newQuery().where('OpeningId', app.OpeningId).count());
			db.openings.save(opening);
			return await update(applicationId, app, userId);
		}
	}
	return null;
};

export const declineApplicationOffer = async (applicationId: string, userId: string, locale: string) => {
	const app = await db.applications.find(applicationId);
	if (app && app.CandidateId === userId) {
		if (checkStatusChange(app.Status, 4)) {
			app.Status = 4;
			app.ActionDate = Date.now();
			return await update(applicationId, app, userId);
		}
	}
	return null;
};

export const negotiateApplicationOffer = async (applicationId: string, user: Account) => {
	const app = await db.applications.with('Opening').where('id', applicationId).first();
	if (app && app.CandidateId === user.id && app.Status === 5) {
		const negotiationChatRoom = {
			Users: [app.Offer.RecruiterId],
			Message: await getMessage(user.Locale, 'I would like to negotiate the salary of ?Salary', app.Offer),
			Subject: await getMessage(user.Locale, 'Negotiation (?)', app.Relations.Opening.Position)
		};
		app.Offer.Negotiate = 1;
		await messagesService.startChatRoom(negotiationChatRoom as any, user.id);
		return await update(applicationId, app, user.id);
	}
	return null;
};
