import AWS = require('aws-sdk');
import config from '../../../config';

// Bucket names must be unique across all S3 users

AWS.config.update({
	accessKeyId: config.s3.accessKeyId,
	secretAccessKey: config.s3.secretAccessKey,
	region: config.s3.region
});
const s3 = new AWS.S3();

export const upload = async (filename: string, file: Buffer) => {
	if (filename !== '') {
		const params = { Bucket: config.s3.bucketName, Key: filename, Body: file };
		return await new Promise((resolve) => {
			s3.putObject(params, (err) => {
				if (err) {
					console.log(err);
					return null;
				}
				resolve(true);
			});
		});
	}
	return null;
};

export const removeBase64Prefix = (filename: string) => {
	if(filename.includes(',')) {
		return filename.split(',')[1];
	}
	return filename;
};

export const download = async (filename: string) : Promise<string> => {
	if (filename !== '') {
		const params = { Bucket: config.s3.bucketName, Key: filename };
		return await new Promise((resolve) => {
			s3.getObject(params, (err, data) => {
				if (err) {
					console.log(err);
					resolve(null);
				}
				if (data) {
					resolve(data.Body.toString('utf-8'));
				} else {
					resolve(null);
				}
			});
		});
	}
	return null;
};

// s3.listObjects({ Bucket: config.s3.bucketName }, (err, data) => {
// 	if (err) {
// 		console.log(err);
// 		return null;
// 	}
// 	return data;
// });
