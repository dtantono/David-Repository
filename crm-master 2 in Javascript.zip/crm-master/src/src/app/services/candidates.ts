import { Account } from '../models/Account';
import { Candidate } from '../models/Candidate';
import { getRecruiterById, getAccountByRecruiterAndCandidate } from './recruiters';
import * as bcrypt from 'bcrypt';
import { Tag } from '../models/GlobalClasses';
import * as db from '../db/database';
import { ResultSet } from '../db/DatabaseModule/ListTypes';
import config from '../../../config';
import { Recruiter } from '../models/Recruiter';
import {IPagination} from "../helpers/paginate";
import {arrayToCouchbaseArray} from "../db/DatabaseModule/Helper";
import * as cache from '../helpers/cache';
import {removePunctuation} from "./ai";
import {RecruiterUser} from "../models/RecruiterUser";
import {CompanyUserWithRecruiterId} from "../models/CompanyUser";
import {Resume} from "../models/Resume";

const MAX_SCORE = 10;

export const getActiveAccount = async (candidateId: string): Promise<Account> => {
	let account = await db.accounts.newQuery().where('AccountEntityId', candidateId).where('Active', true).first();
	if (!account) {
		account = await db.accounts.newQuery().where('AccountEntityId', candidateId).first();
		if(account) {
			account.Active = true;
			await db.accounts.save(account);
		}
	}
	return account;
};
export const saveAccount = async (relation: Account): Promise<any> => db.accounts.save(relation);
export const getAccountById = async (AccountId: string): Promise<Account> => db.accounts.find(AccountId);
export const getAllAccounts = async (candidateId: string) => (await db.accounts.with('Recruiter').where('AccountEntityId', candidateId).get() as ResultSet<Account>).public()
	.map((x : any) => ({...x, Recruiter: {...x.Recruiter, Picture: x.Recruiter.Picture === '' ? '' : `${config.s3.url}${x.Recruiter.Picture}`}}));
export const getCandidateByEmailAddress = async (EmailAddress: string): Promise<Candidate> => db.candidates.newQuery().where('EmailAddress', EmailAddress).first();

export const resetPassword = async (candidate: Candidate, password: string) => {
	candidate.HashPassword = bcrypt.hashSync(password, 10);
	candidate.ResetPasswordToken = '';
	return await db.candidates.save(candidate);
};

export const getAccountByInvitationKey = async (InvitationKey: string) : Promise<Account> => db.accounts.newQuery(false).where('InvitationKey', InvitationKey).first();

export async function createAccount(candidateId: string, RecruiterId: string, InvitationKey : string = null, deleted : boolean = false): Promise<Account> {
	let candidateAccount = candidateId ? await getAccountByRecruiterAndCandidate(RecruiterId, candidateId) : null;
	if(!candidateAccount) {
		candidateAccount = new Account();
		candidateAccount.fill({
			RecruiterId: RecruiterId,
			AccountEntityId: candidateId,
			CandidateCode: '',
			DeletedAt: deleted ? Date.now() : 0
		} as Account);

		if (InvitationKey) {
			candidateAccount.InvitationKey = InvitationKey;
		}

		const promises: any = [getRecruiterById(RecruiterId, false), db.accounts.newQuery().where('RecruiterId', RecruiterId).count()];
		await Promise.all(promises).then(async (values) => {
			candidateAccount.CandidateCode = `${(values[0] as Recruiter).RecruiterCode}-${(`0000${(values[1] as number) + 1}`).slice(-5)}`;
			// insert the relation model in the database
			await db.accounts.save(candidateAccount);
		});
	}

	return candidateAccount;
}

export interface TagQuery {
	MatchScore: number,
	resume: {
		Tags: Tag[]
	}
}

export async function getCandidatesByTags(tagsArr: Tag[], recruiterId: string) {
	const tags = tagsArr.map((x) => x.name);
	const tagsArray =  arrayToCouchbaseArray(tags);
	const query = `SELECT candidate.*, resume
	FROM ${config.DATABASE.NAME} resume
	LEFT JOIN ${config.DATABASE.NAME} account on keys resume.UserId
	LEFT JOIN ${config.DATABASE.NAME} candidate on keys account.AccountEntityId
	WHERE resume.type = 'Resume'
	and account.RecruiterId = '${recruiterId}'
	and resume.Default = true
	and resume.DeletedAt = 0
    and resume is not missing
	and resume.Tags is not missing
	and candidate is not missing
	ORDER BY ARRAY_LENGTH(ARRAY_INTERSECT(ARRAY x.name FOR x in resume.Tags END, ${tagsArray})) DESC
	LIMIT 10`;
	const candidateList = (await db.candidates.newQuery().executeQuery(query) as object[]) as TagQuery[];

	for (let index = 0; index < candidateList.length; index++) {
		candidateList[index].MatchScore = 0;
		for (let t = 0; t < candidateList[index].resume.Tags.length; t++) {
			if (tags.includes(candidateList[index].resume.Tags[t].name)) {
				candidateList[index].MatchScore += candidateList[index].resume.Tags[t].value;
			}
		}
		if (candidateList[index].MatchScore > MAX_SCORE) {
			candidateList[index].MatchScore = MAX_SCORE;
		}
		candidateList[index].MatchScore /= MAX_SCORE;
		candidateList[index].MatchScore = parseFloat((candidateList[index].MatchScore * 100).toPrecision(3));
		delete candidateList[index].resume.Tags;
	}
	candidateList.sort((a, b) => b.MatchScore - a.MatchScore);
	return candidateList;
}

export const register = async (details) => {
	const newCandidate = new Candidate();
	details = { ...details.PersonalInformation, ...details.Account };
	newCandidate.fill(details);
	newCandidate.HashPassword = bcrypt.hashSync(details.Password, 10);
	// enter into the database
	await db.candidates.save(newCandidate);
	return newCandidate;
};

export const saveCandidate = (candidate: Candidate) => db.candidates.save(candidate);

export async function getThirdPartyUser(ThirdPartyId: string, ThirdPartyType: string) {
	return await db.candidates.newQuery().where('ThirdPartyId', ThirdPartyId).where('ThirdPartyType', ThirdPartyType).first();
}

export async function getCandidateById(id: string, format: boolean) {
	const data = await db.candidates.find(id);
	if (data) {
		return format ? data.public('HashPassword') : data;
	}
	return null;
}
interface IRange {
	From: number, To: number
}
interface IAdvancedSearch {
	Salary: IRange,
	JobTitle: string[],
	Skills: string[]
}

export const markCandidateAsBookmarked = (candidates: Resume[], account: RecruiterUser |CompanyUserWithRecruiterId) =>
	candidates.map(c => ({...c, Bookmarked: account.BookmarkedCandidates.includes(c.UserId.replace('Account/', ''))}));

export async function getCandidateByAccountId(accountId: string) {
	const account = await db.accounts.with('Candidate').where('id', accountId).first();
	const newCandidate = new Candidate();
	newCandidate.fill(account.Relations.Candidate);
	return newCandidate;
}

export const getSharedFormData = async (userId: string) => {
	const user = await getCandidateByAccountId(userId);
	const data = {...user, ...user.FormData};
	return Object.keys(data).reduce((t, x) => {
		t[x.toLowerCase()] = data[x];
		return t;
	}, {});
};

export const updateSharedFormData = async (userId: string, data: object) => {
	console.log(data);
	const user = await getCandidateByAccountId(userId);
	const keys = Object.keys(user).map(x => x.toLowerCase());
	const toStore = Object.keys(data).reduce((t, x) => {
		const currentKey = x.replace(' ', '');
		if(!keys.includes(currentKey) && data[x] !== ''){
			t[currentKey] = data[x];
		}
		return t;
	}, {});

	user.FormData = {...user.FormData, ...toStore};
	return await db.candidates.save(user);
};

export const getCandidatesByRecruiterId = async (RecruiterId: string) =>
	db.accounts.with('Candidate').where('RecruiterId', RecruiterId, undefined, 'Account').get();


export async function searchCandidatesByRecruiterId(RecruiterId: string, paginate: IPagination = null, tags: string[] = null,
                                                    format: boolean = true, salary: IRange = null, bookmarkAccount: RecruiterUser | CompanyUserWithRecruiterId = null, bookmarked: boolean = false) {
	const unwantedProperties = ['Candidate.Personality', 'Account', 'Candidate.HashPassword', 'Tags'];
	let query = db.resumes.with('Account').leftJoin('Account', 'Candidate', 'AccountEntityId')
		.where('Default', true).where('RecruiterId', RecruiterId, undefined, 'Account');
	if(bookmarked && bookmarkAccount) {
		query.where('UserId', bookmarkAccount.BookmarkedCandidates.map(x => `Account/${x}`), 'in');
	}
	if(tags && tags.length > 0) {
		tags = tags.map(x => removePunctuation(x));
		query = query.whereGroup((x => {
			x.whereAny('Tags', tags, 'in', 'name');
			x.orWhere('FirstName', tags, 'in', 'Candidate');
			x.orWhere('LastName', tags, 'in', 'Candidate');
		}));

		query = query.orderByRaw(`ARRAY_LENGTH(ARRAY_INTERSECT(ARRAY x.name FOR x in Resume.Tags END, ${arrayToCouchbaseArray(tags)}))`, false);
	}
	if(salary) {
		query = query.where('DesiredSalary', salary.To, '<=').where('DesiredSalary', salary.From, '>=');
	}
	let res : any = (await query.get());
	res = format ? res.public(...unwantedProperties) : res;
	if(bookmarkAccount) {
		res = markCandidateAsBookmarked(res, bookmarkAccount);
	}
	return res.map(x => ({...x, Candidate: {...x.Candidate, ProfilePicture: x.Candidate.ProfilePicture === '' ? '': `${config.s3.url}${x.Candidate.ProfilePicture}` } }));
}

export async function advancedSearchCandidates(RecruiterId, paginate, searchParams : IAdvancedSearch) {
	const jobTitleArray = searchParams.JobTitle.reduce((total : string[], jobTitle : string) => [...total, ...jobTitle.split(' ')], []);
	const skillsArray = searchParams.Skills.reduce((total : string[], skill : string) => [...total, ...skill.split(' ')], []);
	return searchCandidatesByRecruiterId(RecruiterId, paginate, [...skillsArray, ...jobTitleArray], true, searchParams.Salary);
}

export async function updateCandidateById(id: string, isAccountId: boolean, details: any): Promise<Candidate> {
	await cache.remove(id, 'profile');
	await cache.remove(id, 'dashboard');

	const candidate = isAccountId ? await getCandidateByAccountId(id) : await db.candidates.find(id);
	const picture = details.ProfilePicture;
	delete details.ProfilePicture;
	candidate.fill(details);
	// enter into the database
	await candidate.updatePicture(picture);
	if(await db.candidates.save(candidate)) {
		return candidate;
	}
	return null;
}

export async function updatePersonalityQuestions(CandidateId: string, body) {
	const candidate = await db.candidates.find(CandidateId);
	candidate.Personality = body;
	await db.candidates.save(candidate);
}

export async function getPersonalityQuestions(CandidateId: string) {
	const candidate = await db.candidates.find(CandidateId);
	return candidate.Personality;
}
export async function getRecentCandidatesByRecruiter(RecruiterId: string) {
	const unwantedProperties = ['Candidate.Personality', 'Candidate.HashPassword'];
	let query = await db.accounts.with('Candidate').where('RecruiterId', RecruiterId).limit(5).orderBy('Account.CreatedAt', false).get();
	return query.public(...unwantedProperties);
}
export async function getCandidateByIdAndRecruiterId(RecruiterId: string, candidateId: string) {
	const data = await db.accounts.with('Candidate').where('RecruiterId', RecruiterId).where('CandidateId', candidateId).first();
	if (data) {
		return data.Relations.Candidate;
	}
	return null;
}
