import { CompanyUser } from '../models/CompanyUser';
import * as db from '../db/database';
import * as openingService from './openings';
import { Opening } from '../models/Opening';
import { Company } from '../models/Company';
import { ResultSet } from '../db/DatabaseModule/ListTypes';
import {
	getAdminRecruiter,
	getRecruiterById,
	IRecruiterRegister,
	saveAccount,
	updateUsersTeamGeneral
} from "./recruiters";
import {ITeam} from "../models/GlobalClasses";
import {RecruiterUser} from "../models/RecruiterUser";
import {validate} from "../helpers/validation/Validation";

const bcrypt = require('bcrypt');

export const createMember = async (companyId, details, invitationKey : string = null, invitationType : string = null) => {
	// Make the admin user
	const newUser = new CompanyUser();
	await newUser.fill(details);
	if (details.Password) {
		newUser.HashPassword = bcrypt.hashSync(details.Password, 10);
	}
	newUser.CompanyId = invitationType === 'Company' ? null : companyId;
	if(invitationKey && invitationType) {
		newUser.InvitationKey = invitationKey;
		newUser.InvitationType = invitationType;
	}
	// enter into the database
	await db.companyUsers.save(newUser);
	return newUser;
};

export const getCompanyById = async (CompanyId) => await db.companies.find(CompanyId);
export const updateCompanyById = async (CompanyId: string, details) => {
	const data = await db.companies.find(CompanyId);
	const recruiterId = data.RecruiterId;
	if (data) {
		data.fill(details);
		data.RecruiterId = recruiterId;
		await data.updatePicture();
		// enter into the database
		return await db.companies.save(data);
	}
	return null;
};
export const getCompanyUsersByCompanyId = async (companyId : string) => {
	const company = await getCompanyById(companyId);
	return (await db.companyUsers.newQuery().where('CompanyId', companyId).orderBy('FirstName').get()).public('HashPassword').map(u => {
		return {...u, Teams: company.Teams.filter(t => t.Members.includes(`${u.type}/${u.id}`)).map(t => t.Name)}
	});
};

export const updateUsersTeams = async (details: string[], companyUserId: string, companyId: string ) => {
	const companyUser = await db.companyUsers.find(companyUserId);
	if (companyUser && companyUser.CompanyId === companyId) {
		return await updateUsersTeamGeneral(details, companyUserId, companyId, db.companies);
	}
	return null;
};

export const createTeam = async (details: ITeam, companyId: string) => {
	const company = await db.companies.find(companyId);
	details.Members = details.Members.map(m => m.includes('CompanyUser') ? m : `CompanyUser/${m}`);
	company.Teams.push(details);
	return await db.companies.save(company);
};

export const getTeams = async (companyId: string) => {
	const company = await db.companies.find(companyId);
	return company ? company.Teams : null;
};

export const getCompanyWithOpeningsById = async (CompanyId) => {
	const promises = [];
	promises.push(db.companies.find(CompanyId));
	promises.push(openingService.getOpeningsByCompanyId(`Company/${CompanyId}`));
	promises.push(getCompanyUsersByCompanyId(`Company/${CompanyId}`));
	let data : any = {};
	await Promise.all(promises).then((values : any) => {
		data = (values[0] as Company).public();
		data.Opening = values[1];
		data.Team = values[2]
	});
	return data;
};

export const getCompanyUserByEmailAddress = async (email) => await db.companyUsers.newQuery().where('EmailAddress', email).where('Active', true).first();
export const getCompanyUserByEmailAddressWithCompany = async (email) => await db.companyUsers.with('Company').where('EmailAddress', email).where('Active', true).first();


export const updateCompanyUserById = async (userId, details) => {
	const user = await db.companyUsers.find(userId);
	if (user && details) {
		const picture = details.ProfilePicture;
		delete details.ProfilePicture;
		user.fill(details);
		// enter into the database
		await user.updatePicture(picture);
		if('Password' in details) {
			user.updatePassword(details.Password);
		}
		if(await db.companyUsers.save(user)) {
			return user;
		}
	}
	return null;
};

export const saveCompanyUser = (user: CompanyUser) => db.companyUsers.save(user);
export const getCompanyUserById = async (id : string, format : boolean) => {
	const user = await db.companyUsers.find(id);
	return user && format ? user.public() : user;
};
export const bookmarkCandidate = async(userId: string, candidateId: string) => {
	const account = await getCompanyUserById(userId, false);
	const candidateIndex = account.BookmarkedCandidates.indexOf(candidateId);
	if(candidateIndex === -1) {
		account.BookmarkedCandidates.push(candidateId);
	} else {
		account.BookmarkedCandidates.splice(candidateIndex, 1);
	}
	return saveCompanyUser(account);
};


export const resetPassword = async (user: CompanyUser, password: string) => {
	user.updatePassword(password);
	return await db.companyUsers.save(user);
};

export const getCompaniesByRecruiterId = async (id, searchTerm) => {
	let data = null;
	if (searchTerm === undefined) {
		data = await db.companies.newQuery().where('RecruiterId', id).get();
	} else {
		data = await db.companies.newQuery().where('RecruiterId', id).where('CompanyName', searchTerm, 'LIKE').get();
	}
	return data.public();
};

export const registerCompany = async (details : IRecruiterRegister, InviteKey : string = null): Promise<CompanyUser> => {
	const newCompany = new Company();
	const companyPicture = details.CompanyAdditional.ProfilePicture;
	newCompany.fill({...details.Company, ...details.CompanyAdditional});
	await newCompany.updatePicture(companyPicture);

	let newCompanyUser : CompanyUser = null;
	if(InviteKey) {
		newCompanyUser = await db.companyUsers.newQuery().where('InvitationKey', InviteKey).first();
		newCompany.RecruiterId = `${newCompanyUser.CompanyId}`;
	}
	if(!newCompanyUser) {
		newCompanyUser = new CompanyUser();
		newCompany.RecruiterId = (await getAdminRecruiter()).getFullKey();
	}
	const companyUserPicture = details.Personal.ProfilePicture;
	await newCompanyUser.fill({ ...details.Signup, ...details.Personal });
	newCompanyUser.Role = 1;
	newCompanyUser.Active = true;
	newCompanyUser.CompanyId = newCompany.getFullKey();
	newCompanyUser.updatePassword(details.Signup.Password);

	await newCompanyUser.updatePicture(companyUserPicture);
	await db.companies.save(newCompany);
	await db.companyUsers.save(newCompanyUser);
	return newCompanyUser;
};