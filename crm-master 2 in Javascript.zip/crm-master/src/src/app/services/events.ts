import {Event} from '../models/Event';
import * as db from '../db/database';
import {addUsersToModel, getContacts} from "./messages";
import {Account} from "../models/Account";
import * as cache from '../helpers/cache';
import {RecruiterUser} from "../models/RecruiterUser";
import {CompanyUser} from "../models/CompanyUser";

export const create = async (details, UserId : string) => {
	details.Users = [...details.Users, UserId];
	const newEvent = new Event();
	await newEvent.fill(details);
	newEvent.UserId = UserId;
	// enter into the database
	cache.remove(UserId, 'dashboard');
	await db.events.save(newEvent);
	return true;
};

export const getEventsByUser = async (user: Account | RecruiterUser | CompanyUser) => {
	const contacts = await getContacts(user, true);
	const data = await db.events.newQuery().where('UserId', user.id).get();
	return data.public().map(x => addUsersToModel(x, contacts)).map(x => ({...x, Users: x.Contacts}));
};

export const getEventsByIdAndUserId = async (id, user: Account | RecruiterUser | CompanyUser) => {
	const event = await db.events.find(id);
	if (event && event.UserId === user.id) {
		const contacts = await getContacts(user, true);
		let result = addUsersToModel(event, contacts);
		result.Users = result.Contacts;
		return result;
	}
	return null;
};

export const updateEvent = async (id, details, UserId) => {
	const event = await db.events.find(id);
	if (event && event.UserId === UserId) {
		await event.fill(details);
		cache.remove(UserId, 'dashboard');
		return await db.events.save(event);
	}
	return null;
};

export const deleteEvent = async (id, UserId) => {
	const event = await db.events.find(id);
	if (event && event.UserId === UserId) {
		cache.remove(UserId, 'dashboard');
		return await db.events.delete(event);
	}
	return null;
};
