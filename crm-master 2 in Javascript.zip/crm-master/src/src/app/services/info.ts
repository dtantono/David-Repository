import * as db from '../db/database';
import { MasterData } from '../db/referencedata';
import mcache = require('memory-cache');
import refData = require('../db/referencedata');

import config from '../../../config';
const refCacheKey = 'reference-data';
const skillsCacheKey = 'skills-data';
const positionsCacheKey = 'positions-data';
const duration = 24 * 60 * 60 * 1000; // 24 hours, calculated in milliseconds

export const getCacheRefData = async (query, key) => {
	const cachedBody = mcache.get(key);
	if (cachedBody) {
		return cachedBody;
	}
	const body = await db.openings.newQuery().executeQuery(query, false);
	mcache.put(key, body, duration);
	return body;
};

export const getSkills = async () => {
	const query = `SELECT DISTINCT item.SkillName as name FROM ${config.DATABASE.NAME} UNNEST FeatureSkills AS item`;
	return getCacheRefData(query, skillsCacheKey);
};

export const getCommonJobTitles = async () => {
	const query = `SELECT Position as name, count(*) FROM ${config.DATABASE.NAME}
	where Position is not missing
	group by Position
	order by count(*) desc
	limit 1000`;
	return getCacheRefData(query, positionsCacheKey);
};

export const getReferenceData = async (): Promise<MasterData> => {
	const cachedBody = mcache.get(refCacheKey);
	if (cachedBody) {
		return cachedBody;
	}
	const body = refData.ReferenceData;
	const skillArray = await getSkills();
	body.FeatureSkills = { ...skillArray, ...body.FeatureSkills };
	body.JobTitles = await getCommonJobTitles();
	mcache.put(refCacheKey, body, duration);
	return body;
};

export const jsonToNameValue = (json, locale = 'en') => {
	const newArray = [];
	for (const key in json) {
		if (json.hasOwnProperty(key)) {
			const other = Object.assign({}, json[key]);
			locale = locale in other ? locale : 'en';
			delete other[locale === 'en' ? 'name' : locale];
			newArray.push({ name: locale === 'en' ? json[key].name : json[key][locale], value: key, other: other });
		}
	}
	return newArray;
};

export const getNameValue = async (json) => {
	const newObject = {};
	for (const key in json) {
		if (json.hasOwnProperty(key)) {
			newObject[key] = jsonToNameValue(json[key]);
		}
	}
	return newObject;
};
export const getKeyValue = async () => {
	const json = await getReferenceData();
	const newObject = {};
	for (const key in json) {
		if (json.hasOwnProperty(key)) {
			newObject[key] = {};
			for (const keyChild in json[key]) {
				if (json[key].hasOwnProperty(keyChild)) {
					newObject[key][json[key][keyChild].name] = json[key][keyChild];
				}
			}
		}
	}
	return newObject as MasterData;
};
export const getValueKey = async () => {
	const json = await getReferenceData();
	const newObject = {};
	for (const key in json) {
		if (json.hasOwnProperty(key)) {
			newObject[key] = {};
			for (const keyChild in json[key]) {
				if (json[key].hasOwnProperty(keyChild)) {
					newObject[key][keyChild] = json[key][keyChild].name;
				}
			}
		}
	}
	return newObject;
};

export const getArray = async () => {
	const json = await getReferenceData();
	const newObject = {};
	for (const key in json) {
		if (json.hasOwnProperty(key)) {
			newObject[key] = [];
			for (const keyChild in json[key]) {
				if (json[key].hasOwnProperty(keyChild)) {
					if(key === 'Cities') {
						for (const keyChildChild in json[key][keyChild]) {
							if (json[key][keyChild].hasOwnProperty(keyChildChild)) {
								newObject[key].push(keyChildChild);
							}
						}
					} else {
						newObject[key].push(keyChild);
					}
				}
			}
		}
	}
	return newObject;
};
