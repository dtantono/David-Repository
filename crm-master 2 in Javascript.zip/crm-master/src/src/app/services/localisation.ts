import en from '../assets/locales/en';
import ja from '../assets/locales/ja';
import * as db from '../db/database';
import * as cache from '../helpers/cache';
import {Localisation} from "../models/Localisation";

// This will turn CamelCase into spaced lowercase
const normaliseWords = (words : any) => words.toString().replace(/([A-Z])/g, ' $1').toLowerCase().trim();

export const getAll = async () : Promise<Localisation> => {
	let words = await cache.get('locale', 'translations');
	if(!words) {
		words = (await db.localisation.all()).first();
		cache.put('locale', 'translations', words);
	}
	return words;
};

interface IWordDefinition {
	en: string, ja: string
}

export const createWord = async (wordToCreate: string, definitions: IWordDefinition = null) => {
	const allWords = await getAll();
	const word = wordToCreate;
	const en = definitions && 'en' in definitions ? definitions.en : word;
	const ja = definitions && 'ja' in definitions ? definitions.ja : word;
	if ((word.toLowerCase() in allWords.Words)) {
		allWords.Words[word.toLowerCase()].date = Date.now();
	} else {
		allWords.Words[word.toLowerCase()] = {en, ja, date: Date.now()};
	}

	cache.put('locale', 'translations', allWords);
	await db.localisation.save(allWords);
	return allWords.Words[word.toLowerCase()];
};
export const updateWord = async (wordToCreate: string, definitions: IWordDefinition = null) => {
	const allWords = await getAll();
	const word = wordToCreate;
	const en = definitions && 'en' in definitions ? definitions.en : word;
	const ja = definitions && 'ja' in definitions ? definitions.ja : word;
	if ((word.toLowerCase() in allWords.Words)) {
		allWords.Words[word.toLowerCase()] = {...allWords.Words[word.toLowerCase()], en, ja};
	} else {
		allWords.Words[word.toLowerCase()] = {en, ja, date: Date.now()};
	}
	allWords.Words[word.toLowerCase()] = { en, ja };
	cache.put('locale', 'translations', allWords);
	await db.localisation.save(allWords);
	return allWords.Words[word.toLowerCase()];
};

export const deleteWord = async (wordToCreate: string) => {
	const allWords = await getAll();
	const word = wordToCreate;
	delete allWords.Words[word.toLowerCase()];
	cache.put('locale', 'translations', allWords);
	await db.localisation.save(allWords);
	return true;
};

export const getMessage = async (locale: string, messageId: string, replaceVal : string | object = null, normalise : boolean = true) => {
	const allWords = await getAll();
	if (messageId.toLowerCase() in allWords.Words) {
		let message = allWords.Words[messageId.toLowerCase()][locale];
		if (replaceVal) {
			if (replaceVal.constructor === String) {
				return message.replace('?', normaliseWords(replaceVal as string));
			} else {
				// replace val is an object
				Object.keys(replaceVal).forEach((key) => message = message.replace(`?${key}`, normalise ? normaliseWords(replaceVal[key]) : replaceVal[key]));
			}
		}
		return message;
	}
	return (await createWord(messageId))[locale];
};

