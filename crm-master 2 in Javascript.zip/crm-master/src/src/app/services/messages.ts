import {ChatRoom, mapMessagePaths, Message, Template} from '../models/ChatRoom';
import * as pdfHelper from '../helpers/pdf';
import * as db from '../db/database';
import { Account } from '../models/Account';
import pusher = require('./pusher');
import awshelper = require('./aws');
import {IFile} from "../models/Pipeline";
import {RecruiterUser} from "../models/RecruiterUser";
import * as candidateService from './candidates';
import {Event} from "../models/Event";
import {CompanyUser} from "../models/CompanyUser";
import * as companyService from "./companies";
import config from '../../../config';

export const deleteChatRoom = async (ChatRoomId: string) => db.chatRooms.delete(await db.chatRooms.find(ChatRoomId));
export const archiveChatRoom = async (ChatRoomId: string) => {
	const room = await db.chatRooms.find(ChatRoomId);
	room.Archived = true;
	return await db.chatRooms.save(room);
};

interface ISelfContact {
	FirstName: string;
	LastName: string;
	EmailAddress: string;
	ProfilePicture: string;
}

export interface IFullContact extends ISelfContact {
	id: string;
	Recruiter: string;
}

export const getSharedContacts = async (self: ISelfContact, id: string, recruiterId: string) : Promise<IFullContact[]>  => {
	const recruiterContacts = await db.recruiterUsers.with('Recruiter').where('id', recruiterId, undefined, 'Recruiter').get();
	const companyContacts = await db.companyUsers.with('Company').where('RecruiterId', recruiterId, undefined, 'Company').get();
	const contacts : IFullContact[] = [...recruiterContacts, ...companyContacts].map((contact) => ({
		id: contact.getFullKey(),
		FirstName: contact.FirstName,
		LastName: contact.LastName,
		EmailAddress: contact.EmailAddress,
		Recruiter: contact.type === 'RecruiterUser' ? contact.Relations.Recruiter.RecruiterName : contact.Relations.Company.CompanyName,
		ProfilePicture: contact.ProfilePicture === '' ? '' : `${config.s3.url}${contact.ProfilePicture}`,
	}));
	if(self) {
		contacts.push({
			id: id,
			FirstName: self.FirstName,
			LastName: self.LastName,
			EmailAddress: self.EmailAddress,
			ProfilePicture: self.ProfilePicture === '' ? '' : `${config.s3.url}${self.ProfilePicture}`,
			Recruiter: ''
		} as IFullContact);
	}
	return contacts;
};

export const getCandidateContacts = async (user : Account, withSelf : boolean = false) : Promise<IFullContact[]> => {
	const getSelf = withSelf ? await db.candidates.find(user.AccountEntityId) : null;
	return await getSharedContacts(getSelf, user.id, user.RecruiterId);
};

export const getRecruiterUserContacts = async (user : RecruiterUser) : Promise<IFullContact[]> => {
	const candidates : IFullContact[] = (await candidateService.getCandidatesByRecruiterId(user.RecruiterId)).map((account: Account) => ({
		FirstName: account.Relations.Candidate.FirstName,
		LastName: account.Relations.Candidate.LastName,
		EmailAddress: account.Relations.Candidate.EmailAddress,
		ProfilePicture: account.Relations.Candidate.ProfilePicture === '' ? '' : `${config.s3.url}${account.Relations.Candidate.ProfilePicture}`,
		id: account.getFullKey(),
		Recruiter: ''
	} as IFullContact));
	return [...await getSharedContacts(null, user.id, user.RecruiterId), ...candidates];
};
export const getCompanyUserContacts = async (user : CompanyUser) : Promise<IFullContact[]> => {
	const companyUsers : IFullContact[] = (await companyService.getCompanyUsersByCompanyId(user.CompanyId)).map(companyUser => ({
		FirstName: companyUser.FirstName,
		LastName: companyUser.LastName,
		EmailAddress: companyUser.EmailAddress,
		ProfilePicture: companyUser.ProfilePicture === '' ? '' : `${config.s3.url}${companyUser.ProfilePicture}`,
		id: `${companyUser.type}/${companyUser.id}`,
		Recruiter: ''
	} as IFullContact));
	return [...await getSharedContacts(null, user.id, user.Relations.Company.RecruiterId), ...companyUsers];
};

export const getContacts = async (user : Account | RecruiterUser | CompanyUser, withSelf: boolean = false) : Promise<IFullContact[]> => {
	switch(user.type) {
		case 'Candidate':
		case 'Account':
			return getCandidateContacts(user as Account, withSelf);
		case 'Recruiter':
			return getRecruiterUserContacts(user as RecruiterUser);
		case 'Company':
			return getCompanyUserContacts(user as CompanyUser);
		default:
			return null;
	}
};

export function addUsersToModel(model : ChatRoom | Event | any, contacts : IFullContact[]) {
	model.Contacts = model.Users.map((user) => ({
		UserId: user,
		Details: contacts.filter((contact) => contact.id === user)
	}));
	model.Contacts = model.Contacts.filter((contact) => contact.Details.length > 0).map((contact) => ({
		UserId: contact.UserId,
		Details: contact.Details[0]
	}));
	const getContactDetail = (message) => {
		const contactsFiltered = model.Contacts.filter((contact) => message.FromUserId === contact.UserId);
		const contact = contactsFiltered.length ? contactsFiltered[0] : null;
		if (contact && contact.hasOwnProperty('Details')) {
			return contact.Details;
		}
		return null;
	};
	if('Messages' in model && model.Messages.constructor === Array) {
		model.Messages = model.Messages.map((message) => ({...message, ...{FromUser: getContactDetail(message)}}));
	}
	return model;
}

export const getArchivedChatRoom = async (user: Account | CompanyUser | RecruiterUser) => {
	const rooms = await db.chatRooms.newQuery().whereAny('Users', user.id).where('Archived', true).get();
	const contacts = await getContacts(user, true);
	return rooms.map((room) => addUsersToModel(room, contacts));
};

export const getDeletedChatRooms = async (user: Account | CompanyUser | RecruiterUser) => {
	const rooms = await db.chatRooms.newQuery(false, true).whereAny('Users', user.id).get();
	const contacts = await getContacts(user, true);
	return rooms.map((room) => addUsersToModel(room, contacts));
};

export const getMessages = async (chatRoomID: string, paginate: object, user: Account | CompanyUser | RecruiterUser) => {
	const contacts = await getContacts(user, true);
	let messages = await db.chatRooms.newQuery().where('id', chatRoomID).whereAny('Users', user.id).unnest('Messages').select('Messages').get(false) as any; // todo pagination await database.getByFields({}, type, null, { Messages: 'Messages' }, { limit: 20, offset: 0 }, { 'chatRoom.Users': user.id });
	messages = messages.map((message) => ({ ...message.Messages, ...{ FromUser: contacts.filter((contact) => message.Messages.FromUserId === contact.id)[0] } }));
	messages = mapMessagePaths(messages, `ChatRoom/${chatRoomID}`);
	return { data: messages };
};

export const printChatRoom = async (ChatRoomId: string, user: Account | CompanyUser | RecruiterUser) => {
	const messages = await getMessages(ChatRoomId, null, user);
	const filename = `${ChatRoomId}.pdf`;
	const mimetype = 'application/pdf'; // octet-stream
	const filestream = await pdfHelper.createMessagesExportFromTemplate({ Messages: messages.data });
	return { filename: filename, mimetype: mimetype, filestream: filestream };
};

interface ChatRoomDetails {
	Users: string[],
	Message: string,
	Subject: string,
	GroupName: string,
	Color: string,
	Template: string
}

export const createTemplate = async (message: string, userId: string) => {
	const template = new Template();
	template.fill({ Message: message, UserId: userId });
	return await db.templates.save(template);
};

export const startChatRoom = async (details: ChatRoomDetails, starter: string) => {
	const chatRoom = new ChatRoom();
	chatRoom.fill({
		Users: [starter, ...details.Users], Starter: starter, Messages:
			[{ Description: details.Message, FromUserId: starter, CreatedAt: Date.now() } as Message],
		RoomName: details.Subject, GroupName: details.GroupName, Color: details.Color
	} as ChatRoom);
	if (details.Template) {
		await createTemplate(details.Message, starter);
	}
	await db.chatRooms.save(chatRoom);
	console.log(chatRoom);
	return chatRoom.getKey();
};
export const addMessage = async (chatRoomID: string, userId: string, message: string, attachment: IFile = null) => {
	const chatRoom = await db.chatRooms.find(chatRoomID);
	if (chatRoom && chatRoom.Users.includes(userId)) {
		const msg = { Description: message, FromUserId: userId, CreatedAt: Date.now() } as Message;
		if (attachment) {
			awshelper.upload(chatRoom.getFullKey() + '/' + attachment.Name, Buffer.from(awshelper.removeBase64Prefix(attachment.Contents), 'base64'));
			msg.Attachment = {Name: attachment.Name};
		}
		chatRoom.Messages.push(msg);
		await db.chatRooms.save(chatRoom);
		chatRoom.Users.forEach((user) => {
			if (user !== userId) {
				try {
					pusher.trigger(msg, user);
				} catch (err) {
					console.log(err);
				}
			}
		});
		return true;
	}
	return null;
};
export const inviteUser = async (chatRoomID: string, userId: string) => {
	const chatRoom = await db.chatRooms.find(chatRoomID);
	chatRoom.Users.push(userId);
	await db.chatRooms.save(chatRoom);
};

export const getChatRooms = async (user: Account | RecruiterUser | CompanyUser) => {
	const contacts = await getContacts(user, true);
	const chatrooms = db.chatRooms.newQuery().whereAny('Users', user.id).where('Archived', false).get();
	let result = null;
	await Promise.all([chatrooms, contacts]).then((values) => {

		if (values[0]) {
			result = values[0].map((chatRoom) => {
				const newChatRoom = chatRoom.public();
				newChatRoom.Messages.sort((a, b) => b.CreatedAt - a.CreatedAt);
				newChatRoom.Messages = newChatRoom.Messages.slice(0, 5);
				return addUsersToModel(newChatRoom, values[1]);
			});
			result.sort((b, a) => a.Messages[a.Messages.length - 1].CreatedAt - b.Messages[b.Messages.length - 1].CreatedAt);
		}
	});
	return result;
};

export const getLatestMessages = (user :  Account | RecruiterUser | CompanyUser) => db.chatRooms.newQuery()
	.whereAny('Users', `${user.type}/${user.id}`).unnest('Messages')
	.select('Messages', 'ChatRoom.id', 'ChatRoom.RoomName')
	.get(false) as any; // todo pagination await database.getByFields({}, type, null, { Messages: 'Messages' }, { limit: 20, offset: 0 }, { 'chatRoom.Users': user.id });

export const latestMessages = async (user: Account | RecruiterUser | CompanyUser) => {
	let messages = await getLatestMessages(user);
	let contacts = await getContacts(user, true);
	messages = messages.map((message) => ({
		...message.Messages,
		ChatRoomId: message.id,
		RoomName: message.RoomName,
		FromUser: contacts ? contacts.filter((contact) => message.Messages.FromUserId === contact.id)[0] : {}
	}));
	delete messages.data;
	return messages;
};

// export const sentMessages = async (user: Account) => {
// 	let messages = await db.chatRooms.newQuery().where('FromUserId', user.id, undefined, 'Messages').unnest('Messages').select('Messages', 'ChatRoom.id', 'ChatRoom.RoomName').get(false) as any; // todo pagination await database.getByFields({}, type, null, { Messages: 'Messages' }, { limit: 20, offset: 0 }, { 'chatRoom.Users': user.id });
// 	const contacts = await getContacts(user);
// 	messages = messages.map((message) => ({
// 		...message.Messages,
// 		ChatRoomId: message.id,
// 		RoomName: message.RoomName,
// 		FromUser: contacts.filter((contact) => message.Messages.FromUserId === contact.id)[0]
// 	}));
// 	delete messages.data;
// 	return messages;
// };
export const sentMessages = async (user: Account | RecruiterUser| CompanyUser) => {
	return (await getChatRooms(user)).map(room => {
		room.Messages = room.Messages.filter(m => m.FromUserId === user.id);
		return room;
	});
};
export const receivedMessages = async (user: Account | RecruiterUser| CompanyUser) => {
	return (await getChatRooms(user)).map(room => {
		room.Messages = room.Messages.filter(m => m.FromUserId !== user.id);
		return room;
	}).filter(room => room.Messages.length > 0);
};

export const getTemplatesByUserId = async (userId: string) => await db.templates.newQuery().where('UserId', userId).get();

export const addSystemMessage = () => // (title, message, authorId, authorType) => {
	 true
;

export const readMessages = () => {
	// return database.updateByFields({ 'META().id': userId }, userId.split('/')[0], { 'child0.Read': true }, { Messages: null });
};

export const searchMessages = async (user: Account| RecruiterUser| CompanyUser, search: string) => {
	const chatRooms = db.chatRooms.newQuery().whereAny('Users', user.id).where('Archived', false).whereAny('Messages', search, 'LIKE', 'Description').get();
	const contacts = await getContacts(user);
	let result = null;
	await Promise.all([chatRooms, contacts]).then((values) => {
		if (values[0]) {
			result = values[0].public().map((chatRoom) => {
				const newChatRoom = chatRoom;

				newChatRoom.Messages.sort((a, b) => b.CreatedAt - a.CreatedAt);
				newChatRoom.SearchMatch = newChatRoom.Messages.map((x, i) => {
					x.index = i;
					return x;
				}).filter((x) => x.Description !== null && x.Description.toLowerCase().includes(search.toLowerCase()));

				return addUsersToModel(newChatRoom, values[1]);
			});
		}
	});
	return result;
};
