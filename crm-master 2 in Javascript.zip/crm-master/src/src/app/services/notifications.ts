import * as db from '../db/database';
import * as recruiterService from '../services/recruiters';
import * as companyService from '../services/companies';
import {getMessage} from "./localisation";
import {RecruiterUser} from "../models/RecruiterUser";
import {CompanyUser} from "../models/CompanyUser";
import {Account} from "../models/Account";
import {DatabaseManager} from "../db/DatabaseModule/DatabaseManager";
import {getLatestMessages} from "./messages";
import {getContacts} from "./messages";

const getUserDb = (type: string) => {
	let userFunction : DatabaseManager<RecruiterUser | CompanyUser | Account>;
	switch(type) {
		case 'Candidate':
			userFunction = db.accounts;
			break;
		case 'Recruiter':
			userFunction = db.recruiterUsers;
			break;
		case 'Company':
			userFunction = db.companyUsers;
			break;
		default:
			break;
	}
	return userFunction;
};

export const addNotification = async (type, userId, title, message, authorId, link) => {
	const userFunction = getUserDb(type);
	const user = await userFunction.find(userId);
	if (user) {
		user.Notifications.push({
			Title: await getMessage(user.Locale, title),
			Description: await getMessage(user.Locale, message),
			AuthorId: authorId,
			CreatedAt: Date.now(),
			Link: link,
			Read: false
		});
		await userFunction.save(user)
	}
};
export const addNotificationsForRecruiterUsers = async (RecruiterId, title, message, authorId, link) => {
	const users = await recruiterService.getRecruiterUsersByRecruiter(RecruiterId);
	users.forEach(user => addNotification('Recruiter', user.id, title, message, authorId, link));
};

export const addNotificationsForCompanyUsers = async (CompanyId, title, message, authorId, link) => {
	const users = await companyService.getCompanyUsersByCompanyId(CompanyId);
	users.forEach(user => addNotification('Company', user.id, title, message, authorId, link));
};

export const getNotifications = async (user) => {
	const userFunction = getUserDb(user.type);
	const userModel = await userFunction.find(user.id);

	if (userModel) {
		const contacts = await getContacts(user, true);
		console.log(contacts);
		const notifications = userModel.Notifications;
		const messages = (await getLatestMessages(user)).map(message => ({...message, ...{Link: '/messages', AuthorId: message.FromUserId, Title: 'Message: ' + message.RoomName}}));
		return [...messages, ...notifications].map(n => ({...n,
			FromUser: contacts ? contacts.filter((contact) => n.AuthorId === contact.id)[0] : {}
		}));
	}
	return null;
};
export const addSystemNotification = () => true;
export const readNotifications = async (userId) => await db.accounts.newQuery().update('Read', true).where('id', userId).unnest('Notifications').get();
export const clearAllNotifications = async (userId) => await db.accounts.newQuery().update('Notifications', []).where('id', userId).get();
