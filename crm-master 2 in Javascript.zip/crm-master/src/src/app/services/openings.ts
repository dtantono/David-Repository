import { Opening } from '../models/Opening';
import * as db from '../db/database';
import aiService = require('../services/ai');
import companyService = require('../services/companies');
import config from '../../../config';
import {IPagination} from "../helpers/paginate";
import {arrayToCouchbaseArray} from "../db/DatabaseModule/Helper";
import {removePunctuation} from "./ai";

export const getOpeningsByCompanyId = async (companyId) =>
	(await db.openings.with('Company').where('CompanyId', companyId).get()).public('Tags');
export const getOpeningsByUserId = async (userId, status = 'All') => {
	let query = db.openings.with('RecruiterUser').where('UserId', userId);
	switch(status) {
		case 'Active':
			query = query.where('Active', true);
			break;
		case 'Draft':
			query = query.where('Active', false);
			break;
		case 'Closed':
			query = query.where('Closed', true);
			break;
		default:
			break;
	}
	return (await query.get()).public('RecruiterUser.HashPassword', 'RecruiterUser.Notifications');
};

export const getRecentOpeningsByRecruiter = async (RecruiterId: string) =>
	(await db.openings.with('Company').where('RecruiterId', RecruiterId, '=', 'Company').orderBy('Opening.CreatedAt', false).limit(5).get()).public();

export const getRecentOpeningsByCompany = async (CompanyId: string) =>
	(await db.openings.with('Company').where('CompanyId', CompanyId).orderBy('Opening.CreatedAt', false).limit(5).get()).public();

export const getOpeningTags = async (query) => {
	let data = [];
	query = removePunctuation(query);
	if (query.length < 3) {
		data = await db.openings.newQuery().executeQuery(`select DISTINCT tags.name
	from ${config.DATABASE.NAME}
	unnest ${config.DATABASE.NAME} as tags
	where META(${config.DATABASE.NAME}).id = "tags" and tags.name like "${query}%"
	ORDER BY tags['value'] DESC
	OFFSET 0 LIMIT 5`, false);
	} else {
		data = await db.openings.newQuery().executeQuery(`select DISTINCT tags.name
	from ${config.DATABASE.NAME}
	unnest ${config.DATABASE.NAME} as tags
	where META(${config.DATABASE.NAME}).id = "tags" and tags.name like "%${query}%"
	ORDER BY tags['value'] DESC
	OFFSET 0 LIMIT 5`, false);
	}
	const toReturn = [];
	data.forEach((element) => {
		toReturn.push(element.name);
	});
	return toReturn;
};
export async function generateOpeningTags(opening) {
	const toReturn = await aiService.generateOpeningTags([opening]);
	toReturn.sort((a, b) => b.value - a.value).splice(25);
	return toReturn;
}

interface IAdvancedSearch {
	Company: string[],
	Salary: {
		From: number, To: number
	},
	Location: string[],
	JobTitle: string[],
	Skills: string[]
}

export const getAdvancedSearchOpenings = async (RecruiterId, paginate, searchParams : IAdvancedSearch, CandidateId = null) => {
	const jobTitleArray = searchParams.JobTitle.reduce((total : string[], jobTitle : string) => [...total, ...jobTitle.split(' ')], []);
	const skillsArray = searchParams.Skills.reduce((total : string[], skill : string) => [...total, ...skill.split(' ')], []);
	const tagsArray = `["${[...skillsArray, ...jobTitleArray].join(`","`)}"]`;
	const companyArray = `["${searchParams.Company.join(`","`)}"]`;
	const locationArray = `["${searchParams.Location.join(`","`)}"]`;
	const query = `SELECT opening.*, Company, ARRAY_INTERSECT(ARRAY x.name FOR x in opening.Tags END, ${tagsArray}) as MatchedTags${CandidateId && `, (FIRST META(m).id FOR m IN application WHEN m.CandidateId ="Candidate/${CandidateId}" AND m.Status != 3 AND m.Status != 4 END) as ApplicationId`}
		FROM ${config.DATABASE.NAME} opening
		LEFT NEST ${config.DATABASE.NAME} application on key application.OpeningId for opening
		LEFT JOIN ${config.DATABASE.NAME} Company on keys opening.CompanyId
		WHERE opening.type = 'Opening'
		AND opening.Compensation BETWEEN ${searchParams.Salary.From} AND ${searchParams.Salary.To}
		${searchParams.Location.length > 0 ? `AND opening.Location in ${locationArray}` : ''}
		AND Company.RecruiterId = "${RecruiterId}" ${searchParams.Company.length > 0 ? `AND Company.id in ${companyArray}` : ''}
		AND opening.Active = True
		ORDER BY ARRAY_LENGTH(ARRAY_INTERSECT(ARRAY x.name FOR x in opening.Tags END, ${tagsArray})) DESC`;
	const result = await db.openings.newQuery().executeQuery(query, false);
	if (result) {
		// if (paginate && !id) {
		// 	return (result as PaginatedList<Opening>).public();
		// }
		return result;
	}
	return null;
};

export const deleteOpeningById = async (id: string, userId: string) => {
	const opening = await db.openings.find(id);
	if(opening.UserId === userId) {
		return await db.openings.delete(opening);
	}
	return null;
};

export const getOpeningsByRecruiterId = async (RecruiterId : string, paginate : IPagination, searchParams : string[], CandidateId = null, onlyActive = true, id = null) => {
	let result: any;
	let query: string;
	if (searchParams && searchParams.length > 0) {
		// const whereCond = `Company.RecruiterId = "${RecruiterId}" AND (opening.Position like "%${searchParams.q}%" OR opening.Location like "%${searchParams.q}%" OR Company.CompanyName like "%${searchParams.q}%")`;
		const array = arrayToCouchbaseArray(searchParams);
		query = `SELECT opening.*, Company, ARRAY_INTERSECT(ARRAY x.name FOR x in opening.Tags END, ${array}) as MatchedTags ${CandidateId ? `, (FIRST META(m).id FOR m IN application WHEN m.CandidateId ="Candidate/${CandidateId}" AND m.Status != 3 AND m.Status != 4 END) as ApplicationId` : ''}
		FROM ${config.DATABASE.NAME} opening
		${CandidateId ? `LEFT NEST ${config.DATABASE.NAME} application on key application.OpeningId for opening` : ''}
		LEFT JOIN ${config.DATABASE.NAME} Company on keys opening.CompanyId
		WHERE opening.type = 'Opening'
		AND any x in opening.Tags satisfies x.name in ${array} end
		AND opening.DeletedAt = 0
		AND Company.RecruiterId = "${RecruiterId}"
		${onlyActive ? 'AND opening.Active = True' : ''}
		ORDER BY ARRAY_LENGTH(ARRAY_INTERSECT(ARRAY x.name FOR x in opening.Tags END, ${array})) DESC`;
		result = await db.openings.newQuery().executeQuery(query, false);
	} else {
		query = `SELECT opening.*, Company ${CandidateId ? `, (FIRST META(m).id FOR m IN application WHEN m.CandidateId ="${CandidateId}" AND m.Status != 3 AND m.Status != 4 END) as ApplicationId` : ''}
		FROM ${config.DATABASE.NAME} opening
		${CandidateId ? `LEFT NEST ${config.DATABASE.NAME} application on key application.OpeningId for opening` : ''}
		LEFT JOIN ${config.DATABASE.NAME} Company on keys opening.CompanyId
		WHERE opening.type = 'Opening'
		AND opening.DeletedAt = 0
		AND Company.RecruiterId = "${RecruiterId}"
		${onlyActive ? 'AND opening.Active = True ' : ''}
		${id ? `AND opening.id = '${id}' ` : ''}`;
		result = await db.openings.newQuery().executeQuery(query, false);
	}
	if (result) {
		// if (paginate && !id) {
		// 	return (result as PaginatedList<Opening>).public();
		// }
		return result;
	}
	return null;
};

export const getOpeningByIdAndRecruiterId = async (id, RecruiterId, CandidateId = null) => {
	const data = await getOpeningsByRecruiterId(RecruiterId, null, null, CandidateId, false, id);
	if (data && data.length) {
		return data[0];
	}
	return null;
};
export const getOpeningById = async (id, format = true) => {
	const data = await db.openings.with('Company').where('id', id).first();
	return format ? data.public() : data;
};
export const getOpeningByIdAndCompanyId = async (id, companyId) => {
	const data = await db.openings.with('Company').where('id', id).first();
	if (data.CompanyId === companyId) {
		return data.public();
	}
	return null;
};

export const create = async (details, CompanyId, UserId) => {
	const newOpening = new Opening();
	await newOpening.fill(details);
	newOpening.UserId = UserId;
	newOpening.CompanyId = CompanyId;
	newOpening.ReadOnly.VacanciesUnfilled = newOpening.RequiredCandidates;
	newOpening.Tags = await generateOpeningTags(newOpening);
	// enter into the database
	await db.openings.save(newOpening);
	return true;
};

export const createOnBehalf = async (details, CompanyId, RecruiterUserId, RecruiterId) => {
	if ((await companyService.getCompanyById(CompanyId)).RecruiterId === RecruiterId) {
		return await create(details, CompanyId, RecruiterUserId);
	}
	return null;
};

async function update(id, details) {
	const opening = await db.openings.find(id);
	await opening.fill(details);
	opening.Tags = await generateOpeningTags(opening);
	// enter into the database
	return await db.openings.save(opening);
}

export const updateOnBehalf = async (id, details, CompanyId, RecruiterId) => {
	if ((await companyService.getCompanyById(CompanyId)).RecruiterId === RecruiterId) {
		details.CompanyId = CompanyId;
		return await update(id, details);
	}
	return null;
};

export const updateOpening = async (id, details, CompanyId) => {
	const data = await getOpeningById(id, false);
	if (data) {
		if (data.CompanyId === CompanyId) {
			details.CompanyId = CompanyId;
			await update(id, details);
			return true;
		}
	}
	return null;
};

export const getRecommendationsByCandidateId = async (accountId) => {
	const data = await db.accounts.newQuery().where('id', accountId)
		.where('Active', true, undefined, 'Recommendations')
		.unnest('Recommendations')
		.leftJoin('Recommendations', 'Opening')
		.leftJoin('Opening', 'Company')
		.get();
	console.log(data);
	return data.public();
};
