import {DocumentTask, InterviewTask, ITask, Pipeline, Task, TodoTask} from '../models/Pipeline';
import * as db from '../db/database';
import {asyncForEach} from "../helpers/arrayHelpers";

const awshelper = require('./aws');

export const getPipelinesByCompanyId = async (companyId) => await db.pipelines.newQuery().where('CompanyId', companyId).get();

export const getPipelinesByRecruiterId = async (RecruiterId) => await db.pipelines.newQuery().where('CompanyId', RecruiterId).get();

const pipelineToTasks = async (pipeline) => {
	const mapTasks = async (tasks) => {
		await asyncForEach(tasks, async (task, i) => {
			if(task.TaskType === 'Group') {
				tasks[i] = await mapTasks(task.Tasks)
			} else {
				tasks[i]  = (await db.tasks.find(task.id)).public();
			}
		});
	};
	await mapTasks(pipeline.Tasks);
	return pipeline;
};

export const getPipelineByIdAndRecruiterId = async (id, RecruiterId) => {
	const pipeline = await db.pipelines.find(id);
	if (pipeline && pipeline.CompanyId === RecruiterId) {
		return await pipelineToTasks(pipeline.public());
	}
	return null;
};
export const getPipelineByIdAndCompanyId = async (id, companyId) => {
	const pipeline = await db.pipelines.newQuery().where('id', id).where('CompanyId', companyId).first();
	return await pipelineToTasks(pipeline.public());
};

export const create = async (details, CompanyId, UserId) => {
	delete details.id;
	const newPipeline = new Pipeline();
	const mapTasks = async (taskList) => asyncForEach(taskList, async (t, i) => {
		let newTask = null;
		if (taskList[i].TaskType === 'Group') {
			newTask = taskList[i];
			await mapTasks(newTask.Tasks);
		} else {
			const {id, TaskType, Days} = taskList[i];
			newTask = {id, TaskType, Days};
		}
		taskList[i] = newTask;
	});
	await mapTasks(details.Tasks);
	newPipeline.fill(details);
	newPipeline.UserId = UserId;
	newPipeline.CompanyId = CompanyId;
	// enter into the database
	return await db.pipelines.save(newPipeline);
};

export const updatePipeline = async (id, details, CompanyId) => {
	const pipeline = await db.pipelines.find(id);
	if (pipeline && pipeline.CompanyId === CompanyId) {
		pipeline.fill(details);
		// enter into the database
		return await db.pipelines.save(pipeline);
	}
	return null;
};

export const deletePipeline = async (id, CompanyId) => {
	const pipeline = await db.pipelines.find(id);
	if (pipeline && pipeline.CompanyId === CompanyId) {
		return await db.pipelines.delete(pipeline);
	}
	return null;
};
// export const addDocumentTypeTask = async (id, details) => {
// 	const pipeline = await db.pipelines.find(id);
// 	const task = Object.assign({}, details);
// 	task.fileId = uuid();
// 	task.TaskType = 'Document';
// 	pipeline.Tasks.push(task);
// 	delete task.file;
// 	await awshelper.upload(task.fileId, details.file);
// 	return await db.upsert(`${type}/${id}`, pipeline);
// };

export const getPipelineByUser = async (UserId) => {
	const data = await db.pipelines.newQuery().where('UserId', UserId).get();
	return data.public();
};

export const getTasks = async (OwnerId) => await db.tasks.newQuery().where('OwnerId', OwnerId).get();
export const getTaskById = async (TaskId, UserId) => {
	const task = await db.tasks.find(TaskId);
	const res = task.public() as any;
	if (task.TaskType === 'Document') {
		res.File = await awshelper.download(task.getFullKey());
	}
	return task && task.OwnerId === UserId ? res : null;
};

export const deleteTaskById = async (TaskId, UserId) => {
	const task = await db.tasks.find(TaskId);
	if(task.OwnerId === UserId) {
		return await db.tasks.delete(task);
	}
	return null;
};
export const createDocumentTask = async (details: any, OwnerId: string) => {
	const documentTask = new DocumentTask();
	documentTask.fill(details);
	documentTask.TaskType = 'Document';
	documentTask.OwnerId = OwnerId;
	const result = await awshelper.upload(documentTask.getFullKey(), details.File);
	if(result) {
		documentTask.File = documentTask.getFullKey();
		return await db.tasks.save(documentTask);
	}
	return null;
};
export const createInterviewTask = async (details: any, OwnerId: string) => {
	const interviewTask = new InterviewTask();
	interviewTask.fill(details);
	interviewTask.TaskType = 'Interview';
	interviewTask.OwnerId = OwnerId;
	return await db.tasks.save(interviewTask);
};
export const createTodoTask = async (details, OwnerId) => {
	const documentTask = new TodoTask();
	documentTask.fill(details);
	documentTask.TaskType = 'Todo';
	documentTask.OwnerId = OwnerId;
	return await db.tasks.save(documentTask);
};
export const updateTask = async (TaskId, details, UserId) => {
	const task = await db.tasks.find(TaskId);
	if('File' in details) {
		delete details.File;
	}
	if (task && task.OwnerId === UserId) {
		task.fill(details);
		return await db.tasks.save(task);
	}
	return null;
};

