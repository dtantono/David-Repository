const Pusher = require('pusher');
import config from '../../../config';

const pusher = new Pusher(config.pusher);
export const trigger = (object, userid) => pusher.trigger(userid.replace('/', '-'), 'my-event', object);
export const auth = (ctx) => {
	const socketId = ctx.request.body.socket_id;
	const channel = ctx.request.body.channel_name;
	const presenceData = {
		UserId: ctx.request.user
	};
	ctx.status = 200;
	ctx.body = pusher.authenticate(socketId, channel, presenceData);
};
