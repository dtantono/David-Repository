import { Recruiter } from '../models/Recruiter';
import { RecruiterUser } from '../models/RecruiterUser';
import * as openingService from '../services/openings';
import * as db from '../db/database';
import { Account } from '../models/Account';
import {Company} from "../models/Company";
import {ITeam} from "../models/GlobalClasses";
import * as cache from '../helpers/cache';
import {DatabaseManager} from "../db/DatabaseModule/DatabaseManager";
import {CompanyUser} from "../models/CompanyUser";

function getRandomString(length: number): string {
	let text = '';
	const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

	for (let i = 0; i < length; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length));
	}

	return text;
}

async function generateRecruiterCodeFunc(name: string, length: number, origName: string) {
	let code = '';
	for (let i = 0; i < name.length; i++) {
		code += name.charAt(i).toUpperCase();
		if (code.length > 2) {
			if ((await db.recruiters.newQuery().where('RecruiterCode', code).count()) === 0) {
				return code;
			}
			code = code.slice(0, -1);
		}
	}
	if (name.length === length) {
		if (origName.length > length + 1) {
			return generateRecruiterCodeFunc(origName, length + 1, origName);
		}
		const random = getRandomString(26);
		return await generateRecruiterCodeFunc(random, 3, random);
	}
	return await generateRecruiterCodeFunc(name.slice(0, -1), length, origName);
}

export const generateRecruiterCode = (name) => generateRecruiterCodeFunc(name, 3, name);


export interface IRecruiterRegister {
	Signup: any,
	Company: any,
	CompanyAdditional: any,
	Personal: any
}
export const registerRecruiter = async (details : IRecruiterRegister, InviteKey : string = null): Promise<RecruiterUser> => {
	const newRecruiter = new Recruiter();
	const companyPicture = details.CompanyAdditional.ProfilePicture;
	await newRecruiter.fill({...details.Company, ...details.CompanyAdditional});
	newRecruiter.RecruiterCode = await generateRecruiterCode(newRecruiter.RecruiterName);
	await newRecruiter.updatePicture(companyPicture);
	newRecruiter.IsSuperAdmin = false;

	let newRecruiterUser : RecruiterUser = null;
	if(InviteKey) {
		newRecruiterUser = await db.recruiterUsers.newQuery().where('InvitationKey', InviteKey).first();
	}
	if(!newRecruiterUser) {
		newRecruiterUser = new RecruiterUser();
	}
	const companyUserPicture = details.Personal.ProfilePicture;
	await newRecruiterUser.fill({...details.Signup, ...details.Personal});
	newRecruiterUser.Role = 1;
	newRecruiterUser.Active = true;
	newRecruiterUser.RecruiterId = newRecruiter.getFullKey();
	newRecruiterUser.updatePassword(details.Signup.Password);

	await newRecruiterUser.updatePicture(companyUserPicture);

	const newCompany = new Company();
	newCompany.fill({...details.Company, ...details.CompanyAdditional});
	newCompany.CompanyName = newRecruiter.RecruiterName;
	newCompany.RecruiterId = newRecruiter.getFullKey();

	await db.recruiters.save(newRecruiter);
	await db.recruiterUsers.save(newRecruiterUser);
	await db.companies.save(newCompany);
	return newRecruiterUser;
};

export const getRecruiters = async (RecruiterId: string) => {
	if((await db.recruiters.find(RecruiterId)).IsSuperAdmin) {
		const data = await db.recruiterUsers.with('Recruiter').where('Role', 1).orderBy('Recruiter.RecruiterName').get();
		return data.public();
	}
	return null;
};

export const getRecruiterById = async (id, format) => {
	const data = await db.recruiters.find(id);
	return format ? data.public() : data;
};

export const getRecruiterUserById = async (id, format) => {
	const data = await db.recruiterUsers.with('Recruiter').where('id', id).first();
	return format ? data.public('HashPassword') : data;
};

export const createMember = async (recruiterId, details, invitationKey : string = null, invitationType : string = null) => {
	const recruiterUser = new RecruiterUser();
	await recruiterUser.fill(details);
	recruiterUser.RecruiterId = invitationType === 'Recruiter' ? null : recruiterId;
	recruiterUser.Role = invitationType === 'Recruiter' ? 1 : 0;
	if(invitationKey && invitationType) {
		recruiterUser.InvitationKey = invitationKey;
		recruiterUser.InvitationType = invitationType;
	}
	return await db.recruiterUsers.save(recruiterUser);
};

export const createTeam = async (details: ITeam, recruiterId: string) => {
	const recruiter = await db.recruiters.find(recruiterId);
	details.Members = details.Members.map(m => m.includes('RecruiterUser') ? m : `RecruiterUser/${m}`);
	recruiter.Teams.push(details);
	return await db.recruiters.save(recruiter);
};

export const updateUsersTeamGeneral = async (details: string[], recruiterUserId: string, recruiterId: string, db: DatabaseManager<Company | Recruiter>) => {
	const recruiter = await db.find(recruiterId);
	if(recruiter) {
		recruiter.Teams.forEach(team => {
			const newTeams = details.filter(t => t === team.Name);
			const oldIndex = team.Members.indexOf(recruiterUserId);
			if(newTeams.length) {
				if(oldIndex === -1) {
					team.Members.push(recruiterUserId);
				}
			} else {
				if(oldIndex !== -1) {
					team.Members.splice(oldIndex);
				}
			}
		});
	}
	return await db.save(recruiter);
};

export const updateUsersTeams = async (details: string[], recruiterUserId: string, recruiterId: string ) => {
	const recruiterUser = await db.recruiterUsers.find(recruiterUserId);
	if (recruiterUser && recruiterUser.RecruiterId === recruiterId) {
		return await updateUsersTeamGeneral(details, recruiterUserId, recruiterId, db.recruiters);
	}
	return null;
};

export const getTeams = async (recruiterId: string) => {
	const recruiter = await db.recruiters.find(recruiterId);
	return recruiter ? recruiter.Teams : null;
};

export const getRecruiterUserByEmail = async (EmailAddress: string) => db.recruiterUsers.newQuery().where('EmailAddress', EmailAddress).first();
export const getRecruiterUsersByRecruiter = async (RecruiterId: string) => {
	const recruiter = await getRecruiterById(RecruiterId, false);
	return (await db.recruiterUsers.newQuery().where('RecruiterId', RecruiterId).orderBy('FirstName').get()).public('HashPassword').map(u => {
		return {...u, Teams: recruiter.Teams.filter(t => t.Members.includes(`${u.type}/${u.id}`)).map(t => t.Name)}
	});
};
export const saveAccount = async (user: RecruiterUser): Promise<any> => db.recruiterUsers.save(user);
export const updateRecruiterById = async (RecruiterId, details) => {
	let data = await db.recruiters.find(RecruiterId);
	if(data) {
		data.fill(details);
		await data.updatePicture();
		// enter into the database
		return await db.recruiters.save(data);
	}
	return null;
};

export const resetPassword = async (user: RecruiterUser, password: string) => {
	user.updatePassword(password);
	return await db.recruiterUsers.save(user);
};
export const saveRecruiterUser = (user: RecruiterUser) => db.recruiterUsers.save(user);
export const updateRecruiterUserById = async (RecruiterUserId, details) => {
	const user = await db.recruiterUsers.find(RecruiterUserId);
	if(user) {
		const picture = details.ProfilePicture;
		delete details.ProfilePicture;
		user.fill(details);
		// enter into the database
		await user.updatePicture(picture);
		if('Password' in details) {
			user.updatePassword(details.Password);
		}
		// enter into the database
		if(await db.recruiterUsers.save(user)) {
			return user;
		}
	}
	return null;
};
export const getRecruiterByName = async (name): Promise<Recruiter | null> => await db.recruiters.newQuery().where('RecruiterName', name).first();
export const getAdminRecruiter = async (): Promise<Recruiter | null> => await getRecruiterByName('Motivo');
export const bookmarkCandidate = async(userId: string, candidateId: string) => {
	if(await db.accounts.find(candidateId)) {
		const account = await getRecruiterUserById(userId, false);
		const candidateIndex = account.BookmarkedCandidates.indexOf(candidateId);
		if(candidateIndex === -1) {
			account.BookmarkedCandidates.push(candidateId);
		} else {
			account.BookmarkedCandidates.splice(candidateIndex, 1);
		}
		return await saveAccount(account);
	}
	return null;
};
export const getAccountByRecruiterAndCandidate = async (RecruiterId, CandidateId) => await db.accounts.newQuery().where('AccountEntityId', CandidateId).where('RecruiterId', RecruiterId).first();

export const loginAccount = async (RecruiterId: string, CandidateId: string) => {
	const account: Account = await getAccountByRecruiterAndCandidate(RecruiterId, CandidateId);
	if(account) {
		account.Active = true;
		await db.accounts.newQuery().update('Active', false).where('AccountEntityId', account.AccountEntityId).get();
		return await db.accounts.save(account);
	}
	return null;
};

export const addRecommendationByCandidateId = async (candidateId, RecruiterId, openingId) => {
	const account: Account = await getAccountByRecruiterAndCandidate(RecruiterId, candidateId);
	if (account) {
		const opening = await openingService.getOpeningByIdAndRecruiterId(openingId, RecruiterId);
		if (opening) {
			account.Recommendations.push({ OpeningId: `Opening/${openingId}`, Active: true, CreatedAt: Date.now() });
			cache.remove(candidateId, 'dashboard');
			return await db.accounts.save(account);
		}
	}
	return null;
};
