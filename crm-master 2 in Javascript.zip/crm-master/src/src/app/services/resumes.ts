
import { Resume } from '../models/Resume';
import * as recruiterService from '../services/recruiters';
import * as db from '../db/database';

const aiService = require('../services/ai');

const pdfHelper = require('../helpers/pdf');


export const generateResumeTags = async (resume) => {
	const toReturn = [];
	(await aiService.generateResumeTags([resume])).forEach((element) => {
		if (element.value > 0.2) {
			toReturn.push(element);
		}
	});
	return toReturn;
};

export const getResumesByUser = async (UserId, searchTerm : string = null) => {
	let data = db.resumes.newQuery().where('UserId', UserId);
	if (searchTerm) {
        data = data.whereGroup((query) => {
        	query
				.where('Name', searchTerm, 'LIKE')
				.orWhere('JobTitle', searchTerm, 'LIKE')
				.orWhere('Language', searchTerm, 'LIKE');
		});
    }
	return (await data.get()).public();
};

export const create = async (details, userId) => {
	const newResume = new Resume();
	// create the resume
	const skills = [];
	Object.keys(details.FeatureSkills).forEach((skill) => {
		skills.push({ SkillName: skill, Level: details.FeatureSkills[skill] });
	});
	details.FeatureSkills = skills;
	const languages = [];
	Object.keys(details.Languages).forEach((language) => {
		languages.push({ Name: language, Level: details.Languages[language] });
	});
	details.Languages = languages;
	await newResume.fill(details);
	newResume.UserId = userId;
	newResume.Default = (await getResumesByUser(userId)).length === 0;
	newResume.Tags = await generateResumeTags(newResume);
	// enter into the database
	return await db.resumes.save(newResume);
};

export const makeResumeDefault = async (UserId, ResumeId) => {
	await db.resumes.newQuery().where('UserId', UserId).update('Default', false).get();
	await db.resumes.newQuery().where('id', ResumeId).update('Default', true).get();
	return true;
};

export const getDefaultResume = async (UserId) => {
	let resume = await db.resumes.newQuery().where('UserId', UserId).// .where('RecruiterId', RecruiterId)
	where('Default', true).first();
	if(!resume) {
		resume = new Resume();
		resume.fill({});
	}
	return resume;
};

export const getResumesByIdAndCandidateId = async (id, CandidateId) => {
	const resume = await db.resumes.find(id);
	if (resume && resume.UserId === CandidateId) {
		return resume;
	}
	return null;
};

export const downloadResumeById = async (id) => {
	const resume = await db.resumes.with('Account').where('id', id).first();
	if (resume === null || resume.isDeleted()) {
		return null;
	}
	const candidateAccount = resume.Relations.Account;
	const candidate = await db.candidates.find(candidateAccount.AccountEntityId);
	const templateParam = resume.all();
	templateParam.CandidateCode = candidateAccount.CandidateCode;
	templateParam.FeatureSkills.sort((a, b) => b.Level - a.Level);
	templateParam.Candidate = candidate.public();
	const filename = `${id}.pdf`;
	const mimetype = 'application/pdf'; // octet-stream
	const filestream = await pdfHelper.createResumeFromTemplate(templateParam);
	return { filename: filename, mimetype: mimetype, filestream: filestream };
};

export const getResumePreviewById = async (RecruiterId, id) => {
	const resume = await db.resumes.with('Account').where('id', id).first();
	if (resume === null || resume.isDeleted()) {
		return null;
	}
	const candidateAccount = resume.Relations.Account;
	const candidate = await db.candidates.find(candidateAccount.AccountEntityId);
	const templateParam = resume.all();
	templateParam.CandidateCode = candidateAccount.CandidateCode;
	templateParam.FeatureSkills.sort((a, b) => b.Level - a.Level);
	templateParam.Candidate = candidate.public();
	return await pdfHelper.createResumePreviewFromTemplate(templateParam);
};

export const updateCandidateResume = async (id, details, UserId) => {
	const resume = await getResumesByIdAndCandidateId(id, UserId);
	if (resume) {
		const skills = [];
		resume.fill(details);
		Object.keys(details.FeatureSkills).forEach((skill) => {
			skills.push({ SkillName: skill, Level: details.FeatureSkills[skill] });
		});
		resume.FeatureSkills = skills;
		const languages = [];
		Object.keys(details.Languages).forEach((language) => {
			languages.push({ Name: language, Level: details.Languages[language] });
		});
		resume.Languages = languages;
		resume.Tags = await generateResumeTags(resume);
		// enter into the database
		return await db.resumes.save(resume);
	}
	return null;
};

export const deleteResumeById = async (id, candidateId) => {
	const data = await getResumesByIdAndCandidateId(id, candidateId);
	if (data) {
		return await db.resumes.delete(data);
	}
	return null;
};
