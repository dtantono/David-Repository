import * as db from '../app/db/database';
import {IApplicationTodoTask} from "../app/models/Pipeline";
db.applications.all().then((data) => {
	data.forEach((application, l) => {
		application.CandidatePipeline.forEach((task : IApplicationTodoTask) => {
			if(task.TaskType === 'Todo') {
				task.Attachments = [];
			}
		});
		db.applications.save(application).then(() => console.log('FINISHED', l + 1, 'of', data.length));
	});
}).catch((err) => console.log(err));
