const candidateService = require('../../dist/src/app/services/candidates');
candidateService.getCandidateById('Candidate/11fdaac0-ca09-4b88-9a39-7a1dc18d4a1f', false).then((data) => {
	candidateService.resetPassword(data, 'password');
});
