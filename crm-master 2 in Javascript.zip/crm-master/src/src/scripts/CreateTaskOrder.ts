import * as db from '../app/db/database';
import * as applicationService from '../app/services/applications';
import {IApplicationInterviewTask, IInterviewTask} from "../app/models/Pipeline";
const faker = require('faker');
db.applications.all().then((data) => {
	data.forEach((application, l) => {
		const app = applicationService.createTaskOrder(application);
		app.CandidatePipeline.map((task : IApplicationInterviewTask, i) => {
			task.Description = faker.lorem.paragraph();
			task.DueDate = Date.now() + (i * 2 * 3600 * 1000 * 24);
			if (task.hasOwnProperty('InterviewDetails')) {
				task.InterviewDetails.From = Date.now();
				task.InterviewDetails.To = Date.now() + 3600;
				delete task.InterviewDetails.From;
				delete task.InterviewDetails.To;
			}
			return task;
		});
		db.applications.save(app).then(() => console.log('FINISHED', l + 1, 'of', data.length));
	});
}).catch((err) => console.log(err));

db.pipelines.all().then((data) => {
	data.forEach((application, l) => {
		application.Tasks.map((task : IInterviewTask, i) => {
			task.Description = faker.lorem.paragraph();
			task.Deadline = Date.now() + (i * 2 * 3600 * 1000 * 24);
			if (task.hasOwnProperty('InterviewDetails')) {
				task.InterviewDetails.From = Date.now();
				task.InterviewDetails.To = Date.now() + 3600;
				delete task.InterviewDetails.From;
				delete task.InterviewDetails.To;
			}
			return task;
		});
		db.pipelines.save(application).then(() => console.log('FINISHED', l + 1, 'of', data.length));
	});
}).catch((err) => console.log(err));
