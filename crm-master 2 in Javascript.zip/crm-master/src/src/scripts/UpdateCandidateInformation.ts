

import * as db from '../app/db/database';
import { asyncForEach } from '../app/helpers/arrayHelpers';
import {Candidate} from "../app/models/Candidate";
import {Account} from "../app/models/Account";

// db.candidates.all().then((data) => {
// 	asyncForEach(data, async (candidate : Candidate, l) => {
// 		candidate.PhoneNumber = candidate.PhoneNumber.length > 0 ? candidate.PhoneNumber[0] : '';
// 		db.candidates.save(candidate).then(() => console.log('FINISHED', l + 1, 'of', data.length));
// 	});
// }).catch((err) => console.log(err));


db.accounts.all().then(data => {
	asyncForEach(data, async (account : Account, l) => {
		account.Notifications.forEach(n => {
			n.Link = '/kanban/'+n.Link.split('Application/')[1]
		});
		db.accounts.save(account).then(() => console.log('FINISHED', l + 1, 'of', data.length));
	});
}).catch((err) => console.log(err));