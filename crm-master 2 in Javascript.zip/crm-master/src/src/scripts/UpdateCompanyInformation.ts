

import * as db from '../app/db/database';
import { generateRandomCompany } from '../app/db/seed';
import { asyncForEach } from '../app/helpers/arrayHelpers';

db.companies.all().then((data) => {
	asyncForEach(data, async (company, l) => {
		const newCompany = await generateRandomCompany();
		newCompany.id = company.id;
		newCompany.RecruiterId = company.RecruiterId;
		db.companies.save(newCompany).then(() => console.log('FINISHED', l + 1, 'of', data.length));
	});
}).catch((err) => console.log(err));
