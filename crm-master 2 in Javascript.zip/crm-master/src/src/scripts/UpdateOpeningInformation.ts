

import * as db from '../app/db/database';
import { generateRandomOpening } from '../app/db/seed';
import { asyncForEach } from '../app/helpers/arrayHelpers';
import { Opening } from '../app/models/Opening';

db.openings.all().then((data) => {
	asyncForEach(data, async (opening : Opening, l) => {
		const newOpening = await generateRandomOpening();
		opening.Location = newOpening.Location;
		opening.Compensation = newOpening.Compensation;
		db.openings.save(opening).then(() => console.log('FINISHED', l + 1, 'of', data.length));
	});
}).catch((err) => console.log(err));
