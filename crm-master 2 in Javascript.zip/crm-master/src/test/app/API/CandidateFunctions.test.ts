import app from '../../../src/app/server/index';
import 'mocha';
import * as seeder from '../../../src/app/db/seed';
import * as hasher from '../../../src/app/helpers/hash';
import * as db from '../../../src/app/db/database';
import * as candidateService from '../../../src/app/services/candidates';
import { Candidate } from '../../../src/app/models/Candidate';
import config from '../../../config';
import * as chai from 'chai';

const server = app.listen();
import chaiHttp = require('chai-http');

chai.should();
chai.use(chaiHttp);

let token = '';
let eventId = '';
let candidate: Candidate = null;
let hash = '';
let openingId = '';
let applicationId = '';
let CandidateId = '';

const urlPrefix = '/api/';

function checkGoodWrapper(body) {
	body.should.have.property('result');
	body.result.should.be.eql(1);
	body.should.have.property('status');
	body.status.should.to.be.within(200, 205);
	body.should.have.property('error');
	body.error.length.should.be.eql(0);
	body.should.have.property('data');
}

function checkBadWrapper(body) {
	body.should.have.property('result');
	body.result.should.be.eql(2);
	body.should.have.property('status');
	body.status.should.to.be.within(400, 500);
	body.should.have.property('error');
	if (body.error.constructor === Array) {
		body.error.should.not.be.empty;
	} else if (body.error.constructor === Object) {
		Object.keys(body.error).should.not.be.empty;
	} else if (body.status !== 401) {
		body.error.should.be.eql('An error occurred');
	}
	body.should.have.property('data');
}

function checkAuthError(body) {
	body.status.should.be.eql(401);
	body.error.should.be.eql('You are not authorised');
}

const checkCandidate = (profile) => {
	profile.should.have.property('id');
	profile.should.have.property('CreatedAt');
	profile.should.have.property('FirstName');
	profile.should.have.property('DateOfBirth');
	profile.should.have.property('Gender');
	profile.should.have.property('Nationality');
	profile.should.have.property('PhoneNumber');
	profile.should.have.property('ProfilePicture');
	profile.should.have.property('CurrentLocation');
	profile.should.have.property('EmailAddress');
	profile.should.have.property('UpdatedAt');
};

let register;
let resume;
let event;
let login;
let personalInfo;
let account;
let profile;
let openings;
let createdResume;
let invite;

function checkCandidateTasks(task) {
	task.should.have.property('Name');
	task.should.have.property('Tasks');
	task.should.have.property('TaskType');
	task.should.have.property('Status');
	task.should.have.property('Source');
	task.should.have.property('Id');

	task.TaskType.should.be.a('string').and.oneOf(['Todo', 'Document', 'Default', 'Folder']);
	task.Status.should.be.a('string').and.oneOf(['Not started', 'In progress', 'Waiting', 'Completed', 'Deferred']);
	task.Source.should.be.a('number').and.within(1, 2);
	task.Name.should.be.a('string');
	if (task.TaskType === 'Folder') {
		task.Tasks.forEach((task) => checkCandidateTasks(task));
	} else {
		task.Tasks.should.be.empty;
	}
	task.Id.should.be.a('string');
}

function modelChecks(model, type) {
	model.should.have.property('id');
	model.should.have.property('type', type);
	model.should.have.property('CreatedAt');
	model.should.have.property('UpdatedAt');
	model.should.have.property('DeletedAt', 0);
}

function checkOpening(opening) {
	modelChecks(opening, 'Opening');
	opening.should.have.property('AdditionalSkills').which.is.an('array');
	opening.should.have.property('CompanyId').which.is.a('string');
	opening.should.have.property('Compensation').which.is.a('string');
	opening.should.have.property('Description').which.is.a('string');
	opening.should.have.property('JobType').which.is.a('string').and.is.oneOf(['Permanent', 'Contract', 'Part time']);
	opening.should.have.property('Location').which.is.a('string');
	opening.should.have.property('OtherRequirements').which.is.an('array');
	opening.should.have.property('Position').which.is.a('string');
	opening.should.have.property('ReadOnly').which.is.an('object').and.has.keys('ApplicationCount', 'VacanciesUnfilled');
	opening.should.have.property('RequiredCandidates').which.is.a('number');
	opening.should.have.property('RequiredEducation').which.is.an('array');
	opening.should.have.property('RequiredExperience').which.is.an('array');
}

function checkCompany(company) {
	modelChecks(company, 'Company');
	company.should.have.property('CompanyName');
	company.should.have.property('Mission');
	company.should.have.property('VisaSponsership');
	company.should.have.property('RecruiterId');
	company.should.have.property('WhoCanApply');
}

function checkApplication(application, candidateId) {
	modelChecks(application, 'Application');
	application.should.have.property('RejectionReason');
	application.should.have.property('ActionDate');
	application.should.have.property('TaskOrder');
	application.should.have.property('OpeningId');
	application.should.have.property('CandidateId'); // Account/%%%
	application.should.be.eql(candidateId);
	application.should.have.property('ResumeId');
	application.should.have.property('Status');
	application.should.have.property('CandidatePipeline');
	application.should.have.property('Opening');
	application.should.have.property('Company');

	application.DeletedAt.should.be.a('number');
	application.RejectionReason.should.be.a('string');
	application.TaskOrder.should.be.a('object');
	application.ActionDate.should.be.a('number');
	application.id.should.be.a('string');
	application.CreatedAt.should.be.a('number');
	application.UpdatedAt.should.be.a('number');
	application.CandidatePipeline.should.be.an('array').and.not.empty;
	application.CandidatePipeline.forEach((task) => checkCandidateTasks(task));
	application.Status.should.be.a('string').and.is.oneOf(['Applied', 'In progress', 'Dropped', 'Declined', 'Offered', 'Accepted']);
	checkOpening(application.Opening);
	checkCompany(application.Company);
}

describe('All candidate functions', () => {
	after(async () => {
		const login = await seeder.getData('Login');
		console.log(`DELETING ${login.EmailAddress}`);
		await db.candidates.newQuery().executeQuery(`DELETE from motivo where motivo.EmailAddress = "${login.EmailAddress}"`);
		console.log('FINISHED');
	});
	// before(() => {
	// 	this.timeout(20000);
	// 	return new Promise(async (resolve) => {
	// 		await seeder.seedTestSystem(1, 1, 1, 1, 10, 2, 1, 1);
	// 		resolve
	// 	});
	// });
	beforeEach(async () => {
		await new Promise((resolve) => {
			setTimeout(resolve, 100);
		});
		register = await seeder.getData('Register');
		resume = await seeder.getData('resume');
		event = await seeder.getData('event');
		login = await seeder.getData('Login');
		personalInfo = await seeder.getData('PersonalInformation');
		account = await seeder.getData('Account');
		profile = await seeder.getData('Profile');
		openings = await seeder.getData('Openings');
		invite = await seeder.getData('invite');
	});
	describe('Registration', () => {
		describe('POST candidates/register/validatePersonalInformation', () => {
			it('can validate a filled out personal information form', (done) => {
				chai.request(server).post(`${urlPrefix}candidates/register/validatePersonalInformation`).send(personalInfo).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('cant validate if EmailAddress is missing', (done) => {
				const data : any = Object.assign({}, personalInfo);
				delete data.EmailAddress;
				chai.request(server).post(`${urlPrefix}candidates/register/validatePersonalInformation`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					Object.keys(res.body.error).length.should.be.eql(1);
					done(err);
				});
			});
		});
		describe('POST candidates/register/validateCreateAccount', () => {
			it('can validate a filled out create account form', (done) => {
				chai.request(server).post(`${urlPrefix}candidates/register/validateCreateAccount`).send(account).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('cant validate if FirstName is missing', (done) => {
				const data : any = Object.assign({}, account);
				delete data.FirstName;
				chai.request(server).post(`${urlPrefix}candidates/register/validateCreateAccount`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					Object.keys(res.body.error).length.should.be.eql(1);
					done(err);
				});
			});
		});
		describe('GET candidates/register', () => {
			it('it should register with good credentials', (done) => {
				chai.request(server).post(`${urlPrefix}candidates/register`).send(register).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					done(err);
				});
			});
			it('cant register same email twice', (done) => {
				chai.request(server).post(`${urlPrefix}candidates/register`).send(register).end((err, res) => {
					console.log(res.body);
					res.should.have.status(409);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it("cant register when passwords don't match", (done) => {
				const data : any = register;
				data.ConfirmPassword = 'hello';
				chai.request(server).post(`${urlPrefix}candidates/register`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(409);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('cant register when email has the incorrect format', (done) => {
				const data : any = Object.assign({}, register);
				data.PersonalInformation.EmailAddress = 'hello.com';
				chai.request(server).post(`${urlPrefix}candidates/register`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					Object.keys(res.body.error).length.should.be.eql(1);
					done(err);
				});
			});
			it("can't register when first name isn't supplied", (done) => {
				const data : any = Object.assign({}, register);
				data.FirstName = '';
				chai.request(server).post(`${urlPrefix}candidates/register`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					Object.keys(res.body.error).length.should.be.eql(1);
					done(err);
				});
			});
			it("can't register when the password isn't long enough", (done) => {
				const data : any = register;
				data.PersonalInformation.Password = 'hello';
				data.PersonalInformation.ConfirmPassword = 'hello';
				chai.request(server).post(`${urlPrefix}candidates/register`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					Object.keys(res.body.error).length.should.be.eql(1);
					done(err);
				});
			});
		});

		describe('GET candidates/register/confirm', () => {
			before(() => new Promise(async (resolve) => {
				candidate = await candidateService.getCandidateByEmailAddress(personalInfo.EmailAddress);
				hash = hasher.createRegistrationKey(candidate.getFullKey(), candidate.EmailAddress, candidate.CreatedAt);
				resolve();
			}));
			it('cant confirm an account with an incorrect key', (done) => {
				chai.request(server).get(`${urlPrefix}candidates/register/confirm?key=hello&email=${candidate.EmailAddress}`).end((err, res) => {
					console.log(res.body, res.redirects);
					res.redirects[0].should.contain('failed');
					res.should.have.status(200); // real is 302
					done(err);
				});
			});
			it('cant confirm an account with an incorrect email', (done) => {
				chai.request(server).get(`${urlPrefix}candidates/register/confirm?key=${hash}&email=${candidate.EmailAddress}.uk`).end((err, res) => {
					console.log(res.body, res.redirects);
					res.redirects[0].should.contain('failed');
					res.should.have.status(200); // real is 302
					done(err);
				});
			});
			it('cant login an account before confirmation', (done) => {
				chai.request(server).post(`${urlPrefix}candidates/login`).send(login).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					Object.keys(res.body.error).length.should.be.eql(1);
					res.body.error[0].should.haveOwnProperty('EmailAddress');
					res.body.error[0].EmailAddress.should.be.eql('Please confirm your email first.');
					done(err);
				});
			});
			it('can confirm an account with the correct key', (done) => {
				chai.request(server).get(`${urlPrefix}candidates/register/confirm?key=${hash}&email=${candidate.EmailAddress}`).end((err, res) => {
					console.log(res.body, res.redirects);
					res.should.have.status(200); // real is 302
					res.redirects[0].should.contain('confirmed');
					done(err);
				});
			});
		});
	});
	describe('Authentication', () => {
		describe('GET candidates/login', () => {
			it('it should LOGIN with good credentials', (done) => {
				chai.request(server).post(`${urlPrefix}candidates/login`).send(login).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					token = token = `Bearer ${res.body.data.token}`;
					res.body.should.be.a('object');
					res.body.data.should.have.property('token');
					res.body.data.token.should.have.lengthOf(223);
					done(err);
				});
			});
			it("it shouldn't LOGIN with a bad password", (done) => {
				const data : any = login;
				data.Password = 'hello';

				chai.request(server).post(`${urlPrefix}candidates/login`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it("it shouldn't LOGIN with a bad username", (done) => {
				const data : any = login;
				data.EmailAddress = 'dawdwda@daw.com';
				chai.request(server).post(`${urlPrefix}candidates/login`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/requestResetPassword', () => {
			it('Still get success if you request to reset a password and the user doesnt exist', (done) => {
				const data : any = {};
				data.EmailAddress = 'awdaw@roaw.com';
				chai.request(server).post(`${urlPrefix}candidates/requestResetPassword`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('Can request to reset a password with a valid user', (done) => {
				const data : any = {};
				data.EmailAddress = personalInfo.EmailAddress;
				chai.request(server).post(`${urlPrefix}candidates/requestResetPassword`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET candidates/resetPassword', () => {
			before(() => new Promise(async (resolve) => {
				candidate = await candidateService.getCandidateByEmailAddress(personalInfo.EmailAddress);
				hash = hasher.createRegistrationKey(`${candidate.getKey()}pass`, candidate.EmailAddress, candidate.CreatedAt);
				resolve();
			}));
			it('Cant reset a password if the key isnt correct', (done) => {
				const data : any = {};
				data.Password = `${personalInfo.Password}1`;
				data.ConfirmPassword = `${personalInfo.ConfirmPassword}1`;
				chai.request(server).post(`${urlPrefix}candidates/resetPassword?key=dwadwda&email=${candidate.EmailAddress}`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('Cant reset a password if the passwords dont match', (done) => {
				const data : any = {};
				data.Password = `${personalInfo.Password}1`;
				data.ConfirmPassword = `${personalInfo.ConfirmPassword}2`;
				chai.request(server).post(`${urlPrefix}candidates/resetPassword?key=${hash}&email=${candidate.EmailAddress}`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('Can reset a password if the key is correct', (done) => {
				const data : any = {};
				data.Password = `${personalInfo.Password}1`;
				data.ConfirmPassword = `${personalInfo.ConfirmPassword}1`;
				chai.request(server).post(`${urlPrefix}candidates/resetPassword?key=${hash}&email=${candidate.EmailAddress}`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('Can login in with the new password', (done) => {
				const data : any = {};
				data.EmailAddress = login.EmailAddress;
				data.Password = `${login.Password}1`;
				chai.request(server).post(`${urlPrefix}candidates/login`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.should.be.a('object');
					res.body.data.should.have.property('token');
					res.body.data.token.should.have.lengthOf(223);
					token = token = `Bearer ${res.body.data.token}`;
					done(err);
				});
			});
			it('Can reset the password back to the original', (done) => {
				const data : any = {};
				data.Password = personalInfo.Password;
				data.ConfirmPassword = personalInfo.ConfirmPassword;
				chai.request(server).post(`${urlPrefix}candidates/resetPassword?key=${hash}&email=${candidate.EmailAddress}`).send(data).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
		});
	});
	describe('Recruiters', () => {
		describe('GET /recruiters', () => {
			it('get all recruiters that are associated with the candidate', (done) => {
				chai.request(server).get(`${urlPrefix}recruiters`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					done(err);
				});
			});
			it('cant get all recruiters when not logged in', (done) => {
				chai.request(server).get(`${urlPrefix}recruiters`).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					done(err);
				});
			});
		});
	});

	describe('Profile', () => {
		describe('GET candidates/profile', () => {
			it('it should GET profile with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}profile`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.should.be.a('object');
					profile.should.have.property('Candidate');
					profile.should.have.property('Recruiter');
					checkCandidate(res.body.data.Candidate);
					CandidateId = `Candidate/${res.body.data.Candidate.id}`;
					done(err);
				});
			});
			it('it shouldnt GET profile with a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}profile`).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					checkAuthError(res.body);
					done(err);
				});
			});
		});
		describe('PUT candidates/profile', () => {
			it('it should UPDATE profile with a good token', (done) => {
				const data : any = profile;
				data.FirstName = 'UpdatedName';
				chai.request(server).put(`${urlPrefix}profile`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(201);
					res.body.should.be.empty;
					done(err);
				});
			});
			it('it should GET updated profile with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}profile`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					profile.should.have.property('Candidate');
					profile.should.have.property('Recruiter');
					checkCandidate(res.body.data.Candidate);
					done(err);
				});
			});
			it('it shouldnt UPDATE profile with a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}profile`).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					checkBadWrapper(res.body);
					checkAuthError(res.body);
					done(err);
				});
			});
			it('it shouldnt UPDATE profile when first name isnt supplied', (done) => {
				const data : any = Object.assign({}, profile);
				data.FirstName = '';
				chai.request(server).put(`${urlPrefix}profile`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
	});
	describe('Resumes', () => {
		describe('POST candidates/resumes/validateCareerSummary', () => {
			it('it should return success if provided successfully', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateCareerSummary`).send(resume.CareerSummary).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should return success even if there are missing fields', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateCareerSummary`).send({}).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					res.body.error.should.have.lengthOf(0);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should return the particular errors if the format is invalid', (done) => {
				const data : any = Object.assign({}, resume.CareerSummary);
				data.Description = 1;
				chai.request(server).post(`${urlPrefix}resumes/validateCareerSummary`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('Schema');
					res.body.error[0].Schema.should.be.eql('Schema does not match');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/resumes/validateExperience', () => {
			it('it should return success if provided successfully', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateExperience`).send(resume.Experience[0]).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should return invalid schema if there are missing fields', (done) => {
				const data : any = Object.assign({}, resume.Experience[0]);
				data.JobTitle = '';
				chai.request(server).post(`${urlPrefix}resumes/validateExperience`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('Schema');
					res.body.error[0].Schema.should.be.eql('Schema does not match');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it should return the particular errors if the format is invalid', (done) => {
				const data : any = resume.Experience[0];
				data.From = 1000000000000000;
				chai.request(server).post(`${urlPrefix}resumes/validateExperience`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body, data);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('To');
					res.body.error[0].To.should.be.eql(`The "to" date must be greater than the "from" date`);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/resumes/validateEducation', () => {
			it('it should return success if provided successfully', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateEducation`).send(resume.Education[0]).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should return invalid schema if there are missing fields', (done) => {
				const data : any = Object.assign({}, resume.Education[0]);
				data.Degree = '';
				chai.request(server).post(`${urlPrefix}resumes/validateEducation`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('Schema');
					res.body.error[0].Schema.should.be.eql('Schema does not match');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('It should return the particular errors if the format is invalid', (done) => {
				const data : any = Object.assign({}, resume.Education[0]);
				data.Degree = 20;
				chai.request(server).post(`${urlPrefix}resumes/validateEducation`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('Schema');
					res.body.error[0].Schema.should.be.eql('Schema does not match');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/resumes/validateFeatureSkills', () => {
			it('it should return success if provided successfully', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateFeatureSkills`).send(resume.FeatureSkills).set('Authorization', token).end((err, res) => {
					console.log(res.body, resume.FeatureSkills);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should still pass if no skills are sent', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateFeatureSkills`).send({}).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/resumes/validateLanguages', () => {
			it('it should return success if provided successfully', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateLanguages`).send(resume.Languages).set('Authorization', token).end((err, res) => {
					console.log(res.body, resume.Languages);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should still pass if no skills are sent', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateLanguages`).send({}).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/resumes/validateAwards', () => {
			it('it should return success if provided successfully', (done) => {
				chai.request(server).post(`${urlPrefix}resumes/validateAwards`).send(resume.Awards[0]).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it should return invalid schema if there are missing fields', (done) => {
				const data : any = Object.assign({}, resume.Awards[0]);
				data.Title = '';
				chai.request(server).post(`${urlPrefix}resumes/validateAwards`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('Schema');
					res.body.error[0].Schema.should.be.eql('Schema does not match');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it should return the particular errors if the format is invalid', (done) => {
				const data : any = Object.assign({}, resume.Awards[0]);
				data.From = 1;
				chai.request(server).post(`${urlPrefix}resumes/validateAwards`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body, data);
					res.should.have.status(400);
					res.body.error.should.have.lengthOf(1);
					res.body.error[0].should.have.property('From');
					res.body.error[0].From.should.be.eql('Please enter an award date');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/resumes', () => {
			it('it should POST a resumes with a good token', (done) => {
				chai.request(server).post(`${urlPrefix}resumes`).send(resume).set('Authorization', token).end((err, res) => {
					console.log(res.body, resume);
					res.should.have.status(201);
					res.body.should.be.empty;
					done(err);
				});
			});
			it('it shouldnt POST a resumes with a bad token', (done) => {
				chai.request(server).post(`${urlPrefix}resumes`).send(resume).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt POST a resumes without a Skill section', (done) => {
				const data : any = Object.assign({}, resume);
				data.FeatureSkills = '';
				chai.request(server).post(`${urlPrefix}resumes`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET candidates/resumes', () => {
			it('it should GET resumes with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}resumes`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.data.length.should.be.eql(1);
					res.body.data[0].should.have.property('id');
					// res.body.data[0].should.have.property('resumeName');
					// res.body.data[0].should.have.property('fullName');
					// res.body.data[0].should.have.property('desiredJob');
					// res.body.data[0].should.have.property('locale');
					// res.body.data[0].should.have.property('email');
					// res.body.data[0].should.have.property('phoneNumber');
					createdResume = res.body.data[0];
					done(err);
				});
			});
			it('it shouldnt GET resumes with a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}resumes`).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET candidates/resumes/:id', () => {
			it('it should GET a resume with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}resumes/${createdResume.id}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.data.should.have.property('id');
					done(err);
				});
			});
			it('it shouldnt GET a resumes with a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}resumes/${createdResume.id}`).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt GET a resumes with a bad id', (done) => {
				chai.request(server).get(`${urlPrefix}resumes/1`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(404);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('PUT candidates/resumes/:id', () => {
			it('it should UPDATE a resumes with a good token', (done) => {
				const data : any = Object.assign({}, resume);
				data.FeatureSkills.SkillName = 'NEWSKILLNAME';
				chai.request(server).put(`${urlPrefix}resumes/${createdResume.id}`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(201);
					res.body.should.be.empty;
					done(err);
				});
			});
			it('it should GET an updated resumes with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}resumes/${createdResume.id}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					// res.body.data.resumeName.should.be.eql('NEWRESUMENAME');
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt UPDATE a resumes without a resume name', (done) => {
				const data : any = Object.assign({}, resume);
				data.FeatureSkills = '';
				chai.request(server).put(`${urlPrefix}resumes/${createdResume.id}`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt UPDATE a resumes with a bad token', (done) => {
				chai.request(server).put(`${urlPrefix}resumes/${createdResume.id}`).send(resume).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					checkBadWrapper(res.body);
					checkAuthError(res.body);
					done(err);
				});
			});
		});
	});

	function checkEvent(event) {
		event.should.have.property('id');
		event.should.have.property('Title');
		event.should.have.property('Body');
		event.should.have.property('Repeat');
		event.should.have.property('Location');
		event.should.have.property('StartTime');
		event.should.have.property('EndTime');
	}

	describe('Events', () => {
		describe('POST events', () => {
			it('it should POST a events with a good token', (done) => {
				chai.request(server).post(`${urlPrefix}events`).send(event).set('Authorization', token).end((err, res) => {
					console.log(res.body, event);
					res.should.have.status(201);
					res.body.should.be.empty;
					done(err);
				});
			});
			it('it shouldnt POST a events with a bad token', (done) => {
				chai.request(server).post(`${urlPrefix}events`).send(event).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt POST a events without a event title', (done) => {
				const data : any = Object.assign({}, event);
				data.Title = '';
				chai.request(server).post(`${urlPrefix}events`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET candidates/events', () => {
			it('it should GET events with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}events`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.data.length.should.be.eql(1);
					res.body.data.forEach((event) => checkEvent(event));
					eventId = res.body.data[0].id;
					done(err);
				});
			});
			it('it shouldnt GET events with a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}events`).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET candidates/events/:id', () => {
			it('it should GET a events with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}events/${eventId}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					checkEvent(res.body.data);
					eventId = res.body.data.id;
					done(err);
				});
			});
			it('it shouldnt GET a events with a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}events/${eventId}`).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt GET a events with a bad id', (done) => {
				chai.request(server).get(`${urlPrefix}events/1`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(404);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('PUT candidates/events/:id', () => {
			it('it should UPDATE a events with a good token', (done) => {
				const data : any = Object.assign({}, event);
				data.Title = 'NEWEVENTNAME';
				chai.request(server).put(`${urlPrefix}events/${eventId}`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(201);
					res.body.should.be.empty;
					done(err);
				});
			});
			it('it should GET an updated events with a good token', (done) => {
				chai.request(server).get(`${urlPrefix}events/${eventId}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					res.body.data.Title.should.be.eql('NEWEVENTNAME');
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt UPDATE a events without a event title', (done) => {
				const data : any = Object.assign({}, event);
				data.Title = '';
				chai.request(server).put(`${urlPrefix}events/${eventId}`).send(data).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt UPDATE a events with a bad token', (done) => {
				chai.request(server).put(`${urlPrefix}events/${eventId}`).send(event).set('Authorization', 'adwad').end((err, res) => {
					console.log(res.body, event);
					checkBadWrapper(res.body);
					checkAuthError(res.body);
					done(err);
				});
			});
		});
	});
	describe('Openings', () => {
		describe('GET candidates/openings', () => {
			it('it should return openings related to companies related to the same recruiter, and which are currently public', (done) => {
				chai.request(server).get(`${urlPrefix}openings`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					// res.body.data.length.should.be.eql(1);
					res.body.data[0].should.have.property('id');
					res.body.data[0].should.have.property('CreatedAt');
					res.body.data[0].should.have.property('Position');
					res.body.data[0].should.have.property('Description');
					res.body.data[0].should.have.property('Location');
					res.body.data[0].should.have.property('JobType');
					res.body.data[0].should.have.property('RequiredExperience');
					res.body.data[0].should.have.property('AdditionalSkills');
					res.body.data[0].should.have.property('OtherRequirements');
					res.body.data[0].should.have.property('Compensation');
					res.body.data[0].should.have.property('Active');
					res.body.data[0].should.have.property('RequiredCandidates');
					res.body.data[0].should.have.property('UserId');
					res.body.data[0].should.have.property('CompanyId');
					res.body.data[0].should.have.property('Company');
					res.body.data[0].should.have.property('UpdatedAt');
					openingId = res.body.data[0].id;
					done(err);
				});
			});
			it('it shouldnt return openings if provided a bad token', (done) => {
				chai.request(server).get(`${urlPrefix}openings`).set('Authorization', 'Bearer adwadw').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST openings', () => {
			it('cant access', (done) => {
				chai.request(server).post(`${urlPrefix}openings`).send(openings.common).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('PUT openings:id', () => {
			it('cant access', (done) => {
				chai.request(server).put(`${urlPrefix}openings/${openingId}`).send(openings.common).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					// res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET candidates/openings:id', () => {
			it('it should return an opening with the related id if the company is related to the recruiter the candidate signed up with', (done) => {
				chai.request(server).get(`${urlPrefix}openings/${openingId}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST candidates/openings:id/recommend', () => {
			it('cant access', (done) => {
				chai.request(server).post(`${urlPrefix}openings/${openingId}/recommend`).send(openings.recommend).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					res.body.error.should.be.eql('You are not authorised');
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
	});
	describe('Applications', () => {
		describe('POST candidates/openings/:id/applications', () => {
			it('it should make an application for an opening', (done) => {
				chai.request(server).post(`${urlPrefix}openings/${openingId}/applications`).send({ ResumeId: `Resume/${createdResume.id}` }).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt make an application for an opening if an incorrect token is provided', (done) => {
				chai.request(server).post(`${urlPrefix}openings/${openingId}/applications`).send({ ResumeId: `Resume/${createdResume.id}` }).set('Authorization', 'Bearer dawdaw').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it shouldnt make an application for an opening if the opening doesnt exist', (done) => {
				const openingId2 = '2c58dc36-d465-42f2-beb8-06b0c6e3b8e0';
				chai.request(server).post(`${urlPrefix}openings/${openingId2}/applications`).send({ ResumeId: `Resume/${createdResume.id}` }).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(404);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it should not make an application for an opening that is not associated with your recruiter', (done) => {
				db.openings.newQuery().executeQuery(`SELECT * FROM ${config.DATABASE.NAME} opening
			LEFT JOIN ${config.DATABASE.NAME} company on keys opening.CompanyId
			WHERE opening.type = "Opening"
			AND company.RecruiterId not in 
			(Select RAW RecruiterId FROM ${config.DATABASE.NAME} relation 
			where relation.type = "Account" and relation.AccountEntityId = "${CandidateId}")`
					, true).then((openings) => {
					chai.request(server).get(`${urlPrefix}openings/${openings[0].getKey()}/applications`).set('Authorization', token).end((err, res) => {
						console.log(res.body);
						res.should.have.status(404);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
		});
		describe('GET /applications', () => {
			it('it should return only my own (active) applications', (done) => {
				chai.request(server).get(`${urlPrefix}applications`).set('Authorization', token).end((err, res) => {
					// console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.data.should.have.length(1);
					applicationId = res.body.data[0].id;
					res.body.data.forEach((application) => checkApplication(application, CandidateId));
					done(err);
				});
			});
			it('it shouldnt return applications if an incorrect token is provided', (done) => {
				const untoken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhbmRpZGF0ZS9jZWU2NjYxNS1jNzZjLTRmODUtYTA1YS0yNDQxNjgwZDMwNGQiLCJ0eXBlIjoiQ2FuZGlkYXRlIiwicmVsYXRpb25JZCI6InJlY3J1aXRlci85Y2RjZWE4My1lZjM4LTQxOGUtOTRlNi05NzJiNWVjZDY0NTgiLCJpYXQiOjE1MzI1MDk3NDUsImV4cCI6MTUzMjU5NjE0NX0.nVmga3KD_beSdZMNqBPbWM';
				chai.request(server).get(`${urlPrefix}applications`).set('Authorization', untoken).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('GET /applications/:id', () => {
			it('it should return the application if its mine', (done) => {
				chai.request(server).get(`${urlPrefix}applications/${applicationId}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					checkApplication(res.body.data, CandidateId);
					done(err);
				});
			});
			it('it should return an error if its another candidates', (done) => {
				db.applications.newQuery().executeQuery(`SELECT * FROM ${config.DATABASE.NAME} application
			LEFT JOIN ${config.DATABASE.NAME} opening on keys application.OpeningId
			LEFT JOIN ${config.DATABASE.NAME} company on keys opening.CompanyId
			WHERE opening.type = "Opening"
			AND application.type = "Application"
			AND company.RecruiterId not in 
			(Select RAW RecruiterId FROM ${config.DATABASE.NAME} relation 
			where relation.type = "Account" and relation.AccountEntityId = "${CandidateId}")`
					, true).then((applications) => {
					chai.request(server).get(`${urlPrefix}applications/${applications[0].getKey()}`).set('Authorization', token).end((err, res) => {
						console.log(res.body);
						res.should.have.status(404);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
			it('it should return an error if the id doesnt exist', (done) => {
				const applicationId2 = '115as276-4865-40aa-b18f-a9c56dq2s85';
				chai.request(server).get(`${urlPrefix}applications/${applicationId2}`).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(404);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('it should return an error if the token isnt valid', (done) => {
				chai.request(server).get(`${urlPrefix}applications/${applicationId}`).set('Authorization', 'Bearer dawdaw').end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST /applications/:id/accept', () => {
			it('cant access', (done) => {
				chai.request(server).post(`${urlPrefix}applications/${applicationId}/accept`).send({ PipelineId: 'Pipeline/1' }).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('POST /applications/:id/reject', () => {
			it('cant access', (done) => {
				chai.request(server).post(`${urlPrefix}applications/${applicationId}/reject`).send({ PipelineId: 'Pipeline/1' }).set('Authorization', token).end((err, res) => {
					console.log(res.body);
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		// describe('PUT /applications/:applicationId/task/:taskId', () => {
		// 	it('can successfully change a task if the application and task ids are correct', (done) => {
		// 		chai.request(server).
		// 			put(`${urlPrefix}applications/${applicationId}/task/`).
		// 			send(applications.update).
		// 			set('Authorization', token).
		// 			end((err, res) => {
		// console.log(res.body);
		// 				res.should.have.status(200);
		// 				checkGoodWrapper(res.body);
		// 				done(err);
		// 			});
		// 	});
		// });
		describe('Invite', () => {
			describe('POST candidates/invite', () => {
				it('cant access', (done) => {
					chai.request(server).post(`${urlPrefix}invite`).send(invite).set('Authorization', token).end((err, res) => {
						console.log(res.body);
						res.should.have.status(404);
						checkBadWrapper(res.body);
						res.body.should.be.empty;
						done(err);
					});
				});
			});
		});
		describe('Dashboard', () => {
			describe('GET /dashboard', () => {
				it('can get own dashboard successfully if logged in (and it will send back own information)', (done) => {
					chai.request(server).get(`${urlPrefix}dashboard`).set('Authorization', token).end((err, res) => {
						console.log(res.body);
						res.should.have.status(200);
						checkGoodWrapper(res.body);
						res.body.data.should.have.property('applications');
						res.body.data.should.have.property('profile');
						checkCandidate(res.body.data.profile);
						res.body.data.should.have.property('droppedApplications');
						res.body.data.should.have.property('upcomingEvents');
						res.body.data.should.have.property('recommendedOpenings');
						res.body.data.should.have.property('offers');
						done(err);
					});
				});
				it('cant get dashboard with incorrect token', (done) => {
					const untoken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkNhbmRpZGF0ZS9jZWU2NjYxNS1jNzZjLTRmODUtYTA1YS0yNDQxNjgwZDMwNGQiLCJ0eXBlIjoiQ2FuZGlkYXRlIiwicmVsYXRpb25JZCI6InJlY3J1aXRlci85Y2RjZWE4My1lZjM4LTQxOGUtOTRlNi05NzJiNWVjZDY0NTgiLCJpYXQiOjE1MzI1MDk3NDUsImV4cCI6MTUzMjU5NjE0NX0.nVmga3KD_beSdZMNqBPbWM';
					chai.request(server).get(`${urlPrefix}dashboard`).set('Authorization', untoken).end((err, res) => {
						console.log(res.body);
						res.should.have.status(401);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
		});
		describe('Pipelines', () => {
			describe('GET /pipelines', () => {
				it('cant access', (done) => {
					chai.request(server).get(`${urlPrefix}pipelines`).set('Authorization', token).end((err, res) => {
						console.log(res.body);
						res.should.have.status(401);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
			describe('GET /pipelines/:id', () => {
				it('cant access', (done) => {
					chai.request(server).get(`${urlPrefix}pipelines`).set('Authorization', token).end((err, res) => {
						console.log(res.body);
						res.should.have.status(401);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
		});
	});
});
