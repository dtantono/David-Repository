const app = require('../../../src/app/server/index');
const server = app.listen();

const chai = require('chai');
const chaiHttp = require('chai-http');
chai.should();
chai.use(chaiHttp);

const seeder = require('../../../src/app/db/seed');

var urlPrefix = '/api/info/';

function checkGoodWrapper(body) {
	body.should.have.property('result');
	body.result.should.be.eql(1);
	body.should.have.property('status');
	body.status.should.to.be.within(200, 205);
	body.should.have.property('error');
	body.error.length.should.be.eql(0);
	body.should.have.property('data');
}

// function checkBadWrapper(body) {
// 	body.should.have.property('result');
// 	body.result.should.be.eql(2);
// 	body.should.have.property('status');
// 	body.status.should.to.be.within(400, 500);
// 	body.should.have.property('error');
// 	body.error.length.should.not.be.eql(0);
// 	body.should.have.property('data');
// }
// function checkAuthError(body) {
// 	body.status.should.be.eql(401);
// 	body.error.should.be.eql('You are not authorised');
// }
var refData;
describe('All info functions', function () {
	before(function () {
		this.timeout(10000);
		return new Promise(async function (resolve) {
			await seeder.seedAllForTests();
			resolve();
		});
	});
	beforeEach(async function () {
		await new Promise((resolve) => {
			setTimeout(resolve, 100);
		});
		refData = await seeder.getData('reference');
	});
	describe('Reference data', function () {
		describe('GET info/referenceData', function () {
			it('it should get all reference data', function (done) {
				chai.request(server).get(`${urlPrefix}referenceData`).end(function (err, res) {
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.data.should.be.eql(refData);
					done(err);
				});
			});
			it('it should be filterable', function (done) {
				chai.request(server).get(`${urlPrefix}referenceData?filter=Gender`).end(function (err, res) {
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.data.should.be.eql(refData.Gender);
					done(err);
				});
			});
		});
	});
});
