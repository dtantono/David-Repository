const app = require('../../../src/app/server/index');
const server = app.listen();
// Add promise support if this does not exist natively.
if (!global.Promise) {
	global.Promise = require('q');
}

const chai = require('chai');
const chaiHttp = require('chai-http');
chai.should();
var expect = require('chai').expect;
chai.use(chaiHttp);
const db = require('../../../src/app/db/index');
const hasher = require('../../../src/app/helpers/hash');
const seeder = require('../../../src/app/db/seed');

const url = '/api/recruiters';

function checkGoodWrapper(body) {
	body.should.have.property('result');
	body.result.should.be.eql(1);
	body.should.have.property('status');
	body.status.should.to.be.within(200, 205);
	body.should.have.property('error');
	body.error.length.should.be.eql(0);
	body.should.have.property('data');
}

function checkBadWrapper(body) {
	body.should.have.property('result');
	body.result.should.be.eql(2);
	body.should.have.property('status');
	body.status.should.to.be.within(400, 500);
	body.should.have.property('error');
	body.error.length.should.not.be.eql(0);
	body.should.have.property('data');
}

// function checkAuthError(body) {
// 	body.status.should.be.eql(401);
// 	body.error.should.be.eql('You are not authorised');
// }

describe('Recruiter', () => {
	let recruiter; // allow recruiter's object changes insides tests
	let recruiterBis;
	let token;
	let candidateRegister;
	let candidateLogin;
	let invite;

	// after(async () => await db.deleteWhere(''));

	beforeEach(async () => {
		recruiter = {
			FirstName: 'Test',
			LastName: 'Dude',
			EmailAddress: 'test@example.com',
			Password: '11111111',
			ConfirmPassword: '11111111',
			DateOfBirth: '1970/01/01',
			Gender: 'Male',
			Nationality: 'Japan',
			PhoneNumber: '+81 90 1234 5678',
			ProfilePicture:
				'iVBORw0KGgoAAAANSUhEUgAAAL4AAAC+CAMAAAC8qkWvAAAAXVBMVEU/l1r821b///+Cq1nVyleouViqzLODtpFSnFrX5tvz11bfz1dzplmctFjp01dTn2m/wli0vVhkoVnKxlfs8+10r4X1...',
			CurrentLocation: 'Tokyo, Japan'
		};
		recruiterBis = {
			FirstName: 'Recruiter',
			LastName: 'Bis',
			EmailAddress: 'recruiterBis@example.com',
			Password: '11111111',
			ConfirmPassword: '11111111',
			DateOfBirth: '1970/01/01',
			Gender: 'Male',
			Nationality: 'Japan',
			PhoneNumber: '+81 90 1234 5678',
			ProfilePicture:
				'iVBORw0KGgoAAAANSUhEUgAAAL4AAAC+CAMAAAC8qkWvAAAAXVBMVEU/l1r821b///+Cq1nVyleouViqzLODtpFSnFrX5tvz11bfz1dzplmctFjp01dTn2m/wli0vVhkoVnKxlfs8+10r4X1...',
			CurrentLocation: 'Tokyo, Japan'
		};
		candidateRegister = await seeder.getData('Register');
		invite = await seeder.getData('invite');
		candidateLogin = await seeder.getData('Login');
	});

	// REGISTER
	describe('/POST Register', () => {
		describe('register fails', () => {
			it('should fail to register when password is not long enough (min: 8)', (done) => {
				recruiter.Password = 'bad';
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					expect(res.body.error).to.deep.include.members([
						{Password: 'Password must be longer than 8 characters'}
					]);
					done(err);
				});
			});
			it('should fail to register when ConfirmPassword does not match Password', (done) => {
				recruiter.ConfirmPassword = 'wrongPassword';
				// recruiter.ConfirmPassword = recruiter.Password; (comment: check the test)
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('should fail to register when email not in the correct format', (done) => {
				recruiter.EmailAddress = 'wrongEmail';
				// recruiter.EmailAddress = 'goodEmail@email.com'; (comment: check the test)
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('should fail to register when first name is not supplied', (done) => {
				recruiter.FirstName = '';
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('should fail to register when date of birth is not supplied', (done) => {
				recruiter.DateOfBirth = '';
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('should fail to register when gender is not supplied', (done) => {
				recruiter.Gender = '';
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('should fail to register when phone number is not supplied', (done) => {
				recruiter.PhoneNumber = '';
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
			it('should fail to register when country of residence is not supplied', (done) => {
				recruiter.CurrentLocation = '';
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(400);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});

		describe('register success and retry fails', () => {
			it('should succeed in registering (post) a recruiter ', (done) => {
				chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
					res.should.have.status(200);
					res.body.should.be.a('object');
					checkGoodWrapper(res.body);
					res.body.data.should.have.property('token');
					res.body.data.token.should.have.lengthOf(308);
					done(err);
				});
			});
			it('should fail to register a user if already in the database', (done) => {
				setTimeout(() => {
					chai.request(server).post(`${url}/register`).send(recruiter).end((err, res) => {
						res.should.have.status(400);
						res.body.should.be.a('object');
						checkBadWrapper(res.body);
						done(err);
					});
				}, 200);
			});
		});
	});

	// LOGIN
	describe('POST recruiters/login', function () {
		describe('login fails', () => {
			it('should fail to login when wrong password is provided', function (done) {
				// Change password
				recruiter.Password = 'wrongPassword';
				chai.request(server).post(`${url}/login`).send(recruiter).end(function (err, res) {
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
				it('should fail to login when wrong email is provided', function (done) {
					// Change EmailAddress
					recruiter.EmailAddress = 'wrongemail@bad.com';
					chai.request(server).post(`${url}/login`).send(recruiter).end(function (err, res) {
						res.should.have.status(401);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
			describe('login success', () => {
				it('should succeed in logging in when good credentials are supplied', function (done) {
					chai.request(server).post(`${url}/login`).send(recruiter).end(function (err, res) {
						res.should.have.status(200);
						checkGoodWrapper(res.body);
						res.body.should.be.a('object');
						res.body.data.should.have.property('token');
						res.body.data.token.should.have.lengthOf(308);
						token = token = `Bearer ${res.body.data.token}`;
						done(err);
					});
				});
			});
		});
	});

	describe('/POST Logout', () => {
		it('should succeed in logging out', function (done) {
			chai.request(server).post(`${url}/logout`).send(recruiter).end(function (err, res) {
				res.should.have.status(204);
				expect(res.body.token).to.be.undefined;
				done(err);
			});
		});
	});

	// PROFILE
	describe('/GET Profile', () => {
		let updateRecruiter;
		beforeEach(() => {
			updateRecruiter = {
				// FirstName: 'Rocky',
				// LastName: 'Balboa',
				EmailAddress: 'rocky@iloveboxing.com',
				Password: 'grrrrrrrrr',
				ConfirmPassword: 'grrrrrrrrr',
				FirstName: 'Rocky Balboa',
				LastName: 'Rocky Balboa',
				DateOfBirth: '1970/01/01',
				Gender: 'Male',
				Nationality: 'United States',
				PhoneNumber: '+81 90 1234 5678',
				ProfilePicture:
					'iVBORw0KGgoAAAANSUhEUgAAAL4AAAC+CAMAAAC8qkWvAAAAXVBMVEU/l1r821b///+Cq1nVyleouViqzLODtpFSnFrX5tvz11bfz1dzplmctFjp01dTn2m/wli0vVhkoVnKxlfs8+10r4X1...',
				CurrentLocation: 'Tokyo, Japan',
				JapaneseVisa: 'yes'
			};
		});
		describe('get profile fail', () => {
			it('should fail to get the profile if the right token is not provided', (done) => {
				const wrongToken = 'wrongToken';
				chai.request(server).get(`/api/profile`).set('Authorization', wrongToken).end((err, res) => {
					res.should.have.status(401);
					checkBadWrapper(res.body);
					done(err);
				});
			});
		});
		describe('get profile success', () => {
			it('should succeed in getting the profile if the right token is provided', (done) => {
				chai.request(server).get(`/api/profile`).set('Authorization', token).end((err, res) => {
					res.should.have.status(200);
					checkGoodWrapper(res.body);
					res.body.should.be.a('object');
					res.body.data.should.have.property('id');
					res.body.data.should.have.property('CreatedAt');
					res.body.data.should.have.property('FirstName');
					res.body.data.should.have.property('LastName');
					res.body.data.should.have.property('DateOfBirth');
					res.body.data.should.have.property('Gender');
					res.body.data.should.have.property('Nationality');
					res.body.data.should.have.property('PhoneNumber');
					res.body.data.should.have.property('ProfilePicture');
					res.body.data.should.have.property('CurrentLocation');
					res.body.data.should.have.property('EmailAddress');
					res.body.data.should.have.property('members');
					res.body.data.members.should.have.length(0);
					done(err);
				});
			});
		});

		describe('/PUT Profile', () => {
			describe('update profile fail', () => {
				it('should fail to update the profile if good token not provided', (done) => {
					const wrongToken = 'wrongToken';
					chai.request(server).put(`/api/profile`).send(updateRecruiter).set('Authorization', wrongToken).end((err, res) => {
						res.should.have.status(401);
						checkBadWrapper(res.body);
						done(err);
					});
				});
			});
			describe('update profile success', () => {
				it('should succeed in updating the profile if good token is provided', (done) => {
					chai.request(server).put(`/api/profile`).send(updateRecruiter).set('Authorization', token).end((err, res) => {
						res.should.have.status(201);
						res.body.should.be.empty;
						done(err);
					});
				});
			});
		});
	});

	// REGISTER INVITE MEMBERS
	describe('/POST Register Invite', () => {
		const member = {
			EmailAddress: 'damien@rooking.co.jp',
			FirstName: 'Test',
			LastName: 'Test'
		};
		const completInvitation = {
			DateOfBirth: '11/11/1999',
			Gender: 'Male',
			Nationality: 'JP',
			PhoneNumber: '020-5689-9854',
			ProfilePicture: 'dsadsad',
			CurrentLocation: 'JP',
			Password: '222222222',
			ConfirmPassword: '222222222'
		};
		let id;
		let invitationKey;
		describe('/POST Invite', () => {
			beforeEach(async function () {
				await new Promise((resolve) => {
					setTimeout(resolve, 100);
				});
			});
			it('should invite a new member', function (done) {
				chai.request(server).post('/api/recruiters/register/invitation').send(member).set('Authorization', token).end((err, res) => {
					res.should.have.status(201);
					res.body.data.should.have.property('id');
					res.body.data.should.have.property('invitationKey');
					id = res.body.data.id;
					invitationKey = res.body.data.invitationKey;
					done(err);
				});
			});
			it('should complete the profile', function (done) {
				chai.request(server).post(`/api/recruiters/invited/${id}?key=${invitationKey}`).send(completInvitation).end((err, res) => {
					res.should.have.status(201);
					done(err);
				});
			});
			it('should not invite a new member if he is already in list', (done) => {
				chai.request(server).post('/api/recruiters/register/invitation').send(member).set('Authorization', token).end((err, res) => {
					res.should.have.status(400);
					res.body.should.have.property('error');
					done(err);
				});
			});
			it('should have updated the members array correctly', (done) => {
				chai.request(server).get(`/api/profile`).set('Authorization', token).end((err, res) => {
					res.body.data.should.have.property('members');
					res.body.data.members.should.have.length(1);
					done(err);
				});
			});

			// it('should invite to login if already exists', () => {});
		});
		describe('/POST register', () => {
			// it('should fail to complete if fields are wrong', () => {});
			// it('shoudl update the recruiter members array with member id if invitation accepted on login', () => {});
		});
	});

	// Candidates
	describe('Candidates', () => {
		let key;
		let hash;
		let loginKey;

		describe('POST /candidates/invite', () => {
			describe('register', () => {
				it('should send the candidate to the Register page if candidate does not yet exist', (done) => {
					// test that the relation object has been built
					// take a brand new candidate
					chai.request(server).post(`/api/invite?type=Candidate`).send(invite).set('Authorization', token).end((err, res) => {
						res.should.have.status(201);
						checkGoodWrapper(res.body);
						key = res.body.data.key;
						expect(res.body.data.type).to.equal('register');
						expect(res.body.data.relation).to.have.property('cas');
						done(err);
					});
				});

				it('should enable the candidate to register from the link and update the relation object', (done) => {
					chai.request(server).post(`/api/candidates/register?type=Candidate&key=${key}`).send(candidateRegister).end(function (err, res) {
						res.should.have.status(201);
						done(err);
					});
				});
			});

			// get the confirmation email here

			describe('login', () => {
				beforeEach(function () {
					return new Promise(async function (resolve) {
						await new Promise((resolve) => {
							setTimeout(resolve, 100);
						});
						const candidate = (await db.getByFields({EmailAddress: invite.EmailAddress}, 'Candidate'))[0];
						hash = hasher.createRegistrationKey(
							candidate.id,
							candidate.EmailAddress,
							candidate.CreatedAt
						);
						resolve();
					});
				});
				it('can confirm an account with the correct key', async function () {
					chai.request(server).get(
						`/api/candidates/register/confirm?key=${hash}&email=${
							invite.EmailAddress
							}`
					).then((res) => {
						res.should.have.status(200);
						checkGoodWrapper(res.body);
					}).catch((err) => console.log(err));
				});

				describe('should send the candidate to the Login page if candidate already exists', () => {
					it('register', (done) => {
						chai.request(server).post(`${url}/register`).send(recruiterBis).end((err, res) => {
							res.should.have.status(200);
							res.body.should.be.a('object');
							checkGoodWrapper(res.body);
							res.body.data.should.have.property('token');
							res.body.data.token.should.have.lengthOf(308);
							done(err);
						});
					});

					it('login', (done) => {
						chai.request(server).post(`${url}/login`).send(recruiterBis).end(function (err, res) {
							res.should.have.status(200);
							checkGoodWrapper(res.body);
							res.body.should.be.a('object');
							res.body.data.should.have.property('token');
							res.body.data.token.should.have.lengthOf(308);
							token = token = `Bearer ${res.body.data.token}`;
							done(err);
						});
					});

					it('test', (done) => {
						// take an already existin candidate from the tests of canidate above
						chai.request(server).post(`/api/invite?type=Candidate`).send(invite).set('Authorization', token).end((err, res) => {
							res.should.have.status(201);
							checkGoodWrapper(res.body);
							loginKey = res.body.data.key;
							expect(res.body.data.type).to.equal('login');
							expect(res.body.data.relation).to.have.property('cas');
							done(err);
						});
					});
					it('it should LOGIN with good credentials', function (done) {
						const data = candidateLogin;

						chai.request(server).post(
							`/api/candidates/login?key=${loginKey}&email=${invite.EmailAddress}`
						).send(data).end(function (err, res) {
							res.should.have.status(200);
							checkGoodWrapper(res.body);
							res.body.should.be.a('object');
							res.body.data.should.have.property('token');
							res.body.data.token.should.have.lengthOf(225);

							done(err);
						});
					});

					it('should send a message if the relation has already been built', (done) => {
						chai.request(server).post(`/api/invite?type=Candidate`).send(invite).set('Authorization', token).end((err, res) => {
							res.should.have.status(201);
							done(err);
						});
					});
				});
			});
		});
		describe('/GET candidates', () => {
			let candidateId;
			it('should retrieve a list of candidates objects', (done) => {
				chai.request(server).get('/api/candidates').set('Authorization', token).end((err, res) => {
					candidateId = res.body.data[0].CandidateId;
					res.should.have.status(200);
					expect(res.body.data).to.be.an('array').that.is.not.empty;
					expect(res.body.data).to.have.lengthOf(1);
					done(err);
				});
			});
			it('should retrieve a candidate from the user list of candidates', (done) => {
				const id = candidateId.replace(/Candidate\//, '');
				chai.request(server).get(`/api/candidates/${id}`).set('Authorization', token).end((err, res) => {
					res.should.have.status(200);
					expect(res.body.id).to.equal(candidateId);
					done(err);
				});
			});
		});
		describe('/GET recruiters', () => {
			it('should retrieve a list of recruiters objects', (done) => {
				chai.request(server).get('/api/recruiters').set('Authorization', token).end((err, res) => {
					res.should.have.status(200);
					expect(res.body.data).to.be.an('array').that.is.not.empty;
					expect(res.body.data).to.have.lengthOf(1);
					done(err);
				});
			});
		});
	});
});
// });
