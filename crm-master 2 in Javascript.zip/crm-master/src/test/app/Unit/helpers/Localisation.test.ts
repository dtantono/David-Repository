import 'mocha';
import * as chai from 'chai';
import * as localisation from '../../../../src/app/helpers/Localisation';
chai.should();

describe('Translation', () => {
	it('Function will translate to english', (done) => {
		const res = localisation.getMessage('en', 'required', 'test');
		res.should.be.eql('Must be a valid test');
		done();
	});
	it('Function will translate to japanese', (done) => {
		const res = localisation.getMessage('ja', 'required', 'test');
		res.should.be.eql('testを入力ください');
		done();
	});
	it('Function will translate to english by default', (done) => {
		const res = localisation.getMessage('en', 'required', 'test');
		res.should.be.eql('Must be a valid test');
		done();
	});
});
