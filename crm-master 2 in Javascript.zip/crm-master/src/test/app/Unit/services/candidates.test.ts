import 'mocha';
import * as chai from 'chai';
import * as candidateService from '../../../../src/app/services/candidates';
import * as db from '../../../../src/app/db/database';
import { Candidate } from '../../../../src/app/models/Candidate';
chai.should();

describe('all', () => {
	const candidate = new Candidate();
	candidate.fill({ EmailAddress: 'hello@example.co.jp' });
	before(async () => await db.candidates.save(candidate));
	describe('Get candidate by email', () => {
		it('Works if candidate exists', (done) => {
			candidateService.getCandidateByEmailAddress(candidate.EmailAddress).
				then((data) => {
					data.should.not.be.eql(null);
					data.should.haveOwnProperty('id');
					done();
				});
		});
	});
	describe('Get candidate by id', () => {
		it('Works if candidate exists', (done) => {
			candidateService.getCandidateById(candidate.getKey(), false).
				then((data) => {
					data.should.not.be.eql(null);
					data.should.haveOwnProperty('EmailAddress');
					data.EmailAddress.should.be.eql(candidate.EmailAddress);
					done();
				});
		});
	});
});
