const assert = require('assert');
const db = require('../../../src/app/db/database');

describe('Normal use case', function () {
	it('should add an item to the database', async function () {
		const res = await db.insert('test/123', {test: 'test value'});
		assert(res !== null);
	});
	it('should get an item from the database', async function () {
		await new Promise((resolve) => {
			setTimeout(resolve, 100);
		});
		const res = await db.get('test/123');
		assert(res.id === 'test/123' && res.test === 'test value');
	});

	it('should update an item to the database', async function () {
		const res = await db.upsert('test/123', {testVal: 'test value 1'});
		assert(res !== null);
	});

	it('should get an item by field from the database', async function () {
		const res = await db.getByFields({testVal: 'test value 1'}, 'test');
		assert(res[0].id === 'test/123' && res[0].testVal === 'test value 1');
	});

	it('should remove an item to the database', async function () {
		const res = await db.delete('test/123');
		assert(res !== null);
	});
});

describe('Multiple entries case', function () {
	it('should simulateneously add multiple entries', async function () {
		var res;
		for (var i = 0; i < 10; i++) {
			res = await db.insert(`test/${i}`, {test: 'test value'});
			if (res === null) {
				break;
			}
		}
		assert(res !== null);
	});
	it('should get multiple entries', async function () {
		await new Promise((resolve) => {
			setTimeout(resolve, 100);
		});
		var res = await db.getAll('test');
		assert(res.length === 10);
	});
	it('should delete all of a type', async function () {
		var res = await db.deleteWhere('test');
		assert(res !== null);
	});
});
