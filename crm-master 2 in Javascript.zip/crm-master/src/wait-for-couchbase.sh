#!/bin/bash
# wait-for-couchbase.sh

set -e
url="http://$COUCHBASE_HOST/pools/default"

cd srv
rm -rf node_modules
/usr/local/bin/npm cache clear --force
/usr/local/bin/npm install phantomjs
/usr/local/bin/npm install bcrypt
/usr/local/bin/npm install couchbase
/usr/local/bin/npm install hummus
/usr/local/bin/npm install
/usr/local/bin/npm install -g nodemon
/usr/local/bin/npm install -g typescript
sh build-typescript.sh

i=0 # set counter to 0
while true  # infinite loop
do
				if curl --output /dev/null --silent --head --fail -u $COUCHBASE_ADMINISTRATOR_USERNAME:$COUCHBASE_ADMINISTRATOR_PASSWORD "$url";
    then
        # curl didn't return 0 - failure
        echo $i
								if [ $NODE_ENV = "testing" ];
								then
									npm test
								elif [ $NODE_ENV = "production" ];
								then
									/usr/local/bin/npm install pm2 -g
									pm2-runtime --watch pm2-config.yml
								else
									npm run dev
								fi
        break # terminate loop
    fi
    i=$(($i+1))  # increment counter
    echo -en "$i        \r"   # display # of requests each iteration
    sleep 1  # short pause between requests
done
